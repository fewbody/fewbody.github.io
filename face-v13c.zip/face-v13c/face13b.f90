 	program face1
	use physics
	use methodspec
	use work
	use factorials
	implicit real*8 (a-h,o-z)    

	call factorial(maxfac)
	call readvar

	nsrc = 0
	ny = 0
   	if(n2states>0) then
!    						find occupied core states
	 if(.not.(rwpot=='r'.or.rwpot=='R')) call occ

!	   if(nocc>0) then
!	     allocate (aspl(0:ny+2,0:ny),bspl(0:ny,0:ny))
!	     call splines(ny,aspl,bspl)
!      	     endif
      	   endif
        if(nbmax<0) stop

	if(.not.cfiles) then
          call openfiles(nfile,docont,npmax.gt.10,vadia)
	endif

!  enumeration of sets of total angular momentum & parity:
	do 500 ijt=1,ngt
	 jtot = gtot(ijt)
	 jparity = gparity(ijt)

        write(6,1420) ijt,jtot,psign(jparity+2)
 1420   format(/' ********************************************'/   &
     &          ' * Coupled channels set',i3,' for J,pi =',f5.1,a1,' *'   &
     &     /,   ' ********************************************'/)

!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
! enumeration of basis hh and constructing their representations in 
! terms of the channel hh

	call enumchs
	call flush(6)

	if(ijt.eq.1..or.gtvary) then

! storing the kinematical coefficients

	write(10,*) 'allocate xj,wj',njac,', xl,wl,xlag',nlag
	allocate (xj(njac),wj(njac),  xl(nlag),wl(nlag), xlag(0:nlag))
	call quajac1(xj,wj,njac)
	if(cfiles) then
		do i=1,nlag
		wl(i)=rr
		xl(i)=i
		enddo
		xlag(0) = xl(nlag)
	else
 		call qualag(xlag(1),wl,nbmax,5.d0)
 		call qualag(xl,wl,nlag,5.d0)
		do i=1,nlag
		u = xl(i)
		wl(i)=wl(i)/(u**5d0 * exp(-u))		
		enddo
	endif
!          write(6,*)
!          write(6,*) 'All Jacobi points:'
!          write(6,755) (xj(j),j=1,njac)
          write(6,*)
          write(6,*) 'All Gauss-Laguerre points:'
          write(6,755) (rr*xl(j),j=1,nlag)
          write(6,*)
	  if(nbmax.ne.0) then
          write(6,*) 'Gauss-Laguerre points for nbmax =',nbmax,':'
          write(6,755) (rr*xlag(j),j=1,nbmax)
	  endif
755    	 format(' radii:   ',7f10.3,:,/(10x,7f10.3))
	  rmax = rr*xlag(nbmax)
          write(6,*)
!	if(ny.ne.0.and.ymax.lt.rinner-1.) then
!	   write(6,310) ymax,rmax
!310	   format(' insufficient number of splines.'/  		&
!     &		  ' ymax (',f8.3,') should be ',f8.3,' fm')
!	   stop 'ymax'
!	  endif 
	endif


! the angular ("jacobi") basis functions:

	write(6,*) '  Calculating HH up to n =',nmax,', l1,l2 =',l1max,l2max

	allocate (pj(0:nmax,0:l1max,0:l2max,njac))
	call hh(pj,xj,nmax,l1max,l2max,njac)

! angular matrix elements
	write(6,*) '  Calculating matrix elements'
	call flush(6)
	call fadcoef
	call flush(6)

	mchan = imaxs
	if(pripot) call printco(mchan)
!				Possible reductions of Faddeev set:
	call isoreduce
	if(pripot.and.imaxs<mchan) call printco(imaxs)
	call reduce
	if(pripot.and.imaxr<imaxs) call printco(imaxr)
	call effpot(ndrop(ijt))
	if(pripot.and.imaxe<imaxr) call printco(imaxe)
	call feshbach
	if(pripot.and.imaxh<imaxe) call printco(imaxh)
	call flush(6)

	if(vadia) call adiabatics
	call flush(6)

	if(cfiles) then
	  write(6,*) ' Write out files for sturmx'
	  call writefiles
	else
	  jmax = imaxh*(nbmax+1)
	  jjmax = imaxs*(nbmax+1)
	  meig = meigs(ijt)
	  if(meig==0) meig=jmax
	  call eigen
	endif

	deallocate (kk,lltot,ll1,ll2,ssx,jab,ii,wn1,mp12,wfn,ww,pj)
	deallocate (ifo,iba,kkh,iih,ibh)
	if(init>0) deallocate (ctn,dtn)
500	end do
	call memuse; call cpuuse
	end
