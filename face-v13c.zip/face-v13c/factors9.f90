 	function fadnorm(i,ia,i1,ib)
	use physics
	use work
	implicit real*8(a-h,o-z)
	real*8 jn,jn1
	logical sameii
	parameter(eps=1d-10, zero = 0d0)
	integer same1(1:3,1:3),same2(1:3,1:3),same3(1:3,1:3)
	data same1(:,1)/1,3,2/, same1(:,2)/2,1,3/, same1(:,3)/3,2,1/
	data same2(:,1)/2,1,3/, same2(:,2)/3,2,1/, same2(:,3)/1,3,2/
	data same3(:,1)/3,2,1/, same3(:,2)/1,3,2/, same3(:,3)/2,1,3/
	   l1=ll1(i,ia)
	   l2=ll2(i,ia)
	   k=kk(i,ia)
	   ltot=lltot(i,ia)
	   sxx=ssx(i,ia)
	   jn=jab(i,ia)
!					   c=spectator, a+b interacting
	   ajt=spin(ii(i,2,ia),pairs(1,ia))
	   bjt=spin(ii(i,3,ia),pairs(2,ia))
	   cjt=spin(ii(i,1,ia),pairs(3,ia))
!	   sameii = ii(i1,1,ib)==ii(i,pairs(2,ia),ia) .and.	&
!                    ii(i1,2,ib)==ii(i,pairs(3,ia),ia) .and.	&
!                    ii(i1,3,ib)==ii(i,pairs(1,ia),ia)
!	   sameii = ii(i1,pairs(2,ib),ib)==ii(i,pairs(2,ia),ia) .and.	&
!                    ii(i1,pairs(3,ib),ib)==ii(i,pairs(3,ia),ia) .and.	&
!                    ii(i1,pairs(1,ib),ib)==ii(i,pairs(1,ia),ia)
	   sameii = 	ii(i1,1,ib)==ii(i,same1(ia,ib),ia) .and.	&
			ii(i1,2,ib)==ii(i,same2(ia,ib),ia) .and.	&
			ii(i1,3,ib)==ii(i,same3(ia,ib),ia) 

	   k1=kk(i1,ib)
	   ltot1=lltot(i1,ib)
 	   l11=ll1(i1,ib)
 	   l21=ll2(i1,ib)
	   sxx1=ssx(i1,ib)
	   jn1=jab(i1,ib)
	fadnorm = 0d0
!	if (i.eq.8.and.i1.eq.8) then
!	   ajtb=spin(ii(i,2,ib),pairs(1,ib))
!	   bjtb=spin(ii(i,3,ib),pairs(2,ib))
!	   cjtb=spin(ii(i,1,ib),pairs(3,ib))
!	print*,'fadnorm ',i,i1,ia,ib,sameii,ltot,ltot1,sxx,sxx1,jn,jn1 
!	print*,ajt,ajtb,bjt,bjtb,cjt,cjtb
!	endif

        if(.not.sameii) return
	fn = 0d0
	if(ia==ib) then
!		 	Angular momentum overlaps (diagonal)
	 if(ltot==ltot1.and.abs(sxx-sxx1)<eps.and.abs(jn-jn1)<eps) fn = 1d0
	else if(ib == pairs(1,ia)) then
	 if(ltot/=ltot1.or.k/=k1) then
	    fadnorm = 0d0
	    return
	    endif
!		 	Angular momentum overlaps (cylic off-diagonal)
	nst=sxx+cjt-abs(sxx-cjt)
	do ist=0,nst
	   st=abs(sxx-cjt) + ist
	   phase=st-ajt-sxx1+2*(jtot-sxx1-ajt)
	   stat=sqrt((2*jn+1)*(2*jn1+1)*(2*st+1)*(2*st+1)  &
     &	            *(2*sxx+1)*(2*sxx1+1))
	   raca=racah(ltot+zero,sxx,jtot,cjt,jn,st)*  &
     &	        racah(ajt,bjt,st,cjt,sxx,sxx1)*  &
     &          racah(ajt,sxx1,jtot,ltot+zero,st,jn1)
	   r = (-1)**nint(phase) * stat * raca 
	  fn = fn + r
	enddo
	else
!		 	Angular momentum overlaps (anti-cylic off-diagonal)
	nst=sxx+cjt-abs(sxx-cjt)
	do ist=0,nst
	   st=abs(sxx-cjt) + ist
	   phase=st-cjt+sxx+2*(jtot-sxx1-ajt)
	   stat=sqrt((2*jn+1)*(2*jn1+1)*(2*st+1)*(2*st+1)  &
     &	            *(2*sxx+1)*(2*sxx1+1))
	   raca=racah(ltot+zero,sxx,jtot,cjt,jn,st)*  &
     &	        racah(bjt,ajt,st,cjt,sxx,sxx1)*  &
     &          racah(bjt,sxx1,jtot,ltot+zero,st,jn1)
	   r = (-1)**nint(phase) * stat * raca 
	  fn = fn + r
	enddo
	endif
	fadnorm = fn
	return
	end
!
!
!	matrix elements for the SO potential  calculated
!	between the same type of faddeev components ia==ib
!		< i1 || lxi * G_i || i>  
!	where G_i= G_ij sj + G_ik sk and the circular order
!	between components is predefined as (ijk)
!
!
	function meso(i1,i,ia)
	use physics
	use work
	implicit real*8(a-h,o-z)
	real*8 phase,stat,raca,gj,gk,gam1,gam2,meso
	real*8 sxx,jn,sj1,sk1,sxx1,jn1,si1,ltot
	parameter(zero=0d0, one=1d0)
	gj=gamso1(ia)
	gk=gamso2(ia)
!					   c=spectator, a+b interacting
	   ajt=spin(ii(i,2,ia),pairs(1,ia))
	   bjt=spin(ii(i,3,ia),pairs(2,ia))
	   cjt=spin(ii(i,1,ia),pairs(3,ia))
!		write(98,*) ' Part',ia,'; spec',real(cjt),':',ajt,bjt
!	 write(99,*) 'meso for',i,i1
!	--------------------------------	RHS
	l11=ll1(i1,ia)
	l21=ll2(i1,ia)
	ltot1=lltot(i1,ia)
	sj1=ajt
	sk1=bjt
	sxx1=ssx(i1,ia)
	jn1=jab(i1,ia)
	si1=cjt
!	--------------------------------	LHS
	l1=ll1(i,ia)
	l2=ll2(i,ia)
	ltot=lltot(i,ia)
	sxx=ssx(i,ia)
	jn=jab(i,ia)
!	--------------------------------	
!	 write(99,*) 'meso for', l11,l1,l21,l2,jn1,jn
	if (l11.ne.l1.or.l21.ne.l2.or.jn1.ne.jn) then
	 meso=zero
!	 write(99,*) 'meso=0 as',sameii, l11,l1,l21,l2,jn1,jn
	else
	 phase=jn1+l21+l11+sxx+sj1+sk1
	 stat=sqrt((2*ltot1+1)*(2*ltot+1)*(2*sxx1+1)*(2*sxx+1)  &
     		*(2*l11+1)*l11*(l11+1))
	 raca=sim6j(ltot+zero,ltot1+zero,one,sxx1,sxx,jn)  &
     		*sim6j(ltot+zero,ltot1+zero,one,l11+zero,l1+zero,l2+zero)
	 gam1=gj*(-1)**nint(phase+sxx1)*sqrt((2*sj1+1)*sj1*(sj1+1))  &
     		*sim6j(sxx,sxx1,one,sj1,sj1,sk1)
	 gam2=gk*(-1)**nint(phase+sxx)*sqrt((2*sk1+1)*sk1*(sk1+1))  &
     		*sim6j(sxx,sxx1,one,sk1,sk1,sj1)
	 meso=stat*raca*(gam1+gam2)
!	 write(99,88) i,i1,ia,gj,gk,stat,raca,gam1,gam2, meso
!	 write(99,87) 1,sxx,sxx1,one,sj1,sj1,sk1
!	 write(99,87) 2,sxx,sxx1,one,sk1,sk1,sj1
87       format(' gamm',i1,'=',6f6.1)
!	 write(99,88) stat,raca,gam1,gam2,gj,gk
88	 format(' meso =>',3i4,2f4.1,7f10.5/)
	endif
	end
!
!
!	matrix elements for the SS potential  calculated
!	between the same type of faddeev components
!		< i1 || s_j * s_k  || i>  
!
!
	function mess(i1,i,ia)
! 	it should not really have ib since it is only between same fadd comp
	use physics
	use work
	implicit real*8(a-h,o-z)
	real*8 phase,stat,raca,mess
	real*8 sxx,jn,sj1,sk1,sxx1,jn1,si1
	parameter(zero=0d0, one=1d0)
!					   c=spectator, a+b interacting
	ajt=spin(ii(i,2,ia),pairs(1,ia))
	bjt=spin(ii(i,3,ia),pairs(2,ia))
	cjt=spin(ii(i,1,ia),pairs(3,ia))
!		write(98,*) ' Part',ia,'; spec',real(cjt),':',ajt,bjt
!	 write(99,*) 'meso for',i,i1
!	--------------------------------	RHS
	l11=ll1(i1,ia)
	l21=ll2(i1,ia)
	ltot1=lltot(i1,ia)
	sj1=ajt
	sk1=bjt
	sxx1=ssx(i1,ia)
	jn1=jab(i1,ia)
	si1=cjt
!	--------------------------------	LHS
	l1=ll1(i,ia)
	l2=ll2(i,ia)
	ltot=lltot(i,ia)
	sxx=ssx(i,ia)
	jn=jab(i,ia)
!	--------------------------------	
!	 write(99,*) 'mess for' l11,l1,l21,l2,jn1,jn
	if (l11.ne.l1.or.l21.ne.l2.or. &
     &      ltot1.ne.ltot.or.jn1.ne.jn.or.sxx1.ne.sxx) then
	 mess=zero
!	 write(99,*) 'mess=0 as',sameii, l11,l1,l21,l2,ltot1,ltot
	else
	  phase=sj1+sk1+sxx1
	  stat=sqrt((2*sj1+1)*sj1*(sj1+1)*(2*sk1+1)*sk1*(sk1+1))
	  raca=sim6j(sj1,sj1,1.d0,sk1,sk1,sxx)
	  mess=(-1)**nint(phase)*stat*raca
!	xx1=0.5*(sxx*(sxx+1)-sj1*(sj1+1)-sk1*(sk1+1))
!	  write(99,88) i,i1,ia,stat,raca,phase, mess
88	  format(' mess =>',3i4, 6f10.5/)
	endif
	end
!
!
!
!	matrix elements for the tensor potential  calculated
!	between the same type of faddeev components ia==ib
!		< i1 || T_2 (sj,sk) * C_2 (lxi)  || i > 
!
!
	function metensor(i1,i,ia)
	use physics
	use work
	implicit real*8(a-h,o-z)
	real*8 phase,stat,raca,metensor
	real*8 sxx,jn,sj1,sk1,sxx1,jn1,si1
	parameter(zero=0d0, one=1d0)
!					   c=spectator, a+b interacting
	ajt=spin(ii(i,2,ia),pairs(1,ia))
	bjt=spin(ii(i,3,ia),pairs(2,ia))
	cjt=spin(ii(i,1,ia),pairs(3,ia))
!		write(98,*) ' Part  ',ia,'; spec  ',real(cjt),':  ',ajt,bjt
!	 write(99,*) 'metensor for',i,i1
	metensor = zero
!	--------------------------------	RHS
	l11=ll1(i1,ia)
	l21=ll2(i1,ia)
	ltot1=lltot(i1,ia)
	sj1=ajt
	sk1=bjt
	sxx1=ssx(i1,ia)
	jn1=jab(i1,ia)
	si1=cjt
!	--------------------------------	LHS
	l1=ll1(i,ia)
	l2=ll2(i,ia)
	ltot=lltot(i,ia)
	sxx=ssx(i,ia)
	jn=jab(i,ia)
		if(ltot.ne.ltot1) return		! TEST TEST
!	--------------------------------	
!	 write(99,*) 'metensor for  ', i,i1,ia,l11,l1,l21,l2,jn1,jn,sxx,sxx1
	if (l21.ne.l2.or.jn1.ne.jn) then
	 metensor=zero
!	 write(99,*) 'metensor=0 as',l11,l1,l21,ltot1,jn1
	else
!	phase=3*jn1+l21-sxx
	phase=jn1+l21+sxx1
	stat=sqrt(2.*(2*2+1)*(2*sxx1+1)*(2*sxx+1)* &
     &	(2*ltot1+1)*(2*ltot+1)*(2*l11+1)*(2*l1+1)*  &
     &	(2*sj1+1)*sj1*(sj1+1)*(2*sk1+1)*sk1*(sk1+1)/3.) 
	w1=sim6j(ltot1+zero,ltot+zero,2.d0,sxx,sxx1,jn1)
	w2=sim6j(ltot1+zero,ltot+zero,2.d0, &
		l1+zero,l11+zero,l2+zero) 
	w3=wig(2*l11,2*2,2*l1,0,0)
	w4=sim9j(sxx1,sxx,2.d0,sj1,sj1,1.d0,sk1,sk1,1.d0)
	raca=w1*w2*w3*w4   
	metensor=(-1)**nint(phase)*stat*raca*12.d0
!	write(99,88) i,i1,ia,stat,raca,w1,w2,w3,w4, metensor
!	print*,w1,w2,w3,w4,raca
!	nn1=jn1+l21+1+ltot+ltot1
!	stat1=2.*sqrt(5.*6.*(2*l1+1)*(2*l11+1)*(2*ltot+1)*(2*ltot1+1))
!	xx1=sim6j(ltot1+zero,ltot+zero,2.d0,1.d0,1.d0,jn)
!	xx2=sim6j(l1+zero,l2+zero,ltot+zero, &
!     &           ltot1+zero,2.d0,l11+zero) 
!	xx3=wig(2*l1,2*l11,4,0,0)
!	raca1=xx1*xx2*xx3
!	xx4=(-1)**nn1*stat1*raca1
!	metensor=xx4
!	write(99,88) i,i1,ia,stat1,raca1,xx1,xx2,xx3,0.,xx4
	endif
88	  format(' met  =>',3i4,7f8.4/)
	end
!
!
!
!
!	matrix elements for the deformed potential  calculated
!	between the same type of faddeev components ia==ib
!		< i1 || C_2(lxi) * C_2(sj)  || i > 
!	it assume that there is only deformation of one of the
!	nuclei and it is the first interacting pair.
!
!
	function medef1(i1,i,ia,lam)
	use physics
	use work
	implicit real*8(a-h,o-z)
	real*8 phase,stat,raca,medef1
	real*8 sxx,jn,sj1,sk1,sxx1,jn1,si1,ktot
	parameter(zero=0d0, one=1d0)
!					   i=spectator, j+k interacting
!	 write(99,*) 'medef1 for',i,i1
!	--------------------------------	RHS
	l11=ll1(i1,ia)
	l21=ll2(i1,ia)
	ltot1=lltot(i1,ia)
	sj1=spin(ii(i1,2,ia),pairs(1,ia))
	sk1=spin(ii(i1,3,ia),pairs(2,ia))
	sxx1=ssx(i1,ia)
	jn1=jab(i1,ia)
	si1=spin(ii(i1,1,ia),pairs(3,ia))
!	--------------------------------	LHS
	l1=ll1(i,ia)
	l2=ll2(i,ia)
	ltot=lltot(i,ia)
	sj=spin(ii(i,2,ia),pairs(1,ia))
	sk=spin(ii(i,3,ia),pairs(2,ia))
	sxx=ssx(i,ia)
	jn=jab(i,ia)
	si=spin(ii(i,1,ia),pairs(3,ia))
!	--------------------------------
!	rotational model for the "core"
!	write(99,*) 'medef1 for  ', i,i1,ia,l11,l1,l21,l2,jn1,jn,sxx,sxx1
	lsj1=2*sj1
	lsj=2*sj
	lk2=2*corek(pairs(1,ia))
	rot=(-1)**abs(corek(pairs(1,ia))-sj1)*sqrt(2.*sj+1) &
     &     *wig(lsj,lsj1,2*lam,lk2,-lk2)
!	write(99,*) 'medef1> ', lsj1,lsj,lam,lk2,rot
!	--------------------------------
	if (rot.eq.0.or.si.ne.si1.or.sk.ne.sk1.or. &
     &       l2.ne.l21.or.jn.ne.jn1) then
	  medef1=0.d0
!	  write(99,*) 'medef1=0 as  ',rot,si,si1,sk,sk1,l2,l21,jn1,jn1
	else
	phase=jn1+sxx+sxx1+sj1+sk1+l21
	stat=sqrt((2*sxx1+1)*(2*sxx+1)*(2*sj1+1)* &
     &	(2*ltot1+1)*(2*ltot+1)*(2*l11+1)*(2*l1+1)) 
	w1=sim6j(ltot1+zero,ltot+zero,lam+zero,sxx,sxx1,jn1)
	w2=sim6j(ltot1+zero,ltot+zero,lam+zero, &
		l1+zero,l11+zero,l21+zero) 
	w3=sim6j(sxx1,sxx,lam+zero,sj,sj1,sk1)
	w4=wig(2*l11,2*lam,2*l1,0,0)
	raca=w1*w2*w3*w4   
	medef1=(-1)**nint(phase)*stat*raca*rot*sqrt(2.d0*lam+1)
!	write(99,88) i,i1,ia,lam,stat,raca,w1,w2,w3,w4,rot, medef1
	endif
88	  format(' medef = 1 =>',4i4,8f8.4/)
	end
!
!
!	matrix elements for the deformed potential  calculated
!	between the same type of faddeev components ia==ib
!		< i1 || C_2(lxi) * C_2(sk)  || i > 
!	it assume that there is only deformation of one of the
!	nuclei and it is the first interacting pair.
!
!
	function medef2(i1,i,ia,lam)
	use physics
	use work
	implicit real*8(a-h,o-z)
	real*8 phase,stat,raca,medef2
	real*8 sxx,jn,sj1,sk1,sxx1,jn1,si1,ktot
	parameter(zero=0d0, one=1d0)
!					   i=spectator, j+k interacting
!	 write(99,*) 'medef2 for',i,i1
!	--------------------------------	RHS
	l11=ll1(i1,ia)
	l21=ll2(i1,ia)
	ltot1=lltot(i1,ia)
	sj1=spin(ii(i1,2,ia),pairs(1,ia))
	sk1=spin(ii(i1,3,ia),pairs(2,ia))
	sxx1=ssx(i1,ia)
	jn1=jab(i1,ia)
	si1=spin(ii(i1,1,ia),pairs(3,ia))
!	--------------------------------	LHS
	l1=ll1(i,ia)
	l2=ll2(i,ia)
	ltot=lltot(i,ia)
	sj=spin(ii(i,2,ia),pairs(1,ia))
	sk=spin(ii(i,3,ia),pairs(2,ia))
	sxx=ssx(i,ia)
	jn=jab(i,ia)
	si=spin(ii(i,1,ia),pairs(3,ia))
!	--------------------------------
!	rotational model for the "core"
!	write(99,*) 'medef2 for  ', i,i1,ia,l11,l1,l21,l2,jn1,jn,sxx,sxx1
	lsk1=2*sk1
	lsk=2*sk
	lk2=2*corek(pairs(2,ia))
	rot=(-1)**abs(corek(pairs(2,ia))-sk1)*sqrt(2.*sk+1) &
     &     *wig(lsk,lsk1,2*lam,lk2,-lk2)
!	write(99,*) 'medef2> ', lsk1,lsk,lam,lk2,wig(lsk,lsk1,2*lam,lk2,-lk2),rot
!	--------------------------------
	if (rot.eq.0.or.si.ne.si1.or.sj.ne.sj1.or. &
     &       l2.ne.l21.or.jn.ne.jn1) then
	  medef2=0.d0
!	  write(99,*) 'medef2=0 as',rot,si,si1,sk,sk1,l2,l21,jn1,jn1
	else
	phase=jn1+2*sxx1+sj1+sk+l21
	stat=sqrt((2*sxx1+1)*(2*sxx+1)*(2*sk1+1)* &
     &	(2*ltot1+1)*(2*ltot+1)*(2*l11+1)*(2*l1+1)) 
	w1=sim6j(ltot1+zero,ltot+zero,lam+zero,sxx,sxx1,jn1)
	w2=sim6j(ltot1+zero,ltot+zero,lam+zero, &
		l1+zero,l11+zero,l21+zero) 
	w3=sim6j(sxx1,sxx,lam+zero,sk,sk1,sj1)
	w4=wig(2*l11,2*lam,2*l1,0,0)
	raca=w1*w2*w3*w4   
	medef2=(-1)**nint(phase)*stat*raca*rot*sqrt(2.d0*lam+1)
!	write(99,89) i,i1,ia,lam,stat,raca,w1,w2,w3,w4,rot, medef2
	endif
89	  format(' medef = 2 =>',4i4,8f8.4/)
	end
!
