      module susycom
	implicit real*8(a-h,o-z)

      real*8, save,allocatable:: ZF(:,:),ZB(:)
      real*8, save,allocatable:: A(:,:), AA (:,:), B(:,:)
      real*8, save,allocatable:: XIF1(:,:),XIF2(:,:)
      real*8, save,allocatable:: FF(: ),GG(:),FD(:),GD(:)
      real*8, save,allocatable:: FUN(:,:,:)
      real*8, save,allocatable:: TOTSUS(:,:,:)
      real*8, save,allocatable:: BE(:,:),V9(:)

      COMMON
     */INTEG/RM,H,EC ,AH2,DELR,IFUN,IIPR,AH22,WVK,WVK1,RINT,NIN
       real*8 H2M
       integer*4, save:: nm2,nstvk,Nkmaxss
       real*8, save,allocatable:: CL(:,:),FUGS(:,:),VK(:,:)
	end module susycom




	subroutine susy(nch,JTOT,par,fermi,nbl,nbs,pmul,h2sm,A1,A2,nx,drho,
     x                  esum,mc,kval,ic1v,ic2v,sv,sl2,ip,vccx)
c #######################################################################
c
c  *** Calculates 2-Body SUSY potential for Nach 'forbidden' states in  
c  *** coupled channels problem with the angular moments in array kval
c  *** nch - number of  coupled channels
c  *** 
c  
c  **********************************************************************
         use susycom
	implicit real*8(a-h,o-z)
        parameter (MAXEIG=100)
	real*8 JTOT,SL2(NCH,NCH),sv(nch),EFORB(MAXEIG),vccx(nx,NCH,NCH),
     x        esum(NCH),EALLOW(MAXEIG),V(2),nrm(NCH),nrms(NCH,MAXEIG,2),
     x        EINIT(MAXEIG)
	integer JBS,KVAL(NCH),nodes(nch,MAXEIG),nd(MAXEIG),mcbig(MAXEIG)
	integer ic1v(nch),ic2v(nch)
	character par
         logical GO,initscan,calmci

      real*8,allocatable:: wpot(:)
c *** External pot(i,j,r,JTOT) - potentials: i,j - number of channels,
c *** r-radius in fm, JTOT - total moment (for different J-potentials)

c      in TOTSUS(NSMAX,NSMAX,NMAX) - susy components for (i,j,r) channel

         H2M = h2sm
	 amu = A1*A2/( A1 + A2)
	 AMH  = AMU /H2SM
         rhomax = (nx-1)*drho
      WRITE (4,*)'Mass numbers:  A1=',A1,' A2=',A2,' red. mass:',amu

      WRITE (4,*)'Max. radius: ',rhomax,'  step:',drho
      WRITE (4,*)'Esum:',esum(1:NCH)
!     WRITE (4,*)'SL2:'
!     Do I=1,NCH
!     write(4,'(10f8.3)') (SL2(I,J),J=1,NCH)
!     enddo
	 
        nstvk = nch*(nch + 1)/2
	drho2 = drho/2.d0

         RM = rhomax
         H  = drho
         DELR = 4.d0
         RINT = 4d0
	 DELE = 0.2
	 EMAX = +5.0
	 EMAX = +0.0
	 initscan=.true.

c ****   NM - number of radial points for wave function    ****
c ****        with small step for SUSY, and Susy potential ****
        NM = rhomax/drho + 0.5d0
c ****   NM2 - number of radial points for matrix el-s and C.F. Barrier ****
        NM2 = NM*2 +1

        Nkmaxss = nch
c	
c *** calculating and storing (at triangle form in VK(IC,IR)) the potentials
c *** at half-step drho2 for B.S. energy and WF calculation in bs_ss subrout.

C *************************************************************************
	allocate(TOTSUS(nch,nch,NM),CL(nch,NM2),
     & 		 FUGS(nch,NM),VK(nstvk,NM2),wpot(nstvk))

C *************************************************************************
	 write(4,*) 'NCH,JTOT,par lval(:)=',nch,JTOT,par,kval(:)
	 write(401,1) NCH,JTOT, kval(1:nch)
1	 format('#   NCH,JTOT, lval(:) =',i3,f5.1,20i3)
          if(fermi<0.)WRITE (6,2) fermi
2       format('    Exclude bound states up to ',f8.2,' valence energy')
          if(fermi>0.)WRITE (6,201) nint(fermi)
201     format('    Exclude lowest ',i3,' bound states')
	 JBS = nint(JTOT)
C *************************************************************************
	do  IR=1,NM2
	rho = drho2*IR
         ic=0
	  do i=1,nch
	  do j=i,nch
         ic=ic+1
        call pot(v,rho,kval(i),kval(j),ic1v(i),ic1v(j),ic2v(i),ic2v(j),
     X                  sv(i),sv(j),jtot,sl2(i,j),i,j,ip)
        VK(IC,IR) = V(1)*pmul + V(2)
        if(i==j) VK(IC,IR) = VK(IC,IR) + esum(i)
	  enddo
	 enddo
        
	enddo	 

	   istep = 0.2/drho2
!	   istep = 1

	do  IR=istep,NM2,istep
	rho = drho2*IR
c	v = ww(i,j,IR)
         ic=0
	do i=1,nch
	do j=i,nch
         ic=ic+1

        wpot(ic) = vval(i,j,IR)
	enddo
	enddo
        write(4,555)rho,(wpot(icc),icc=1,min(ic,10))
	enddo
 555   format(1x,f8.3,10g12.3)

C
C *** PREPARATION OF CENTRIFUGIONAL ENERGY ARRAY CL(nch,NMAX)
C ***
C
      DO 3  I=1,nch
      AK     =   kval(I)*1.d0
      AK1    =   AK*(AK + 1.D0)
      DO 333 N=1,NM2
      RN2    =  (drho2*N)**2
 333  CL(I,N)=   AK1/RN2
   3  CONTINUE

c ###############################################################################
	if(initscan) then
	    ibs = 0
        ir0 = 1.0/drho2  ! look outside 1fm to avoid Vso spikes
            EC = 0.
	    do 110 ir=1+ir0,NM2
 110	    EC = min(EC,VK(1,ir))
 	write(4,*) ' Start init search at Vmin =',EC
 111            EC = EC*0.995d0
        CALL D3BS (GO,kval,nch  ,mc,.true.,amu,nrm,DELE,EMAX,IFAIL)
	  if(EC.lt.EMAX)write(401,'(''# Initial state at '',f9.3)') EC
	     write(401,*) '&'
          if(.not.GO ) go to 666
          if(IFAIL>0 ) go to 112
	     ibs =ibs +1
	     EINIT(ibs) = EC
	     nrms(1:nch,ibs,1) = nrm(1:nch)
	     big=0.
	     do i=1,nch
	     if(big<nrm(i)) then
	        big = nrm(i)
		mcbig(ibs) = i
		endif
	     enddo
	   write(4,*)'** Bound State',ibs,'at E=',EC  
!	   write(6,*)'** Bound State',ibs,'at E=',EC  
          if(EC.lt.EMAX ) go to 111
	NBS = ibs-1
        if(NBS>0) then
	  write(6,1112) JTOT,par,EINIT(1:NBS)
1112       format('   ',f5.1,a1,'  eigenstates: ',20f8.3)
	  if(nch>1) then
	     do i=1,nch
	     write(6,192) (nrms(i,ibs,1),ibs=1,NBS)
	     enddo
	  endif
	else
          write(6,*) '   No initial eigenstates'
	endif
	endif

!       EC = minval(VK(1,:))
 112        EC = 0.
	    do 113 ir=1+ir0,NM2
 113	    EC = min(EC,VK(1,ir))
	if(initscan.and.EINIT(1)<-1) EC = EINIT(1)-1.
 	write(4,*) ' Start search for susy at =',EC
       isuf = 0
       EALLW = 0.
       NBL = 0
       do 150 isu = 1,MAXEIG
            EC = EC+0.2
!	    write(6,*) 'Look for bs from ',real(EC)
	    mci = mc
	    calmci = .not.initscan.or.isuf+1>NBS
	    if(.not.calmci) mci = mcbig(isuf+1)
            CALL D3BS (GO,kval,nch  ,mci,calmci,amu,nrm,DELE,0d0,IFAIL)
	 if(EC.lt.EMAX)write(401,'(''# eliminate state at '',f9.3)') EC
	     write(401,*) '&'
            if(.not.GO ) go to 666
            if(EC>=0.0) go to 190
            if(IFAIL>0 ) then
!             write(6,114) EC
114           format('**D3BS fails to find bs near ',f8.4,
     x              ' with ch 1 nonzero')
             EC = EC+0.2
              go to 150
              endif

           isuf = isuf+1
           EFORB(isuf) = EC
	   nrms(1:nch,isuf,1) = nrm(1:nch)
	       cx = 0.
	       do 115 i=1,nch
115	       cx = cx + nrm(i)*esum(i)
!	       cx = 0.				! include corex correction now
            if(fermi<0.and.EC-cx>fermi .or.
     x         fermi>0.and.isuf>nint(fermi)) then
	      isuf = isuf -1   			! NOT forbidden
	      EALLW = min(EALLW,EC)
	      write(4,*) ' State at ',EC,' is really ALLOWED'
	      go to 150
	      endif
	   if(EC<0.) write(4,*)'** Original bs',isuf,'at E=',EC,EC-cx
	   NBL = isuf
	   write(401,'(''# Now eliminate state at '',2f9.3)') EC,EC-cx

        CALL SUSY3B ( kval,nch,NCH, NM)
         IIC = 0
	do I1=1,nch
	do J1=1,nch
        vccx(2:nx,I1,J1) = TOTSUS(I1,J1,:)
        vccx(1,I1,J1) = vccx(2,I1,J1)
        if(I1==J1) vccx(:,I1,J1) = vccx(:,I1,J1) - esum(I1)

         IF(J1 .GE. I1)THEN
	   IIC = IIC + 1
           do I=1,NM
             VK(IIC,2*I) = TOTSUS(I1,J1,I)     
           ENDDO ! I
           do I=1,NM-1
             VK(IIC,2*I+1) = (TOTSUS(I1,J1,I)+TOTSUS(I1,J1,I+1))/2.d0     
           ENDDO ! I
           VK(IIC,1) = VK(IIC,2)*4.d0
         ENDIF
	ENDDO ! J1
	ENDDO ! I1

150    continue
190    continue
        if(.true.) then
c #### Printing VK
         IIC = 0
	DO I1=1,nch
	DO J1=1,nch
           del = 0.0
           if(I1==J1) del = esum(I1)
         IF(J1 .GE. I1)THEN
	    IIC = IIC + 1
!	    if(J1 == I1) then ! diagonal potentials only
            write(204,1905)JTOT,par,i1,j1,kval(i1),kval(j1),del
1905        format('### JT',f5.1,a1,' chan i=',i3,', j=',i3,' ###',
     x       ' (Ls',2i3,')  Ec =',f8.3)
            do I=istep,NM2,istep
               write(204,'(G12.5,4X,2G12.3)')
     x	           drho2*I ,VK(IIC,I),VK(IIC,I)-del
            ENDDO
            write(204,*)'&'
!	    endif   ! diagonal only
          ENDIF
 	ENDDO
	ENDDO
        endif

        if(NBL>0) then
	  write(6,191) EFORB(1:NBL)
191       format('   Eliminated states at ',20f8.3)
	  if(nch>1) then
	     do i=1,nch
	     write(6,192) (nrms(i,ibl,1),ibl=1,NBL)
192          format('                  Norms ',20f8.4)
	     enddo
	  endif
	else
          if(NBL==0) write(6,*) '   No eliminated states'
	endif

	if(NBL>0) then !   FIND ALLOWED STATES
	    ibs = 0
            GO = .false.
            EC = min(EALLW,EFORB(NBL))-0.4  ! start looking for allowed states here.
	    write(4,*) ' Start search for allowed states at ',EC
211        EC = EC+0.2
        CALL D3BS (GO,kval,nch  ,mc,.true.,amu,nrm,DELE,EMAX,IFAIL)
	     ibs =ibs +1
	if(EC.lt.EMAX)write(401,'(''# Allowed state at '',f9.3)') EC
	      write(401,*) '&'
             if(.not.GO) go to 290
              if(IFAIL>0 ) then
                write(6,114) EC
                EC = EC+0.2
                go to 211
              endif
             EALLOW(ibs) = EC
	     nrms(1:nch,ibs,2) = nrm(1:nch)
	   write(4,*)'** Allowed Bound State',ibs,'at E=',EC  
!	   write(6,*)'** Allowed Bound State',ibs,'at E=',EC  
                if(.false.) then
                istep = 0.1/drho
                do i=1,nch
       	        write(122,994) i,KVAL(i),EC
                enddo
  994	        format('# Bound state #',i2,',L =',i3,' at ',f10.5)
	        do ir=1,NM,istep
	        write(122,995) ir*real(drho),(FUGS(i,ir),i=1,min(10,nch))
  995           format(f8.3,10f10.6)
	        enddo
	        write(122,*) '&'
	        call flush(122)
                endif
           
            nd(ibs) = 0
            do i=1,nch
             nodes(i,ibs) = 1
             do ir=2+kval(i),NM
               if(fugs(i,ir)*fugs(i,ir-1)<0) nodes(i,ibs) = nodes(i,ibs)+1
             enddo
             nd(ibs) = nd(ibs) + nodes(i,ibs)
            enddo
          if(EC.lt.EMAX.and.ibs<MAXEIG-2 ) go to 211
290     nbs = ibs-1
        write(6,291) nbs,EALLOW(1:nbs)
291     format('  ',i3,' allowed states ',:,'at ',20f8.3,(/24x,20f8.3))
	  if(nbs>0.and.nch>1) then
	     do i=1,nch
	     write(6,192) (nrms(i,ibs,2),ibs=1,NBS)
	     enddo
	  endif
        if(nbs>0.and.nd(ibs)/=nch) then
        if(nch==1) write(6,292) nodes(1:nch,1:nbs)
292     format('  ',3x,'             nodes',20(i4,4x))
        if(nch==2) write(6,293) nodes(1:nch,1:nbs)
293     format('  ',3x,'             nodes',20(i4,i2,2x))
        if(nch>=3) write(6,294) nodes(1:3,1:nbs)
294     format('  ',3x,'             nodes',20(i4,2i2))
        endif
	endif


	deallocate(TOTSUS,CL,FUGS,VK,wpot)
        return 
 666    continue
	deallocate(TOTSUS,CL,FUGS,VK,wpot)
        write(6,*)' *****   Bound state is not found   *******'
        write(6,*)' *****   in deep potential. No SUSY *******'
        return 
	end
c #################### END of SUSY  #########################

c ####################  Lagrange Interpolation 3-d power  #################
        function ALAGR3(ww,mch,nch,nlag,rr,xl,i,j,n0,x)

	implicit real*8(a-h,o-z)

	dimension ww(mch,mch,nlag),xl(nlag)

	x0 = rr*xl(n0)
	x1 = rr*xl(n0+1)
	x2 = rr*xl(n0+2)
	x3 = rr*xl(n0+3)

	y0 = ww(i,j,n0)
	y1 = ww(i,j,n0+1)
	y2 = ww(i,j,n0+2)
	y3 = ww(i,j,n0+3)

        A0 = (x-x1)*(x-x2)*(x-x3)/((x0-x1)*(x0-x2)*(x0-x3)) *y0
        A1 = (x-x0)*(x-x2)*(x-x3)/((x1-x0)*(x1-x2)*(x1-x3)) *y1
        A2 = (x-x0)*(x-x1)*(x-x3)/((x2-x0)*(x2-x1)*(x2-x3)) *y2
        A3 = (x-x0)*(x-x1)*(x-x2)/((x3-x0)*(x3-x1)*(x3-x2)) *y3

        ALAGR3 = A0 + A1 + A2 + A3

        return 
	end
