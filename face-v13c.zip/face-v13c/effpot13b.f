	subroutine effpot(dropped)
c
c  ####  Effective 3-body interaction : transform from Kmax to Kmin
c        Barnea et al Phys Rev C61 p.054001
c        Similarity transformation method
c
c  ####  INTERPOLATION
c     
        use physics
        use methodspec
        use work, nch=>imaxr,mch=>imaxr,neigs=>imaxe

      implicit real*8(a-h,o-z)
      real*8,allocatable:: VHH(:,:),U(:,:),u2(:,:),
     *          omega(:,:), veclan(:,:), beti(:,:),omega2(:,:) 
     x         , veff(:,:), eigval1(:), alfi(:,:),eigval2(:)
      integer indx(nch),iih2(nch,3),kkh2(nch),evord(nch),ibh2(nch),
     x        dropped
      logical flip,OK
c -------------------------------------------------------------------

       neigs = nch
	AH2 = 1.d0/H2SM
	itr=0
	
c               NF counts channels to include  -> IEO(*,1)
c               ND counts channels to eliminate  -> IEO(*,2)
C               IEO(*,3) indexes from original to new channel (or 0 if none)
       NF = 0
       ND = 0
       mc = 0
       do 4 I=1,nch
        k = kkh(I)
         ic1=iih(I,1)
         ic2=iih(I,2)
         ic3=iih(I,3)
         ICORE = max(ic1,ic2,ic3)
         mc = max(mc,ICORE)
        OK = k.le.abs(kmaxeff(ICORE)).or..not.effp
        if(OK) then
         NF = NF+1
         IEO(NF,1) = I
         IEO(I,3) = NF
        else
         ND = ND+1
         IEO(ND,2) = I
         IEO(I,3) = 0
        endif
4       continue
        neigs = NF
        if(ND==0.and.dropped.le.0) return
        write(6,10) NF,ND,kmaxeff(1:mc)
10      format(/'  Effpot reduction to ',i3,' channels, omit',i4,
     x    ' using  Kmaxeff <=',5i3)
        write(6,11) dropped,shift
11	format( '         dropping ',i3,' eigensurfaces, moved to',f8.2)
        if(init==0) then
         write(6,*) 'EFFPOT only for symmetric matrices! Stop'
         stop
        endif
        if(itr>0) write(24,10) NF,ND,kmaxeff(1:mc)
        flip = .false.
        do i=1,neigs
        flip = flip .or. IEO(i,1).ne.i
        enddo
!        flip = .true.
	if(flip) write(6,12) ' Kept ',(IEO(i,1),i=1,neigs)
	if(flip) write(6,12) ' Lost ',(IEO(i,2),i=1,ND)
12	format('  ',a5,' channels =',20i4,:,/(18x,20i4))
C *************************************************************************
	allocate(VHH(nch,nch),U(nch,nch), eigval1(nch), alfi(nch,nch),
     *    omega(nch,nch),veclan(nch,nch), veff(nch,nch),u2(neigs,neigs),
     x    beti(nch,nch),omega2(neigs,neigs), eigval2(nch))  

	 rewind iwf
	 iwn=121-iwf
         open(iwn,access='sequential',status='scratch',
     x             form='unformatted')
         rewind iwn
          DO 16 JR=1,nlag
            R = rr*xl(JR)
          read(iwf) ww(1:nch,1:nch)
          
	 sc = r*r * AH2  ! = r**2/h2sm
         do i=1,nch
                k=kkh(i)
                ic1=iih(i,1)
                ic2=iih(i,2)
                ic3=iih(i,3)
                ib = ibh(i)
            et = energy(ic1,ib) + energy(ic2,pairs(1,ib)) + 
     x           energy(ic3,pairs(2,ib))
          ww(i,i) = ww(i,i) + et + (k+1.5)*(k+2.5)/sc
          enddo
!		Rearrange channels so kept channels first.
          do 21 i=1,nch
          do 20 j=1,nch
           i1 = IEO(i,1); j1 = IEO(j,1)		! wanted channels first
           if(i>neigs) i1 = IEO(i-neigs,2)	! unwanted channels afterwards
           if(j>neigs) j1 = IEO(j-neigs,2)
20        VHH(i,j) = ww(i1,j1) * sc
          kkh2(i) = kkh(i1)
          ibh2(i) = ibh(i1)
          iih2(i,:) = iih(i1,:)
21        continue

       if(itr>0) then
       write(24,*)
       WRITE(24,*)'VHH at R =',real(R)
       endif
       if(itr>3) then
    	  DO   I = 1,nch
     	  WRITE(24,2654)(VHH(I,j),j = 1,min(nch,9))
    	  ENDDO
       endif
       call flush(24)

 2654 FORMAT(2X,10G11.3)
 2655 FORMAT(2X,10(i4,7x))
 2656 FORMAT(2X,f10.5,' evec:',10f9.5)
 2657 FORMAT(2X,f10.5,' reor:',10f9.5)

c
c ****************************************************************
C ****  WE calculate EIGVEC(U(L,LAM))
C	 	 
c       write(4,*)' 1: nch,neigs,nch',nch,neigs,nch
c       write(24,*)'EIVECVAL 1: nch,neigs,nch',nch,neigs,nch

	  
          call f02agf(VHH,nch,nch,eigval1,eigval2,U,nch,
     x                beti,nch,indx,ifail)
          call m01daf(eigval1,1,nch,'a',evord,ifail)
          call m01zaf(evord,1,nch,ifail)
	  if(dropped>0) then
	     write(6,40) R,shift/sc,
     x 		(eigval1(evord(i))/sc,i=1,min(9,dropped))
	     do i=1,dropped
	     eigval1(evord(i)) = shift
	     enddo
             call m01daf(eigval1,1,nch,'a',evord,ifail)  ! resort
             call m01zaf(evord,1,nch,ifail)
40        format('  PA reduced couplings at R =',F8.3,
     X		' after moving to',F8.1,' the levels',10f9.3)

	  endif

	if(itr>1) then
           WRITE(24,*)'Eigenvalues of full VHH:'
           WRITE(24,2654)(eigval1(j),j = 1,nch)
           WRITE(24,*)'Lowest eigenvalues:'
           WRITE(24,2654)(eigval1(evord(j)),j = 1,neigs)
           WRITE(24,2655)(evord(j),j = 1,neigs)
        endif
       if(itr>3) then
       do j=1,nch
       write(24,2656) eigval1(evord(j)),(U(L,evord(j)),L=1,min(nch,9))
       enddo
       do j=1,nch
       write(24,2657) eigval1(evord(j)),
     x			(U(evord(L),evord(j)),L=1,min(nch,9))
       enddo
       endif
c
c ****************************************************************
C ****  WE STORE EIGVAL AND EIGVEC for lowest 'neigs' eigenvalues
C	 	 
	DO LAM=1,nch
	  VECLAN(1:NCH,LAM) = U(1:NCH,evord(LAM))
         ENDDO

        NRHS  = nch - neigs

ccc **** inverse alfa ***
        alfi(1:neigs,1:neigs) = VECLAN(1:neigs,1:neigs)
	
	N2 =0
        call MATIN1 (Alfi,nch ,neigs,N2,indx,NERROR,DETERM)

        beti(1:NRHS,1:neigs) = VECLAN(neigs+1:neigs+NRHS,1:neigs)

	DO  IL=1,neigs
        DO  I1=1,NRHS
         sum = 0.d0
        DO  I=1,neigs
          sum = sum + beti(I1,I) * alfi(I,IL)
	enddo
          omega(I1,IL)=sum
	enddo
	enddo

 211	FORMAT(1X,9(G11.3,1X))
c                                      
c *****  calculating effective (non-hermitian) interaction VHH(nch,nch)
c
        alfi(1:neigs,1:neigs) = VECLAN(1:neigs,1:neigs)

!       beti(1:NRHS,1:neigs) = VECLAN(neigs+1:neigs+NRHS,1:neigs)
	
         VHH(:,:) = 0.d0  
        DO  I=1,neigs
        DO  Ip=1,neigs
        DO  IJ=1,neigs
         SUM = 0.d0
        DO  Iq=1,NRHS

         SUM =  SUM + 
     +    alfi(I,IJ)*eigval1(evord(IJ))*beti(Iq,IJ)*omega(Iq,Ip)  
	  
	enddo
         VHH(I,Ip) = VHH(I,Ip) + SUM
     +          + alfi(I,IJ)*eigval1(evord(IJ))*alfi(Ip,IJ)
	enddo
	
	enddo
	enddo

	if(itr>2) then
	write(24,*)' with nonsymmetric part'
        DO  I1=1,neigs
!	write(24,211)(VHH(I1,I),I=1,MIN(neigs,9))
	write(24,211)(VHH(I1,I),I=1,neigs)
	enddo
	endif
c                                      +
c *****  organizing matrix (P(1 + omega * omega)P)
c
	 omega2(:,:) = 0.d0
        DO  I=1,neigs
        DO  Ip=1,neigs
          DO  Iq=1,NRHS
            omega2(I,Ip) = omega2(I,Ip) +  omega(Iq,I)*omega(Iq,Ip) 
	  enddo
          if (I .eq. Ip) omega2(I,Ip) = omega2(I,Ip) + 1.d0
	enddo
	eigval2(I) = 0.d0
	enddo
c                                      +
c *****  finding eigen -vectors -values of matrix (P(1 + omega * omega)P)
c

c
c ****************************************************************
C ****  WE calculate EIGVAL(eigval1(LAM)) AND EIGVEC(U(L,LAM))
C	
c       write(4,*)' 2: nch,neigs,nch',nch,neigs,nch
c       write(24,*)'EIVECVAL 2: nch,neigs,nch',nch,neigs,nch

        NOVEC = 0 	 
        call  HDIAG(omega2,neigs,neigs,NOVEC,U2,NR)
	 do i=1,neigs
	  eigval1(i) = omega2(i,i)
	  enddo
c
c ****************************************************************
C ****  SQRT((P(1 + omega * omega)P)) -> SQRT( EIGVAL )
C	 	 
       if(itr>0) then
       write(24,*)' eigenvalues of omega2 '
        write(24,211)	(eigval1(LAM),LAM=1,neigs) 
	endif

	DO LAM=1,neigs
	   IF(eigval1(LAM).ge. 0.d0) then
	     eigval2(LAM) = SQRT(eigval1(LAM))
           ELSE
             write(4,*)' EIGVAL of (P(1 + omega * omega)P) < 0 !!!'
             stop 5
	   endif
 	ENDDO
 
c ??? Ordering the columns of eigenvectors

	 omega2(:,:) = 0.d0

        DO  I=1,neigs
        DO  Ip=1,neigs

        DO  Iq=1,neigs
          omega2(I,Ip) = omega2(I,Ip) +   U2(Iq,I)*eigval2(Iq)*U2(Iq,Ip) 
	enddo
	enddo
	enddo

	if(itr>3) then
       write(24,*) '   matrix sqrt(omega2) '
        DO  I1=1,neigs
	write(24,211)(omega2(I1,I),I=1,MIN(neigs,9))
	enddo
	endif


cC ################################################################
c
C ****  WE calculate effective interaction (hermitized)
c
C ****  WE calculate [(P(1 + omega * omega)P)]**(-1/2) =
C ****  omega2(I,Ip)**(-1)  

      omega(1:neigs,1:neigs) = omega2(1:neigs,1:neigs)
c
C ****  WE calculate effective interaction (hermitized) (in omega)
C
               N2 =0
      call MATIN1 (omega2,neigs ,neigs,N2,indx,NERROR,DETERM)

        DO  I=1,neigs
         DO  Ip=1,neigs
            sum = 0.d0
          DO  Iq=1,neigs
          DO  Ik=1,neigs
           sum = sum + omega(I,Iq)*VHH(Iq,Ik)*omega2(Ik,Ip) 
	  enddo
	  enddo
           veff(I,Ip) = sum
	 enddo
	enddo

       if(itr>1) then
       write(24,*)'   Matrix veff(KNL,LAM), symmetrised'
        DO  I1=1,neigs
	write(24,211)(veff(I1,I),I=1,MIN(neigs,9))
	enddo
	endif

C ################################################################
C ****  WE STORE new effective potential 
C	 	 
        VEFF(:,:) = VEFF(:,:) / sc

         do i=1,neigs
                k=kkh2(i)
                ic1=iih2(i,1); ic2=iih2(i,2); ic3=iih2(i,3)
                ib = ibh2(i)
            et = energy(ic1,ib) + energy(ic2,pairs(1,ib)) + 
     x           energy(ic3,pairs(2,ib))
          VEFF(i,i) = VEFF(i,i) - et - (k+1.5)*(k+2.5)/sc
          enddo
c ###################################################################
       if(itr>1) then
       write(24,*)'matrix veff(KNL,LAM)/H*r**2'
        DO  I1=1,neigs
	write(24,211)(veff(I1,I),I=1,MIN(neigs,9))
	enddo
	endif

       write(iwn) veff(1:neigs,1:neigs)

 16    CONTINUE
        close(iwf,status='delete')
        iwf = iwn
        kkh(:) = kkh2(:)		! quantum numbers in new order now.
        ibh(:) = ibh2(:)
        iih(:,:) = iih2(:,:)
!	if(flip.and.JR==1) write(6,11) 'K new',(kkh(i),i=1,neigs)

C
      deallocate(VHH,U, omega ,veclan,
     x          veff , eigval1  , alfi , beti ,omega2, eigval2 )
       write(6,*) 'EFFPOT done: imaxr->imaxe =',nch,neigs
       nch = neigs
       return
       end
