!----------------------------------------------JACOBI HYPERANGULAR BASIS
	subroutine quajac1(x,w,n)
c gauss-jacobi quadrature formulas
	use factorials
	implicit real*8 (a-h,o-z)
	dimension x(n),w(n)
	do 1 i=1,n
	a=pi/(n+1.d0)
	b=a*i
	c=cos(b)
	x(i)=c
	s=1.d0-c*c
1	w(i)=a*s
	return
	end
	
	real*8 function pojac(n,al,be,x)
c calculates the jacobi polinomials
	implicit real*8 (a-h,o-z)
	a=1.
	if(n.eq.0) then
	pojac=a
	return
	end if
	b=.5d0*((al-be)+(al+be+2.d0)*x)
	if(n.eq.1) then
	pojac=b
	return
	end if
	do 1 i=2,n
	p1=2.d0*i+al+be-2.d0
	p2=p1+1.d0
	p3=p2+1.d0
	d=2.d0*i*(al+be+i)*p1
	c=(p2*(p1*p3*x+al*al-be*be)*b-2.d0*(i+al-1.d0)*(i+be-1.d0)*
     x			p3*a)/d
	a=b  	
1	b=c
	pojac=c
	return
	end
	real*8 function jacnorm(n,l1,l2)		
	use factorials
	implicit real*8 (a-h,o-z)
c norm. coefficient for jacobi polynomials with al=l1+1/2,   
c be=l2+1/2.

	a=dlfac(n)
	a1=dlfac(n+l1+l2+1)
	a2=dl2fac(n+l1)
	a3=dl2fac(n+l2)
	ddd=sqrt(2**(2*n)*(l1+l2+2.d0*n+2.d0)*exp(a+a1-a2-a3)/pi)
	jacnorm=sqrt(2d0**(2*n)*(l1+l2+2*n+2)*exp(a+a1-a2-a3)/pi)
	return
	end
	subroutine hh(pj,xj,nmax,l1max,l2max,njac)
	implicit real*8 (a-h,o-z)
	dimension xj(njac),pj(0:nmax,0:l1max,0:l2max,njac)
	real*8 h1(0:l1max),h2(0:l2max)
	real*8 jacnorm

	do 100 i=1,njac
	  xx=xj(i)
	  z1=sqrt(1.-xx)
	  z2=sqrt(1.+xx)
	h1(0)=1.
	h2(0)=1.
	do 80 j=1,l1max
	  h1(j)=h1(j-1)*z1
80	  continue
	do 81 j=1,l2max
	  h2(j)=h2(j-1)*z2
81	  continue

	do 95 l1=0,l1max
	  al=l1+0.5d0
	do 93 l2=0,l2max
	  be=l2+0.5d0
	do 90 n=0,nmax
	   pj(n,l1,l2,i)=h1(l1)*h2(l2)*jacnorm(n,l1,l2)*pojac(n,al,be,xx)
90	 continue
93	continue
95	continue
100	continue
	return
	end

!----------------------------------------------GAUSS-LAGUERRE HYPERRADIAL BASIS
	subroutine qualag(x,w,n,al)
! gauss-laguerre quadrature formulas
! al is an integer number
	use factorials
	implicit real*8 (a-h,o-z)
	dimension x(n),w(n)
	y=1.
	eps=1.e-13
! initial values for nodes
	h=.01d0/n
	f=2.d0*n+al+1.d0
	g=f+sqrt(f*f+.25d0-al*al)
	m=g/h+1
	j=0
	do 1 i=1,m
	z=h*i
	v=polag(n,al,z)
	c=v/y
	if(c.lt.0) then
	j=j+1
	x(j)=z
	end if
1	y=v
! exact nodes
	do 2 i=1,n
	xs=x(i)
	call rootlag(xs,y,eps,n,al)
2	x(i)=y
! the weights
	lal=al
	s=exp(dlfac(n+lal)-dlfac(n+1))/(n+1)
	do 3 i=1,n
	a=x(i)
	b=polag(n+1,al,a)
3	w(i)=s*x(i)/(b*b)
	return
	end
	real*8 function lagnorm(n,al)	
	use factorials
	implicit real*8 (a-h,o-z)
c norm. coeff. for laguerre polynomials
	lal=al
	lagnorm=sqrt(exp(dlfac(n)-dlfac(n+lal)))
	return
	end

      subroutine rootlag(xs,x,eps,n,al)
c solution of eq. f(x)=0 by the newton method. eps shows the accuracy
c of the solution (see the program). the program calls the subr. fun which
c calculates f(y) and its derivative f1(y). xs is the starting value.
      implicit real*8 (a-h,o-z)
      y=xs
 1    continue
      call fun(f,f1,y,al,n)
      x=y-f/f1
c      print 2, x
 2    format(d24.14)
      a=dabs(x-y)
      if(a.lt.eps) go to 3
      y=x
      go to 1
 3    continue
      return
      end	
	
	subroutine fun(f,f1,y,al,n)
	implicit real*8 (a-h,o-z)
	f=polag(n,al,y)
	f1=-polag(n-1,al+1.d0,y)
	return
	end
	
	
	real*8 function polag(n,al,x)
	implicit real*8 (a-h,o-z)
calculates laguerre polynomials	
	a=1.d0
	if(n.eq.0) then
	   polag=a
	   return
	end if
	b=al+1.d0-x
	if(n.eq.1) then
	   polag=b
	   return
	end if
	do 1 i=2,n
	   c=((2.d0*i+al-1.d0-x)*b-(i+al-1.d0)*a)/i
	   a=b
1	   b=c
	polag=c
	return
	end
	real*8 function ekin(n1,n2,k)
c without h^2/(2m*b^2) factor
	implicit real*8 (a-h,o-z)
	real*8 lagnorm
	ma=max0(n1,n2)
	mi=min0(n1,n2)
	de=0.
	if(ma.eq.mi) de=1.
	f=lagnorm(ma,5.d0)/lagnorm(mi,5.d0)
	ekin=f*(.5d0-.25d0*de+mi/6.d0+
     &k*(k+4.d0)*(5.d0*(ma-mi+1.d0)+ma+mi+1.d0)/120.d0)
	return
	end      	


!------------------------------------------------------- MISC ROUTINES
	subroutine factorial(n)
! n>0
! ln(i!) and ln((2i+1)!)
	use factorials
	implicit real*8 (a-h,o-z)
	dlfac(0)=0.
	do 1 i=1,n 
	a=i
1	dlfac(i)=dlfac(i-1)+log(a)
	dl2fac(0)=0.d0
	do 2 i=1,n
	a=2.d0*i+1.d0
2	dl2fac(i)=dl2fac(i-1)+log(a)
	continue
	return
	end
      function ddexp(x)
      implicit doubleprecision(a-h,o-z)
      if(abs(x).gt.80.d0) x = sign(80.d0,x)
      ddexp=exp(x)
      return
      end


