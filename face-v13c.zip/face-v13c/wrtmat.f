      subroutine wrtmat (a,n,m,l,ncol)
      implicit integer (a-z)
      real*8 a
      data iout/ 6 /
      dimension a(l,*)
*
*     wrtmat : prints an n*m matrix stored in an l*l array
*
      ntim = m / ncol
      nf = 0
      if ( ntim .gt. 0 ) then
         do 20 i = 1, ntim
            ni = nf + 1
            nf = nf + ncol
            do 10 j = 1, n
               write (iout,1000) (a(j,k),k = ni,nf)
   10       continue
            write (iout,1010)
   20    continue
      endif
      ni = nf + 1
      if ( ni .le. m ) then
         do 40 j = 1, n
            write (iout,1000) (a(j,k),k = ni,m)
   40    continue
      endif
      return
*
 1000 format (7g16.7)
 1010 format (/)
      end
