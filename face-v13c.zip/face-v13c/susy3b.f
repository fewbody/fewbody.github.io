C###################################################################
C
      SUBROUTINE SUSY3B (KSTATE,NACH,NSUS,NMAX)

C    ***************************************************************
C    *** DELTA SUSY dSUSY(NMAX) AND SUSY TOTSUS(NMAX) potential
C    ***************************************************************
         use susycom

      IMPLICIT DOUBLEPRECISION (A-H,O-Z)

      INTEGER KSTATE(NACH)
cbd
c       real*8,save,allocatable::  dSUSY(:,:,:),
c     * WFINT(:),dSUSCL(:,:)
c     * TOTSUS(:,:,:),WFINT(:),dSUSCL(:,:)

      DOUBLEPRECISION  dSUSY(NACH,NACH,NMAX), 
     * WFINT(NMAX),dSUSCL(NACH,NMAX) 
c       DOUBLEPRECISION  TOTSUS(NACH,NACH,NMAX)
!       pause 'start'
      H2     = H   /2.D0
      NAC = NACH
      NM2     = RM  /H2
      NM1    = RM  /H
          write(4,*)'NM1,NAC,Nmax,NM2',NM1,NAC,Nmax,NM2
C
C *************************************************************************
C *************************************************************************
c	allocate(dSUSY(NAC,NAC,NM1)) 
c        allocate(WFINT(NM1),dSUSCL(NAC,NM1))

C *************************************************************************
C
C    *** INTEGRALS OF SQUARED WAVE FUNCTION
cls

!       pause 'start 2'
C
	 DO I=1,NM1

          WFINT(I) = 0.d0

	 ENDDO

         SUM = 0.
         WRITE(4,*)' RHO   WFINT(I)  '

!          pause 'SUSY 1'
        iiwf = 0.2/H

	  DO I=1,NM1

	    DO ICH=1,NACH
             SUM      = SUM + FUGS(ICH,I)**2
c         IF(FUGS(NACH,I).NE.0..and. I.lt.NM1)
c     *     ak=DLOG(dabs(FUGS(NACH,I+1)/FUGS(NACH,I)))/DLOG(((I+1)*1.d0)/
c     *            (I*1.d0))
	  ENDDO
             WFINT(I) = SUM
!      if(mod(I,10)==0) WRITE(4,'(G12.5,4X,4G12.3)')H*I ,WFINT(I),
!    * ( FUGS(IC,I),IC=1, NACH)
	 ENDDO
C
	  DO I=iiwf,NM1,iiwf

       WRITE(4,'(G12.5,4X,10G12.3)')H*I ,H*WFINT(I),
     * ( FUGS(IC,I),IC=1, NACH)
	 ENDDO
CC    *** DELTA SUSY AND SUSY
C		
!          pause 'SUSY 2'
	 DO ICH=1,NACH
	 DO I=1,NM1

           dSUSCL(ICH,I) = 2.*(2.*(KSTATE(ICH)) + 3.)/(I*H)**2

         ENDDO
         ENDDO
CC


C
C    *** DELTA SUSY AND SUSY, strict differential
C
	 DO ICH1=1,NACH
	 DO ICH2=1,NACH


	  DO I=4,NM1-2

           dSUSY(ICH1,ICH2,I) =-2./12.*((FUGS(ICH1,I-2)*FUGS(ICH2,I-2)
     *                         /WFINT(I-2)-
     *                  FUGS(ICH1,I+2)*FUGS(ICH2,I+2)/WFINT(I+2))-
     *              8.*(FUGS(ICH1,I-1)*FUGS(ICH2,I-1)/WFINT(I-1)-
     *                  FUGS(ICH1,I+1)*FUGS(ICH2,I+1)/WFINT(I+1)))/H**2

          ENDDO

         dSUSY(ICH1,ICH2,NM1-1) = 0.9*dSUSY(ICH1,ICH2,NM1-2)
         dSUSY(ICH1,ICH2,NM1) = 0.9*dSUSY(ICH1,ICH2,NM1-1)

          if(ICH1.le.NSUS .and. ICH2.le.NSUS)then
         dSUSY(ICH1,ICH2,3) = 16.d0/9.d0*dSUSY(ICH1,ICH2,4)
         dSUSY(ICH1,ICH2,2) = 9.d0/4.d0*dSUSY(ICH1,ICH2,3)
         dSUSY(ICH1,ICH2,1) = 9.d0*dSUSY(ICH1,ICH2,3)
          endif
          if(ICH1.gt.NSUS .or. ICH2.gt.NSUS)then

         do ii = 1,3
         x = ii*H
         n0 = 4
	x0 = H*n0
	x1 = H*(n0+1)
	x2 = H*(n0+2)
	x3 = H*(n0+3)

	y0 = dSUSY(ICH1,ICH2,n0)
	y1 = dSUSY(ICH1,ICH2,n0+1)
	y2 = dSUSY(ICH1,ICH2,n0+2)
	y3 = dSUSY(ICH1,ICH2,n0+3)

        A0 = (x-x1)*(x-x2)*(x-x3)/((x0-x1)*(x0-x2)*(x0-x3)) *y0
        A1 = (x-x0)*(x-x2)*(x-x3)/((x1-x0)*(x1-x2)*(x1-x3)) *y1
        A2 = (x-x0)*(x-x1)*(x-x3)/((x2-x0)*(x2-x1)*(x2-x3)) *y2
        A3 = (x-x0)*(x-x1)*(x-x2)/((x3-x0)*(x3-x1)*(x3-x2)) *y3

         dSUSY(ICH1,ICH2,ii)= A0 + A1 + A2 + A3
          ENDDO
          endif

          ENDDO
          ENDDO
!          pause 'SUSY 3'

CB	 DO I=4,NM1

CB           if(ABS(dSUSCL(I) / dSUSY(I) -1.d0) .lt. 1.d-2) go to 2

CB         ENDDO

CB   2      Ncl = I

C
C    *** correction of delta SUSY at small distances
c    *** on analytic expr.
C		

CB	 DO I=1,Ncl

CB           dSUSY(I) = dSUSCL(I) 

CB         ENDDO

C
C    *** Total SUSY 
C		
            ICC = 0
	 DO ICH1=1,NACH
	 DO ICH2=ICH1,NACH
            ICC = ICC + 1

          DO I=1,NM1

           TOTSUS(ICH1,ICH2,I) = VK(ICC,2*I) +
     *     dSUSY(ICH1,ICH2,I)/AH2
           TOTSUS(ICH2,ICH1,I) = TOTSUS(ICH1,ICH2,I)

          ENDDO
         ENDDO
         ENDDO
CC
!          pause 'SUSY 4'


C    *** PRINT OF SUSY AND SUSY
C		
c         WRITE(4,*)' RHO           DSUSY          dSUSCL    CL          TOTSUS      
c     *	   VVAL '

!         WRITE(4,*)' RHO           DSUSY          '
!
          istep = 0.2/H
!
!	  DO I=istep,NM1,istep
!          ic=0
!	 DO ICH1=1,NACH
!	 DO ICH2=1,NACH
!           ic = ic + 1
!          WFINT(IC) = dSUSY(ICH1,ICH2,I)
!         ENDDO
!         ENDDO
!         WRITE(4,'(G12.5,4X,8G12.3)')H*I,(WFINT(In),In=1,NACH*NACH)
!c     *                            (WFINT(In)*(H*I)**2,In=1,NACH*NACH)

!          ENDDO
!         WRITE(4,*)' RHO                   DSUSY*r**2 '
!	  DO I=istep,NM1,istep
!          ic=0
!	 DO ICH1=1,NACH
!	 DO ICH2=1,NACH
!           ic = ic + 1
!          WFINT(IC) = dSUSY(ICH1,ICH2,I)
!         ENDDO
!         ENDDO
!         WRITE(4,'(G12.5,4X,8G12.3)')H*I,
!     *                            (WFINT(In)*(H*I)**2,In=1,NACH*NACH)
!
!          ENDDO

c         WRITE(4,*)' RHO    dSUSCL                     CL           '
c	  DO I=1,NM1
c         WRITE(4,'(G12.5,4X,8G12.3)')H*I,(dSUSCL(In,I),In=1,NACH),
c     *                             (CL(In,2*I),In=1,NACH)

c          ENDDO

         WRITE(4,*)' RHO        TOTSUS       '!,' VVAL  '
	  DO I=istep,NM1,istep

          ic=0

	 DO ICH1=1,NACH
	 DO ICH2=ICH1,NACH

           ic = ic + 1

          WFINT(IC) = TOTSUS(ICH1,ICH2,I)
          WFINT(IC+NACH*(NACH+1)/2) = VK(ic,I*2)
         ENDDO
         ENDDO
         WRITE(4,'(G12.5,4X,12G12.3)')
     x         H*I,(WFINT(In),In=1,min(11,NACH*(NACH+1)/2))

          ENDDO

C *************************************************************************
c	deallocate(dSUSY,
c     & 	WFINT,dSUSCL)

C *************************************************************************
C
      RETURN
      END
		       
