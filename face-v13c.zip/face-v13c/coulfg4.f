      subroutine coulfg(xx,eta1,xlmin,xlmax, fc,gc,fcp,gcp,
     *                  mode1,kfn,ifail,m1)
c  revised ijt with l-t algorithmn for continued fractions
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c                                                                      c
c  revised coulomb wavefunction program using steed's method           c
c                                                                      c
c  a. r. barnett           manchester  march   1981                    c
c                                                                      c
c  original program 'rcwfn'      in    cpc  8 (1974) 377-395           c
c                 + 'rcwff'      in    cpc 11 (1976) 141-142           c
c  full description of algorithm in    cpc 21 (1981) 297-314           c
c  this version written up       in    cpc 27 (1982) 147-166           c
c                                                                      c
c  coulfg returns f,g,f',g', for real xx.gt.0,real eta1 (including 0), c
c   and real lambda(xlmin) .gt. -1 for integer-spaced lambda values    c
c   thus giving positive-energy solutions to the coulomb schrodinger   c
c   equation,to the klein-gordon equation and to suitable forms of     c
c   the dirac equation ,also spherical & cylindrical bessel equations  c
c                                                                      c
c  for a range of lambda values (xlmax - xlmin) must be an integer,    c
c  starting array element is m1 = max0(idint(xlmin+accur),0) + 1       c
c      see text for modifications for integer l-values                 c
c                                                                      c
c  if 'mode' = 1  get f,g,f',g'   for integer-spaced lambda values     c
c            = 2      f,g      unused arrays must be dimensioned in    c
c            = 3      f               call to at least length (1)      c
c  if 'kfn'  = 0 real        coulomb functions are returned            c
c            = 1 spherical   bessel      "      "     "                c
c            = 2 cylindrical bessel      "      "     "                c
c  the use of 'mode' and 'kfn' is independent                          c
c                                                                      c
c  precision:  results to within 2-3 decimals of 'machine accuracy'    c
c   in oscillating region x .ge. eta1 + sqrt(eta1**2 + xlm(xlm+1))     c
c   coulfg is coded for doubleprecision on ibm or equivalent  accur = 10**-16   c
c   use autodbl + extended precision on hx compiler  accur = 10**-33   c
c   for mantissas of 56 & 112 bits. for single precision cdc (48 bits) c
c   reassign dsqrt=sqrt etc.  see text for complex arithmetic version  c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c
      implicit doubleprecision (a-h,o-z)
      dimension    fc(101),gc(101),fcp(101),gcp(101)
      logical      etane0,xlturn
      common       /stee / paccq,nfp,npq,iexp,m1spare
c***  common block is for information only.  not required in code
c***  coulfg has calls to: dsqrt,dabs,dmod,idint,dsign,dmin1
      data zero,one,two,ten2,abort /0.0d0, 1.0d0, 2.0d0, 1.0d2, 2.0d4/
      data half,tm30 / 0.5d0, 1.0d-30 /
      data rt2dpi /0.79788 45608 02865 35587 98921 19868 76373 d0/
c *** this constant is  dsqrt(two/pi):  use q0 for ibm real*16: d0 for
c ***  doubleprecision & cdc double p:  e0 for cdc single p; and truncate value.
c
                        accur = 1.0d-16
c ***            change accur to suit machine and precision required
      mode  = 1
      if(mode1 .eq. 2 .or. mode1 .eq. 3 ) mode = mode1
      ifail = 0
      iexp  = 1
      npq   = 0
      eta   = eta1
      gjwkb = zero
      paccq = one
      if(kfn .ne. 0) eta = zero
                 etane0  = eta .ne. zero
      acc   = accur * 10d0
      acc4  = acc*ten2*ten2
      acch  = dsqrt(acc)
c ***    test range of xx, exit if.le.dsqrt(accur) or if negative
c
      if(xx .le. acch)                          go to 100
      x     = xx
      xlm   = xlmin
      if(kfn .eq. 2)  xlm = xlm - half
      if(xlm .le. -one .or. xlmax .lt. xlmin)   go to 105
      e2mm1 = eta*eta + xlm*xlm + xlm
      xlturn= x*(x - two*eta) .lt. xlm*xlm + xlm
      dell  = xlmax - xlmin + acc
      f = dmod(dell,one)
      if(dabs(f) .gt. acc4) write(6,2040)xlmax,xlmin,dell,f
      lxtra = idint(dell)
      xll   = xlm + lxtra
c ***       lxtra is number of additional lambda values to be computed
c ***       xll  is max lambda value, or 0.5 smaller for j,y bessels
c ***         determine starting array element (m1) from xlmin
      m1  = max0(idint(xlmin + acc),0) + 1
      l1  = m1 + lxtra
c
c ***    evaluate cf1  =  f   =  fprime(xl,eta,x)/f(xl,eta,x)
c
      xi  = one/x
      fcl = one
      pk  = xll + one
      px  = pk  + abort
      f   =  eta/pk + pk*xi
         if(dabs(f).lt.tm30) f = tm30
         d = zero
         c = f
c
c ***   begin cf1 loop on pk = k = lambda + 1
c
    4 pk1   = pk + one
        ek  = eta / pk
        rk2 = one + ek*ek
        tk  = (pk + pk1)*(xi + ek/pk1)
        d   =  tk - rk2 * d
        c   =  tk - rk2 / c
         if(dabs(c).lt.tm30) c = tm30
         if(dabs(d).lt.tm30) d = tm30
         d = one/d
         df = d * c
         f  = f * df
            if(d .lt. zero) fcl = - fcl
         pk = pk1
                          if( pk .gt. px ) go to 110
      if(dabs(df-one) .ge. acc)             go to 4
                  nfp = pk - xll - 1
      if(lxtra .eq. 0)                          go to 7
c
c *** downward recurrence to lambda = xlm. array gc,if present,stores rl
c
      fcl = fcl*tm30
      fpl = fcl*f
      if(mode .eq. 1) fcp(l1) = fpl
                      fc (l1) = fcl
      xl  = xll
      rl  = one
      el  = zero
      do 6  lp = 1,lxtra
         if(etane0) el = eta/xl
         if(etane0) rl = dsqrt(one + el*el)
         sl    =  el  + xl*xi
         l     =  l1  - lp
         fcl1  = (fcl *sl + fpl)/rl
         fpl   =  fcl1*sl - fcl *rl
         fcl   =  fcl1
         fc(l) =  fcl
         if(mode .eq. 1) fcp(l)  = fpl
         if(mode .ne. 3 .and. etane0) gc(l+1) = rl
    6 xl = xl - one
      if(fcl .eq. zero) fcl = acc
      f  = fpl/fcl
c ***    now we have reached lambda = xlmin = xlm
c ***    evaluate cf2 = p + i.q  again using steed's algorithm
c ***    see text for compact complex code for sp cdc or non-ansi ibm
c
    7 if( xlturn ) call jwkb(x,eta,dmax1(xlm,zero),fjwkb,gjwkb,iexp)
      if( iexp .gt. 1 .or. gjwkb .gt. one/(acch*ten2))  go to 9
          xlturn = .false.
      ta =  two*abort
      pk =  zero
      wi =  eta + eta
      p  =  zero
      q  =  one - eta*xi
      ar = -e2mm1
      ai =  eta
      br =  two*(x - eta)
      bi =  two
      dr =  br/(br*br + bi*bi)
      di = -bi/(br*br + bi*bi)
      dp = -xi*(ar*di + ai*dr)
      dq =  xi*(ar*dr - ai*di)
    8 p     = p  + dp
         q  = q  + dq
         pk = pk + two
         ar = ar + pk
         ai = ai + wi
         bi = bi + two
         d  = ar*dr - ai*di + br
         di = ai*dr + ar*di + bi
         c  = one/(d*d + di*di)
         dr =  c*d
         di = -c*di
         a  = br*dr - bi*di - one
         b  = bi*dr + br*di
         c  = dp*a  - dq*b
         dq = dp*b  + dq*a
         dp = c
         if(pk .gt. ta)                         go to 120
      if(dabs(dp)+dabs(dq).ge.(dabs(p)+dabs(q))*acc)   go to 8
                      npq   = pk/two
                      paccq = half*acc/dmin1(dabs(q),one)
                      if(dabs(p) .gt. dabs(q)) paccq = paccq*dabs(p)
c
c *** solve for fcm = f at lambda = xlm,then find norm factor w=w/fcm
c
      gam = (f - p)/q
c           if(q .le. acc4*dabs(p))             go to 130
            if(q .le. acc4*dabs(p))write(4,*) 'coulfg error:',
     *         ' q,p,xx,xlmin =',real(q),real(p),real(xx),xlmin
      w   = one/dsqrt((f - p)*gam + q)
            go to 10
c *** arrive here if g(xlm) .gt. 10**6 or iexp .gt. 70 & xlturn = .true.
    9 w   = fjwkb
      gam = gjwkb*w
      p   = f
      q   = one
c
c *** normalise for spherical or cylindrical bessel functions
c
   10                     alpha = zero
          if(kfn  .eq. 1) alpha = xi
          if(kfn  .eq. 2) alpha = xi*half
                          beta  = one
          if(kfn  .eq. 1) beta  = xi
          if(kfn  .eq. 2) beta  = dsqrt(xi)*rt2dpi
      fcm  = dsign(w,fcl)*beta
           fc(m1)  = fcm
                      if(mode .eq. 3)           go to 11
           if(.not. xlturn)   gcl =  fcm*gam
           if(      xlturn)   gcl =  gjwkb*beta
           if( kfn .ne. 0 )   gcl = -gcl
           gc(m1)  = gcl
           gpl =  gcl*(p - q/gam) - alpha*gcl
                      if(mode .eq. 2)           go to 11
           gcp(m1) = gpl
           fcp(m1) = fcm*(f - alpha)
   11 if(lxtra .eq. 0 ) return
c *** upward recurrence from gc(m1),gcp(m1)  stored value is rl
c *** renormalise fc,fcp at each lambda and correct regular derivative
c ***    xl   = xlm here  and rl = one , el = zero for bessels
         w    = beta*w/dabs(fcl)
         maxl = l1 - 1
      do 12 l = m1,maxl
                      if(mode .eq. 3)           go to 12
                      xl = xl + one
         if(etane0)   el = eta/xl
         if(etane0)   rl = gc(l+1)
                      sl = el + xl*xi
         gcl1     = ((sl - alpha)*gcl - gpl)/rl
         gpl      =   rl*gcl -  (sl + alpha)*gcl1
         gcl      = gcl1
         gc(l+1)  = gcl1
                      if(mode .eq. 2)           go to 12
         gcp(l+1) = gpl
         fcp(l+1) = w*(fcp(l+1) - alpha*fc(l+1))
   12 fc(l+1)     = w* fc(l+1)
      return
c
c ***    error messages
c
  100 ifail = -1
      write(6,2000) xx,acch
 2000 format(' for xx = ',1p,d12.3,' try small-x  solutions',
     *' or x negative'/ ,' square root accuracy parameter =  ',d12.3/)
      return
  105 ifail = -2
      write (6,2005) xlmax,xlmin,xlm
 2005 format(/' problem with input order values:xlmax,xlmin,xlm = ',
     *1p,3d15.6/)
      return
  110 ifail =  1
      write (6,2010) abort,f ,df,pk,px,acc
 2010 format(' cf1 has failed to converge after ',f10.0,' iterations',/
     *' f,df,pk,px,accur =  ',1p,5d12.3//)
      return
  120 ifail =  2
      write (6,2020) abort,p,q,dp,dq,acc
 2020 format(' cf2 has failed to converge after ',f7.0,' iterations',/
     *' p,q,dp,dq,accur =  ',1p,4d17.7,d12.3//)
      return
  130 ifail =  3
      write (6,2030) p,q,acc,dell,lxtra,m1
 2030 format(' final q.le.dabs(p)*acc*10**4 , p,q,acc = ',1p,3d12.3,4x,
     *' dell,lxtra,m1 = ',d12.3,2i5 /)
      return
 2040 format(' xlmax - xlmin = dell not an integer ',1p,4d17.10/)
      end
c
      subroutine jwkb(xx,eta1,xl,fjwkb,gjwkb,iexp)
      doubleprecision          xx,eta1,xl,fjwkb,gjwkb,dzero
c *** computes jwkb approximations to coulomb functions    for xl.ge. 0
c *** as modified by biedenharn et al. phys rev 97 (1955) 542-554
c *** calls dmax1,sqrt,alog,exp,atan2,float,int        barnett feb 1981
      data   zero,half,one,six,ten/ 0.0e0, 0.5e0, 1.0e0, 6.0e0, 10.0e0 /
      data  dzero, rl35, aloge  /0.0d0, 35.0e0, 0.43429 45 e0 /
      x     = xx
      eta   = eta1
      gh2   = x*(eta + eta - x)
      xll1  = dmax1(xl*xl + xl,dzero)
      if(gh2 + xll1 .le. zero) return
       hll  = xll1 + six/rl35
       hl   = sqrt(hll)
       sl   = eta/hl + hl/x
       rl2  = one + eta*eta/hll
       gh   = sqrt(gh2 + hll)/x
       phi  = x*gh - half*( hl*alog((gh + sl)**2/rl2) - alog(gh) )
          if(eta .ne. zero) phi = phi - eta*atan2(x*gh,x - eta)
      phi10 = -phi*aloge
      iexp  =  int(phi10)
      if(iexp .gt. 70) gjwkb = ten**(phi10 - float(iexp))
      if(iexp .le. 70) gjwkb = exp(-phi)
      if(iexp .le. 70) iexp  = 0
      fjwkb = half/(gh*gjwkb)
      return
      end
      function ihl1(l,x)
      implicit doubleprecision(a-h,o-z)
      doubleprecision ihl1,a(5)
      call sbfp(a,l,x)
      ihl1=exp(-x)*(a(1)+a(2)+a(3)+a(4))/a(5)
      return
      end
      subroutine sbfp(a,l,x)
      implicit doubleprecision(a-h,o-z)
      integer b
      dimension a(5),b(55)
      data b/3*1,2*3,1,2*15,6,1,2*105,45,10,1,2*945,420,105,15,1,
     1 2*10395,4725,1260,210,21,1,2*135135,62370,17325,3150,378,28,1,
     2 2*2027025,945945,270270,51975,6930,630,36,1,
     3 2*34459425,16216200,4729725,945945,135135,13860,990,45,1/
      if(l.lt.0.or.l.gt.9)go to 1
      l1=l+1
      do 4 j=1,4
    4 a(j)=0
      j=0
      k=(l*l1)/2
      x1=1.
      do 2 i=1,l1
      k=k+1
      j=j+1
      a(j)=b(k)*x1+a(j)
      if(j.eq.4) j=0
    2 x1=x1*x
      a(5)=x1
      return
    1 iout=6
      write(iout,3)l,x
    3 format(31h bessel routine called with l =,i5,8h and x =,e20.10)
      return
      end
      subroutine hankel(x,n,hkl)
      implicit doubleprecision(a-h,o-z)
      complex*16 hkl
      doubleprecision fc(20),gc(20),fcp(1),gcp(1)
      xl = n
      eta = 0.0
      call coulfg(x,eta,xl,xl,fc,gc,fcp,gcp,2,0,ifail,m1)
      hkl = cmplx(gc(m1),fc(m1))
      return
      end
