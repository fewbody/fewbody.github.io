	subroutine enumchs

! enumerates hyperangular & spin states for a general system
	use physics
	use work
	implicit real*8 (a-h,o-z)
	logical trace,ok
	real*8 jabv,jabv0
	integer kkmins(3)

	l1max=-1
	l2max=-1
	nmax=-1
	kkmin=-1
	kkmins(:)=10000

	do 200 iall=1,2
	trace = iall==1
	trace = .false.
	do 100 ib=1,3
	if(auto(ib)) then
!-------------------------------------Generate all partial waves up to limits
	l1inc=1
	i=0
	jabm(ib) = -1.
	    if(trace) write(6,*) ' Partition ',ib,': ',ns(ib),ns(pairs(1,ib)),ns(pairs(1,ib))
	do 23 icb=1,ns(ib)
	do 22 icb1=1,ns(pairs(1,ib))
	do 21 icb2=1,ns(pairs(2,ib))
	npty = jparity*parity(icb,ib)*parity(icb1,pairs(1,ib))*parity(icb2,pairs(2,ib))
	if(npty.eq.1)then 
		nn=0
	else
		nn=1
	endif
	 kkmax=-1
	 do l1=0,min(lxmax(ib),maxl)
	  kkmax = max(kkmax,kmax(l1,ib),kmaxa(ib))
	 enddo
	    if(trace) write(6,*) ' ib,icb,icb1,icb2,kkmax =',icb,icb1,icb2,kkmax
!	kkmax = maxval(kmax(0:min(lxmax(ib),maxl),ib))
	kmaxv = ((kkmax-nn)/2)*2 + nn
	kmin =  max(kkmin,nn)
!						Start loops on quantum numbers:
	 jabv0 =abs(jtot-spin(icb,ib)) 
	 njab = nint(min(jtot+spin(icb,ib),jabmax(ib)) - jabv0)
	    if(trace) write(6,*) ' min jab, # jab =',jabv0,njab
	do 20 ijabv=0,njab
	 jabv = jabv0 + ijabv
	    if(trace) write(6,*) ' jab =',jabv
	    if(trace) write(6,*) ' min k, max k =',kmin,kmaxv
	do 15 k=kmin,kmaxv,2
     		if(trace) write(6,*) ' k =',k 
	  s0=   abs(spin(icb1,pairs(1,ib))-spin(icb2,pairs(2,ib)))
	  smax =    spin(icb1,pairs(1,ib))+spin(icb2,pairs(2,ib))
	  nss = nint( min(smax,sxmax(ib)) - s0)
	    if(trace) write(6,*) ' min s, # s =',s0,nss
	do 14 is=0,nss
	  s = s0 + is
	    if(trace) write(6,*) ' s =',s
	    if(trace) write(6,*) ' min L, max L =',nint(abs(s-jabv)),nint(s+jabv)
	do 13 n=0,k/2
	  l1mx=min(k-2*n,lxmax(ib),maxl)
	do 12 l1=0,l1mx,l1inc
	  l2=k-l1-2*n
	    if(trace) write(6,*) ' l1,l2 =',l1,l2
	        ok = k.le.kmax(l1,ib) .or. (kmax(l1,ib)<0.and.k.le.kmaxa(ib))
		if(.not.ok) goto 12
	        if(id(ib).and.mod(nint(l1+s+iso(ib)),2)==0) go to 12
	        if(l2.lt.0.or.l2.gt.lymax(ib)) go to 12
	  lmin = max(nint(abs(jabv-s)) , abs(l1-l2))
	  lmax = min(nint(jabv+s)      ,     l1+l2 , ltmax(ib))
	    if(trace) write(6,*) ' min L, max L =',lmin,lmax
	do 11 l=lmin,lmax
	    if(trace) write(6,*) ' L =',l
	   i=i+1
	    if(trace) write(6,*) ' Found i,k,l,l1,l2,s,jabv =',i,k,l,l1,l2,s,jabv
	  if(id(ib)) kkmins(ib) = min(kkmins(ib),k)
	  if(iall==2) then
	   kk(i,ib)=k
	   lltot(i,ib)=l
	   ll1(i,ib)=l1
	   ll2(i,ib)=l2
	   ssx(i,ib)=s
	   jab(i,ib)=jabv
	   ii(i,1,ib)=icb
	   ii(i,2,ib)=icb1
	   ii(i,3,ib)=icb2
	      l1max=max(l1max,l1)
	      l2max=max(l2max,l2)
	      nmax =max(nmax ,(k - ll1(i,ib)-ll2(i,ib))/2)
	      jabm(ib) =max(jabm(ib),jabv)
	   endif
10	continue
11	continue
12	continue
13	continue
14	continue
15	continue
20	continue
21	continue
22	continue
23	continue
	else
!-------------------------------------Generate partial waves from allowed list
	 kkmax=-1
	 do ich=1,nc(ib)
	  kkmax = max(kkmax,lx(ich,ib)+ly(ich,ib)+2*np(ich,ib))
	 enddo
	i=0
	do 60 ich=1,nc(ib)
	do 50 k=lx(ich,ib)+ly(ich,ib),kkmax,2
	  if(k<=lx(ich,ib)+ly(ich,ib)+2*np(ich,ib)) then
	   i=i+1
	  if(iall==2) then
	   kk(i,ib)=k
	   lltot(i,ib)=lt(ich,ib)
	   ll1(i,ib)=lx(ich,ib)
	   ll2(i,ib)=ly(ich,ib)
	   ssx(i,ib)=sx(ich,ib)
	   jab(i,ib)=jp(ich,ib)
	   ii(i,1,ib)=icy(ich,ib)
	   ii(i,2,ib)=icx1(ich,ib)
	   ii(i,3,ib)=icx2(ich,ib)
	      l1max=max(l1max,ll1(i,ib))
	      l2max=max(l2max,ll2(i,ib))         
	      nmax =max(nmax ,(k - ll1(i,ib)-ll2(i,ib))/2)
	   endif
	  endif
50	continue
60	continue
	endif
	imax(ib)=i
100	continue
	imax0(1)=0
	imax0(2)=imax(1)
	imax0(3)=imax0(2)+imax(2)
	if(iall==1) then
	 imaxx = max(imax(1),imax(2),imax(3))
	 imaxs =     imax(1)+imax(2)+imax(3)
	 kkmin = minval(kkmins(1:3))
	 if(kkmin>100) kkmin = 0
	 write(6,*) ' Faddeev channel numbers required:',imax
	 if(kkmin>0) write(6,*) ' Global Kmin = ',kkmin,' from isospin'
	 allocate (kk(imaxs,3),lltot(imaxs,3),ll1(imaxs,3),ll2(imaxs,3),ifo(imaxs,3))
	 allocate (ssx(imaxs,3),jab(imaxs,3),ii(imaxs,3,3),iba(imaxs),ieo(imaxs,3))
	 allocate (kkh(imaxs),iih(imaxs,3),ibh(imaxs))
	endif
200	continue
      	do ib=1,3
      	do i1=1,imax(ib),16
        nchl = min(i1+15,imax(ib))
	write(6,1480)
	write(6,*) sym(ib)//':'
	write(6,1480)'ig',ib,(mod(i+imax0(ib),10000),i=i1,nchl)
	write(6,1480)'i',ib,(mod(i,10000),i=i1,nchl)
	write(6,1480)'K',ib,(kk(i,ib),i=i1,nchl)
     	write(6,1480)'L',ib,(lltot(i,ib),i=i1,nchl)
     	write(6,1481)'sx',ib,(ssx(i,ib),i=i1,nchl)
	write(6,1480)'lx',ib,(ll1(i,ib),i=i1,nchl)
 	write(6,1480)'ly',ib,(ll2(i,ib),i=i1,nchl)
 	write(6,1481)'jp',ib,(jab(i,ib),i=i1,nchl)
        if(ns(ib)>1) write(6,1480)'iy',ib,(ii(i,1,ib),i=i1,nchl)
        if(ns(pairs(1,ib))>1) write(6,1480)'ix',ib,(ii(i,2,ib),i=i1,nchl)
        if(ns(pairs(2,ib))>1) write(6,1480)'iz',ib,(ii(i,3,ib),i=i1,nchl)
	enddo
      	enddo
 1480   format(1x,a2,i2,16i4,:,/(2x,i2,16i4))	
 1481   format(1x,a2,i2,16f4.1,:,/(2x,i2,16f4.1))	
	do i=1,imax(1)
	 iba(i) = 1
	enddo
	do 400 ib=2,3
	do 390 i=1,imax(ib)
	 j = imax0(ib)+i
	 kk(j,1) = kk(i,ib)
	 lltot(j,1) = lltot(i,ib)
	 ssx(j,1) = ssx(i,ib)
	 ll1(j,1) = ll1(i,ib)
	 ll2(j,1) = ll2(i,ib)
	 jab(j,1) = jab(i,ib)
	 do ic=1,3
	  ii(j,ic,1) = ii(i,ic,ib)
	 enddo
	 iba(j) = ib
390	continue
400	continue
!	jabmax(:) = jabm(:)
	write(10,*) 'Enumchs done'
	return
	end
