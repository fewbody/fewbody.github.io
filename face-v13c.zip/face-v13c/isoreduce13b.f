      subroutine isoreduce
                                                                       
        use physics
        use work
        use methodspec
      implicit double precision (A-H,O-Z)
      logical PR,PRT
      parameter(ONE=1d0, ZERO=0d0, PRT=.false.,PR=.true.)
	real*8 w(imaxs,imaxs),perm2(imaxs)
	
	print *,' eqn,id(:)=',eqn,id
       if(.not.(id(1).or.id(2).or.id(3))) return

C
C	Eliminate isospin mirror partitions

	do 500 ip=1,3
	iq = mod(ip,3)+1
	ir = mod(ip+1,3)+1
	if(id(ip)) then
C				Eliminate iq in favour of ir
 	write(6,10) iq,ir
10	format(/' Particles ',i1,' and ',i1,' are identical')
	if(imax(iq)>0.and.imax(ir)>0) then
 	write(6,*) ' so eliminate basis ',iq,' in favour of ',ir
	if(imax(iq).ne.imax(ir)) then
	  write(6,*) ' Bases must be of identical structure!'
	  stop
	  endif
        perm2(:) = 0
	do i=1,imax(ir)
	ix = i+imax0(ir)
!	do j=1,imax(iq)  ! sum over & eliminate
	j=i
	iy = j+imax0(iq)
	if(kk(i,ir)==kk(j,iq).and.ll1(i,ir)==ll1(j,iq).and.
     x     ll2(i,ir)==ll2(j,iq).and.lltot(i,ir)==lltot(j,iq).and.
     x     abs(jab(i,ir)-jab(j,iq))<1e-5) then
            sxx=ssx(i,ir)
!                                          c=spectator, a+b interacting
	    ajt=spin(ii(i,2,ir),pairs(1,ir))
	    bjt=spin(ii(i,3,ir),pairs(2,ir))
	   perm2(iy) = (-1)**nint(ll1(i,ir) + ssx(i,ir) - ajt - bjt)
	 endif
!		write(50,*) ix,iy,iz,coef,perm2(iy)
	enddo
	perm2(:) = - perm2(:) * (-1)**nint(iso(ip)-0.5-0.5)
	write(10,*) '  Isospin permutation coefficients:'
	do j=1,imax(iq)
	 iy = j+imax0(iq)
     	write(10,791) iy,perm2(iy)
	enddo
	call flush(10)
!	call flush(50)
 791	format(1x,i3,24f4.0,:,/(4x,24f4.0))

	do i=1,imax(ir)
	ix = i+imax0(ir)   ! k
!	do j=1,imax(iq)  ! sum over & eliminate
	j = i
	iy = j+imax0(iq)   ! j

	do k=1,imax(ip)
	iz = k+imax0(ip)   ! i
         wn1(iz,ix) = wn1(iz,ix) + wn1(iz,iy)*perm2(iy)
!         write(10,*) 'Wn1(',iz,ix,')+=wn1(',iz,iy,')*perm(',iy,ix,')'
        enddo

	do j=1,imax(iq)  ! sum over & eliminate
	iy = j+imax0(iq)   ! j
!	do i2=1,imax(ir)
	i2 = j
	ix2 = i2+imax0(ir)   ! k'
         wn1(ix,ix2) = wn1(ix,ix2) + wn1(ix,iy)*perm2(iy)
!         write(10,*) 'wn1(',ix,ix2,')+=wn1(',ix,iy,')*perm(',iy,ix2,')'
	enddo
	
	enddo
 	wn1(1+imax0(ir):imax(ir)+imax0(ir),:) = 
     X      2*wn1(1+imax0(ir):imax(ir)+imax0(ir),:) 

	nb = imax(ip)+imax(ir)
        nd = imax(iq)

C	Compact wn1 and ww arrays:
	if(iq==3) then
C			do nothing
	else if(iq==1) then
C			Move 2 other coefficients down by # deleted channels
!	  imax0(ip) = imax0(ip)-nd
!	  imax0(ir) = imax0(ir)-nd

          wn1(:,1:nb) = wn1(:,nd+1:nd+nb)  ! move left by nd
          wn1(1:nb,:) = wn1(nd+1:nd+nb,:)  ! move up by nd

        else if(iq==2) then
C			Move upper channel set iz down by nd next to iy
	  iy = min(ip,ir); ny=imax(iy)
	  iz = max(ip,ir); nz1=1+imax0(iz)
	  
          wn1(1:ny,1+ny:nb) = wn1(1:ny,nz1:imaxs)  ! upper rhs
          wn1(1+ny:nb,1:ny) = wn1(nz1:imaxs,1:ny)  ! lower lhs
          wn1(1+ny:nb,1+ny:nb) = wn1(nz1:imaxs,nz1:imaxs)  ! lower rhs

 	endif
C   Adjust WW arrays:
	rewind iwf
	iwn = 121-iwf
	rewind iwn
        open(iwn,access='sequential',status='scratch',
     x            form='unformatted')
	write(10,*)  'ip,iq,ir =',ip,iq,ir
 	write(10,10) iq,ir
 	write(10,*) ' so eliminate basis ',iq,' in favour of ',ir
	write(10,200)  imax0(ip)+1,imax0(ip)+imax(ip),
     x	               imax0(ir)+1,imax0(ir)+imax(ir),
     x	               imax0(ip)+1,imax0(ip)+imax(ip),
     x	               imax0(iq)+1,imax0(iq)+imax(iq)
	write(10,200)  imax0(ir)+1,imax0(ir)+imax(ir),
     x	               imax0(ir)+1,imax0(ir)+imax(ir),
     x	               imax0(ir)+1,imax0(ir)+imax(ir),
     x	               imax0(iq)+1,imax0(iq)+imax(iq)
200     format(/' ww(',i4,':',i4,',',i4,':',i4,') = * + ',
     x           'ww(',i4,':',i4,',',i4,':',i4,') * perm'/)

	do il=1,nlag
	read(iwf) ww(1:imaxs,1:imaxs)

	do i=1,imax(ir)
	ix = i+imax0(ir)   ! k
!	do j=1,imax(iq)  ! sum over & eliminate
	j = i
	iy = j+imax0(iq)   ! j

	do k=1,imax(ip)
	iz = k+imax0(ip)   ! i
         ww(iz,ix) = ww(iz,ix) + ww(iz,iy)*perm2(iy)
        enddo

	do j=1,imax(iq)  ! sum over & eliminate
	iy = j+imax0(iq)   ! j
!	do i2=1,imax(ir)
  	i2 = j
	ix2 = i2+imax0(ir)   ! k'
         ww(ix,ix2) = ww(ix,ix2) + ww(ix,iy)*perm2(iy)
	 enddo
	
	enddo

C	Compact wn1 and ww arrays:
	if(iq==3) then
C			do nothing
	else if(iq==1) then
C			Move 2 other coefficients down by # deleted channels
          ww(:,1:nb) = ww(:,nd+1:nd+nb)
          ww(1:nb,:) = ww(nd+1:nd+nb,:)

        else if(iq==2) then
C			Move upper channel set iz down by nd next to iy
	  iy = min(ip,ir); ny=imax(iy)
	  iz = max(ip,ir); nz1=1+imax0(iz)
	  
          ww(1:ny,1+ny:nb) = ww(1:ny,nz1:imaxs)  ! upper rhs
          ww(1+ny:nb,1:ny) = ww(nz1:imaxs,1:ny)  ! lower lhs
          ww(1+ny:nb,1+ny:nb) = ww(nz1:imaxs,nz1:imaxs)  ! lower rhs
 	endif
 	
 	write(iwn) WW(1:nb,1:nb)
 	enddo !il=1,NLAG
            close(iwf,status='delete')
	iwf = iwn
         imax(iq) = 0
         imax0(iq)= 0
	if(iq==1) then
	  imax0(ip) = imax0(ip)-nd
	  imax0(ir) = imax0(ir)-nd
	else if(iq==2) then
	  iz = max(ip,ir)
	  imax0(iz) = imax0(iz)-nd
	  endif

C 			 Make new single order of all channels
	do i=1,imax(1)
	 iba(i) = 1
	enddo
	do 400 ib=2,3
	do 390 i=1,imax(ib)
	 j = imax0(ib)+i
	 kk(j,1) = kk(i,ib)
	 lltot(j,1) = lltot(i,ib)
	 ssx(j,1) = ssx(i,ib)
	 ll1(j,1) = ll1(i,ib)
	 ll2(j,1) = ll2(i,ib)
	 jab(j,1) = jab(i,ib)
	 do ic=1,3
	  ii(j,ic,1) = ii(i,ic,ib)
	 enddo
	 iba(j) = ib
390	continue
400	continue
	
	imaxs = nb
	if(PR)
     x	write(6,*) ' Hamiltonian reduced to ',NB,' channels by isospin'
	if(PRT) write(6,*) ' kkr:',(kk(I,1),I=1,NB)
	if(PRT) write(6,*) ' iir:',(ii(I,1:3,1),I=1,NB)
	
	write(6,*) ' New Isospin Basis:'
      	do i1=1,imaxs,16
        nchl = min(i1+15,imaxs)
	write(6,1480)
	write(6,1480)'i',(mod(i,1000),i=i1,nchl)
	write(6,1480)'K',(kk(i,1),i=i1,nchl)
        write(6,1480)'iy',(ii(i,1,1),i=i1,nchl)
        write(6,1480)'ix',(ii(i,2,1),i=i1,nchl)
        write(6,1480)'iz',(ii(i,3,1),i=i1,nchl)
	write(6,1481)'ic',(sym(iba(i)),i=i1,nchl)
	enddo
 1480   format(1x,a2,2x,16i4,:,/(2x,i2,16i4))	
 1481   format(1x,a2,2x,16(3x,a1),:,/(2x,i2,16(3x,a1)))	

        endif
        endif
  500   continue
	RETURN
	END
