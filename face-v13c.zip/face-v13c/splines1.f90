      subroutine splines(ny,a,b)
!***********************************************************************
!             spline coefficients
!***********************************************************************
      implicit real*8(a-h,o-z)
      real*8 a(0:ny+2,0:ny),b(0:ny,0:ny)

!
      null=0
      do 100 i=1,ny
      do 90 j=1,ny
      b(i,j)=0.
   90 continue
      a(i,1)=2.
      b(i,i)=1.
  100 continue
      do 120 i=2,ny
      auxi=-.5/a(i-1,1)
      a(i,1)=a(i,1)+.5*auxi
      jj=i-1
      do 110 j=1,jj
      b(i,j)=auxi*b(i-1,j)
  110 continue
  120 continue
      do 140 ii=1,ny
      i=ny+1-ii
      do 130 j=1,ny
      s=b(i,j)
                 if(i.ne.ny) s=s-.5*b(i+1,j)
      b(i,j)=s/a(i,1)
  130 continue
  140 continue
!
      do 160 i=1,ny
             a(ny+1,i)=0.
      a(null,i)=a(ny+1,i)
      do 150 j=1,ny
      a(i,j)=-b(i,j)
      if(j.ne.1 ) a(i,j)=a(i,j)+b(i,j-1)*.5
      if(j.ne.ny) a(i,j)=a(i,j)+b(i,j+1)*.5
  150 continue
  160 continue
!     write(4,*) 'spline coefficients'
!     do 163 j=1,ny
!     write(4,*) j
!     write(4,161) (a(iy,j),iy=1,ny)
! 161 format('#',15f8.4)
! 163 continue
!
      return
      end
