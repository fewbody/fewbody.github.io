      subroutine reduce
                                                                       
        use physics
        use methodspec
        use work
      implicit double precision (A-H,O-Z)
      dimension wwl(imaxs,imaxs)
      logical PR,PRT,BLAS
      parameter(ONE=1d0, ZERO=0d0, PRT=.false.,BLAS=.true.,PR=.true.)
	
C	Fold Hamiltonian  array and reduce arrays if reqd
C       -------------------------------------------------

	if(init==0)  then
C************************************ Keep Faddeev basis
	   imaxr = imaxs
	   kkh(:) = kk(:,1)
	   ibh(:) = iba(:)
	   iih(:,1:3) = ii(:,1:3,1)
	   return

	else if(init>0) then
C************************************ Start orthonormal basis with set init
C			Convert to Reduced-orthonormal-basis for Faddeev 
	allocate (ctn(imaxs,imaxs), dtn(imaxs,imaxs))
	eps = 1d-5
            if(PRT) call printm ('WN1 ',WN1,imaxs,imaxs,mchan,10)
        call tnbasis(imaxs,init,iba,WN1,mchan,ctn,imaxs,dtn,imaxs,
     X			imax,imax0,reduced,eps,NB,PR)
	if(PR) write(6,*) ' The number of orthoNormal channels =',NB
	if(PRT) then
            call printm ('ctn ',ctn,imaxs,NB ,imaxs,10)
            call printm ('dtn ',dtn,NB ,imaxs,imaxs,10)
	    call dgemm ('n','n',NB,NB,imaxs,ONE,dtn,imaxs,ctn,imaxs,
     X			ZERO,WWL,imaxs)
            call printm ('D*C ',WWL,NB,NB,imaxs,10)
	 endif

	imaxr=NB

	 rewind iwf
	 iwn=121-iwf
	 rewind iwn
	 open(iwn,access='sequential',status='scratch',
     x            form='unformatted')

	 do 350 J=1,NLAG
	 read(iwf) WW(1:imaxs,1:imaxs)
	 call dgemm ('n','n',NB,imaxs,imaxs,ONE,dtn,imaxs,
     X			WW(1,1),mchan,ZERO,WWL,imaxs)
	 call dgemm ('n','n',NB,NB,imaxs,ONE,WWL,imaxs,ctn,imaxs,
     X			ZERO,WW(1,1),mchan)
	 write(iwn) WW(1:imaxr,1:imaxr)
350	 continue
		write(10,*) 'imaxs,mchan,imaxr =',imaxs,mchan,imaxr
		close(iwf,status='delete')
		iwf = iwn
            if(PRT) call printm ('DWC ',WW(1,1),imaxs,imaxs,mchan,10)
	
	 do 580 I=1,NB
C			Find K and core states of new orthonormal channels:
	  do 555 I1=1,imaxs
555	  if(ctn(I1,I).ne.0d0) go to 558
	  write(6,*) '''Orthonormal'' state ',I,' all zero!!!??'
558	  kkh(i) = kk(i1,1)
	  iih(i,1:3) = ii(i1,1:3,1)
	  ibh(i) = iba(i1)		! ibh records partition in
					! which ii is defined
	  if(PRT) write(6,*) 'Using ch',I1,' to find K,core for ',I
580	 continue

	if(PR)
     x	write(6,*) ' Hamiltonian reduced to ',NB,' orthoNormal channels'
	if(PRT) write(6,*) ' kkh:',(kkh(I),I=1,NB)
	if(PRT) write(6,*) ' iih:',(iih(I,1:3),I=1,NB)
	endif
	write(6,*) ' New OrthoNormal Basis:'
      	do i1=1,imaxr,16
        nchl = min(i1+15,imaxr)
	write(6,1480)
	write(6,1480)'i',(mod(i,1000),i=i1,nchl)
	write(6,1480)'K',(kkh(i),i=i1,nchl)
        write(6,1480)'iy',(iih(i,1),i=i1,nchl)
        write(6,1480)'ix',(iih(i,2),i=i1,nchl)
        write(6,1480)'iz',(iih(i,3),i=i1,nchl)
	write(6,1481)'ic',(sym(ibh(i)),i=i1,nchl)
	enddo
 1480   format(1x,a2,2x,16i4,:,/(2x,i2,16i4))	
 1481   format(1x,a2,2x,16(3x,a1),:,/(2x,i2,16(3x,a1)))	
	RETURN
	END

	subroutine tnbasis(n,init,iba,wn1,mchan,ctn,nctn,dtn,ndtn,
     x			   imax,imax0,reduced,thresh,nb,PR)
	implicit real*8(a-h,o-z)
	dimension wn1(mchan,n),ctn(nctn,n),null(n),dtn(ndtn,n),iba(n),
     X  	  imax(3),imax0(3),xov(n)
        PARAMETER ( ZERO=0.0D0,ONE=1.D0)
	logical PR,reduced

************  Construct orthonormal basis by Gramm-Schmidt,
************  using norm matrix wn1
************  put new basis in *columns* of ctn
	nu = 0
	nb = 0
************  starting with the imax(init) basis found from imax0(init)...
	nb = imax(init)
	do 6 i=1,nb
	 do 5 k=1,n
5	 ctn(k,i)  = ZERO
6	 ctn(i+imax0(init),i) = ONE
	if(reduced) then
	   do i=nb+1,n
	   null(i-nb)=i
	   enddo
	   go to 105
	   endif

	do 100 i=nb+1,n
	 do 10 k=1,n
10	 ctn(k,i)  = ZERO
	 ctn(i-imax(init),i) = ONE
c			Subtract overlaps with previous basis states:
	 do 20 j=1,nb
!	   xo = ZERO
!	   do 15 m=1,n
!15	   xo = xo + wn1(m,i-imax(init))*ctn(m,j)
	   xo = ddot(n,wn1(1,i-imax(init)),1,ctn(1,j),1)
20	   xov(j) = xo
	 do 30 k=1,n
	   x1 = ZERO
	 do 21 j=1,nb
21	   x1 = x1 + xov(j) * ctn(k,j)
30	  ctn(k,i) = ctn(k,i) - x1
c
c			Find norm of orthogonalised state:
	 xn = ZERO
	 do 40 ip=1,n
	 do 40 iq=1,n
40	 xn = xn + ctn(ip,i)*wn1(ip,iq)*ctn(iq,i)
	write(10,*) 'Orthogonalised TN state',i,' has norm',real(xn),
     x			' -> ',nb+1
	if(abs(xn).lt.thresh)  then
		nu = nu+1
		null(nu) = i
		if(abs(xn).gt.thresh**2)
     x		write(6,*) 'Proposed orthoNormal channel omitted, as ',
     x		 'norm only',real(xn)
		go to 100
	    endif
	if(xn.lt.-thresh)  then
      	    write(6,*) ' CHANNEL NEGATIVE NORM',xn,', DEEP TROUBLE!'
      	    write(6,*) ' AT i=',i,', strange vector is :'
	    write(6,'(1x,10f8.4)') (ctn(ip,i),ip=1,n)
	    xn = 0.
	    do 45 ip=1,n
	    do 45 iq=1,n
   	    x1 = ctn(ip,i)*wn1(ip,iq)*ctn(iq,i)
	    xn = xn + x1
   45	    if(abs(x1)>1e-9) write(6,46) ip,iq,
     x                       ctn(ip,i),wn1(ip,iq),ctn(iq,i),x1,xn
   46       format(' at ',2i3,' product ',3f8.4,' gives ',2f9.5)
	    stop 'REDUCE'
	    endif

!	write(50,*) 'sqrt(',xn,')'
	xn = ONE/sqrt(xn)
	nb = nb+1
c			Normalise if possible, and copy into next slot.
	do 50 k=1,n
50	ctn(k,nb) = ctn(k,i) * xn
100	continue
105	continue
!      if(PR) write(6,*) ' Only ',nb,' linearly independent channels'
c			Fill up column vectors with units on null rows
	do 120 i=nb+1,n
	 do 110 k=1,n
110	 ctn(k,i) = ZERO
120	 ctn(null(i-nb),i) = ONE

c 	Now find inverse transformation:  dtn = ctn^T . wn1
	 call dgemm ('t','n',n,n,n,ONE,ctn,nctn,wn1,mchan,
     X			ZERO,dtn,ndtn)

	return
 1100 format (' tnbasis : error return from dgetrf, info = ',i6)
 1110 format (' tnbasis : error return from dgetrs, info = ',i6)
	end
      subroutine mprint ( name, a, n, m, nmax , iout)
      implicit integer (a-z)
      double precision a
      character*4 name
      dimension a(nmax,m)
*
*     mprint -- prints a real matrix a(n,m)
*		name	  -- 4 character identification
*		a(nmax,m) -- array to be printed
*		n	  -- number of rows to be printed
*		m	  -- number of columns to be printed ( .le. 10 )
*		nmax	  -- row dimension of a
*
      write (iout,1000) name, (a(1,i), i = 1, m)
      if ( n .gt. 1 ) then
	 do 10 i = 2, n
	    write (iout,1010) (a(i,j), j = 1, m )
   10	 continue
      endif
      return
*
c1000 format ( '0', a4, 2x, 10g12.4 )
c1010 format ( 7x, 10g12.4 )
c1000 format (  / , a4, 2x, 10f9.5 )
c1010 format ( 6x, 10f9.5 )
c1000 format (  / , a4, 2x, 12f8.4 )
c1010 format ( 6x, 12f8.4 )
 1000 format (  / , a4, 2x, 12f7.3 )
 1010 format ( 6x, 12f7.3 )
      end
      subroutine printm (name,array,n,m,nmax,ifl)
      implicit integer (a-z)
      double precision array
      character*4 name,namec
      dimension array(*)
*
*     printm -- driver for mprint
*
      namec(1:4) = name(1:4)
      nh = 1
      mp = 10
      mp = 12
      i = 0
      iz = ichar('0')
      do 10 nl = m, 1, -mp
         nc = min( nl, mp )
         call mprint (namec,array(nh),n,nc,nmax,ifl)
         i = i + 1
         namec(4:4) = char(iz+mod(i,10)) 
         nh = nh + nmax * nc
   10 continue
      end
