      subroutine f02amf(n,eps,d,e,z,iz,ifail)
c     mark 14 re-issue.  nag copyright 1989.
c
c     tql2
c     this subroutine finds the eigenvalues and eigenvectors of a
c     tridiagonal matrix, t, given with its diagonal elements in
c     the array d(n) and its sub-diagonal elements in the last n
c     - 1 stores of the array e(n), using ql transformations. the
c     eigenvalues are overwritten on the diagonal elements in the
c     array d in ascending order. the eigenvectors are formed in
c     the array z(n,n), overwriting the accumulated
c     transformations as supplied by the subroutine f01ajf. the
c     subroutine will fail if all eigenvalues take more than 30*n
c     iterations.
c     1st april 1972
c
c     .. parameters ..
      integer           vlen
      parameter         (vlen=128)
      character*6       srname
      parameter         (srname='f02amf')
c     .. scalar arguments ..
      double precision  eps
      integer           ifail, iz, n
c     .. array arguments ..
      double precision  d(n), e(n), z(iz,n)
c     .. local scalars ..
      double precision  b, c, f, g, h, p, r, s
      integer           i, i1, ipos, isave, iseg, j, k, l, m
c     .. local arrays ..
      double precision  cc(vlen), ss(vlen)
      character*1       p01rec(1)
c     .. external functions ..
      integer           p01abf
      external          p01abf
c     .. external subroutines ..
      external          f06qxf
c     .. intrinsic functions ..
      intrinsic         abs, max, sqrt
c     .. executable statements ..
      isave = ifail
      if (n.eq.1) go to 40
      do 20 i = 2, n
         e(i-1) = e(i)
   20 continue
   40 e(n) = 0.0d0
      b = 0.0d0
      f = 0.0d0
      j = 30*n
      do 300 l = 1, n
         h = eps*(abs(d(l))+abs(e(l)))
         if (b.lt.h) b = h
c        look for small sub-diag element
         do 60 m = l, n
            if (abs(e(m)).le.b) go to 80
   60    continue
   80    if (m.eq.l) go to 280
  100    if (j.le.0) go to 400
         j = j - 1
c        form shift
         g = d(l)
         h = d(l+1) - g
         if (abs(h).ge.abs(e(l))) go to 120
         p = h*0.5d0/e(l)
         r = sqrt(p*p+1.0d0)
         h = p + r
         if (p.lt.0.0d0) h = p - r
         d(l) = e(l)/h
         go to 140
  120    p = 2.0d0*e(l)/h
         r = sqrt(p*p+1.0d0)
         d(l) = e(l)*p/(1.0d0+r)
  140    h = g - d(l)
         i1 = l + 1
         if (i1.gt.n) go to 180
         do 160 i = i1, n
            d(i) = d(i) - h
  160    continue
  180    f = f + h
c        ql transformation
         p = d(m)
         c = 1.0d0
         s = 0.0d0
         do 260 k = m - 1, l, -vlen
            iseg = max(k-vlen+1,l)
            do 240 i = k, iseg, -1
               g = c*e(i)
               h = c*p
               if (abs(p).lt.abs(e(i))) go to 200
               c = e(i)/p
               r = sqrt(c*c+1.0d0)
               e(i+1) = s*p*r
               s = c/r
               c = 1.0d0/r
               go to 220
  200          c = p/e(i)
               r = sqrt(c*c+1.0d0)
               e(i+1) = s*e(i)*r
               s = 1.0d0/r
               c = c/r
  220          p = c*d(i) - s*g
               d(i+1) = h + s*(c*g+s*d(i))
c           store rotations
               cc(vlen-k+i) = c
               ss(vlen-k+i) = -s
  240       continue
c        update vectors
            ipos = vlen - k + iseg
            call f06qxf('right','variable','backward',n,k-iseg+2,1,
     *                  k-iseg+2,cc(ipos),ss(ipos),z(1,iseg),iz)
  260    continue
         e(l) = s*p
         d(l) = c*p
         if (abs(e(l)).gt.b) go to 100
  280    d(l) = d(l) + f
  300 continue
c     order eigenvalues and eigenvectors
      do 380 i = 1, n
         k = i
         p = d(i)
         i1 = i + 1
         if (i1.gt.n) go to 340
         do 320 j = i1, n
            if (d(j).ge.p) go to 320
            k = j
            p = d(j)
  320    continue
  340    if (k.eq.i) go to 380
         d(k) = d(i)
         d(i) = p
         do 360 j = 1, n
            p = z(j,i)
            z(j,i) = z(j,k)
            z(j,k) = p
  360    continue
  380 continue
      ifail = 0
      return
  400 ifail = p01abf(isave,1,srname,0,p01rec)
      return
      end
      subroutine f06qxf( side, pivot, direct, m, n, k1, k2, c, s, a,
     $                   lda )
c     mark 13 release. nag copyright 1988.
c     .. scalar arguments ..
      integer            k1, k2, lda, m, n
      character*1        direct, pivot, side
c     .. array arguments ..
      double precision   a( lda, * ), c( * ), s( * )
c     ..
c
c  f06qxf  performs the transformation
c
c     a := p*a,   when   side = 'l' or 'l'  (  left-hand side )
c
c     a := a*p',  when   side = 'r' or 'r'  ( right-hand side )
c
c  where a is an m by n matrix and p is an orthogonal matrix, consisting
c  of a  sequence  of  plane  rotations,  applied  in  planes  k1 to k2,
c  determined by the parameters pivot and direct as follows:
c
c     when  pivot  = 'v' or 'v'  ( variable pivot )
c     and   direct = 'f' or 'f'  ( forward sequence ) then
c
c        p is given as a sequence of plane rotation matrices
c
c           p = p( k2 - 1 )*...*p( k1 + 1 )*p( k1 ),
c
c        where  p( k )  is a plane rotation matrix for the  ( k, k + 1 )
c        plane.
c
c     when  pivot  = 'v' or 'v'  ( variable pivot )
c     and   direct = 'b' or 'b'  ( backward sequence ) then
c
c        p is given as a sequence of plane rotation matrices
c
c           p = p( k1 )*p( k1 + 1 )*...*p( k2 - 1 ),
c
c        where  p( k )  is a plane rotation matrix for the  ( k, k + 1 )
c        plane.
c
c     when  pivot  = 't' or 't'  ( top pivot )
c     and   direct = 'f' or 'f'  ( forward sequence ) then
c
c        p is given as a sequence of plane rotation matrices
c
c           p = p( k2 - 1 )*p( k2 - 2 )*...*p( k1 ),
c
c        where  p( k )  is a plane rotation matrix for the ( k1, k + 1 )
c        plane.
c
c     when  pivot  = 't' or 't'  ( top pivot )
c     and   direct = 'b' or 'b'  ( backward sequence ) then
c
c        p is given as a sequence of plane rotation matrices
c
c           p = p( k1 )*p( k1 + 1 )*...*p( k2 - 1 ),
c
c        where  p( k )  is a plane rotation matrix for the ( k1, k + 1 )
c        plane.
c
c     when  pivot  = 'b' or 'b'  ( bottom pivot )
c     and   direct = 'f' or 'f'  ( forward sequence ) then
c
c        p is given as a sequence of plane rotation matrices
c
c           p = p( k2 - 1 )*p( k2 - 2 )*...*p( k1 ),
c
c        where  p( k )  is a  plane rotation  matrix  for the  ( k, k2 )
c        plane.
c
c     when  pivot  = 'b' or 'b'  ( bottom pivot )
c     and   direct = 'b' or 'b'  ( backward sequence ) then
c
c        p is given as a sequence of plane rotation matrices
c
c           p = p( k1 )*p( k1 + 1 )*...*p( k2 - 1 ),
c
c        where  p( k )  is a  plane rotation  matrix  for the  ( k, k2 )
c        plane.
c
c  c( k ) and s( k )  must contain the  cosine and sine  that define the
c  matrix  p( k ).  the  two by two  plane rotation  part of the  matrix
c  p( k ), r( k ), is assumed to be of the form
c
c     r( k ) = (  c( k )  s( k ) ).
c              ( -s( k )  c( k ) )
c
c  if m, n or k1 are less than unity,  or k2 is not greater than k1,  or
c  side = 'l' or 'l'  and  k2  is greater than  m, or  side = 'r' or 'r'
c  and  k2  is greater than  n,  then an  immediate return  is effected.
c
c
c  nag fortran 77 o( n**2 ) basic linear algebra routine.
c
c  -- written on 20-november-1986.
c     sven hammarling and mick pont, nag central office.
c
c     alternative code used in this version when side.eq.'l' to
c     enable vectorisation but working with rows of the array a.
c
c     .. parameters ..
      double precision   one, zero
      parameter          ( one = 1.0d+0, zero = 0.0d+0 )
c     .. local scalars ..
      double precision   ctemp, stemp, temp
      integer            i, j
      logical            left, right
c     .. intrinsic functions ..
      intrinsic          min
c     ..
c     .. executable statements ..
      left = ( side.eq.'l' ).or.( side.eq.'l' )
      right = ( side.eq.'r' ).or.( side.eq.'r' )
      if( ( min( m, n, k1 ).lt.1 ).or.( k2.le.k1 ).or.
     $    ( ( left ).and.( k2.gt.m ) ).or.
     $    ( ( right ).and.( k2.gt.n ) ) )return
      if( left )then
         if( ( pivot.eq.'v' ).or.( pivot.eq.'v' ) )then
            if( ( direct.eq.'f' ).or.( direct.eq.'f' ) )then
               do 20 j = k1, k2 - 1
                  if( ( c( j ).ne.one ).or.( s( j ).ne.zero ) )then
                     ctemp = c( j )
                     stemp = s( j )
                     do 10 i = 1, n
                        temp = a( j + 1, i )
                        a( j + 1, i ) = ctemp*temp - stemp*a( j, i )
                        a( j, i ) = stemp*temp + ctemp*a( j, i )
   10                continue
                  end if
   20          continue
            else if( ( direct.eq.'b' ).or.( direct.eq.'b' ) )then
               do 40 j = k2 - 1, k1, -1
                  if( ( c( j ).ne.one ).or.( s( j ).ne.zero ) )then
                     ctemp = c( j )
                     stemp = s( j )
                     do 30 i = 1, n
                        temp = a( j + 1, i )
                        a( j + 1, i ) = ctemp*temp - stemp*a( j, i )
                        a( j, i ) = stemp*temp + ctemp*a( j, i )
   30                continue
                  end if
   40          continue
            end if
         else if( ( pivot.eq.'t' ).or.( pivot.eq.'t' ) )then
            if( ( direct.eq.'f' ).or.( direct.eq.'f' ) )then
               do 60 j = k1 + 1, k2
                  ctemp = c( j - 1 )
                  stemp = s( j - 1 )
                  if( ( ctemp.ne.one ).or.( stemp.ne.zero ) )then
                     do 50 i = 1, n
                        temp = a( j, i )
                        a( j, i ) = ctemp*temp - stemp*a( k1, i )
                        a( k1, i ) = stemp*temp + ctemp*a( k1, i )
   50                continue
                  end if
   60          continue
            else if( ( direct.eq.'b' ).or.( direct.eq.'b' ) )then
               do 80 j = k2, k1 + 1, -1
                  ctemp = c( j - 1 )
                  stemp = s( j - 1 )
                  if( ( ctemp.ne.one ).or.( stemp.ne.zero ) )then
                     do 70 i = 1, n
                        temp = a( j, i )
                        a( j, i ) = ctemp*temp - stemp*a( k1, i )
                        a( k1, i ) = stemp*temp + ctemp*a( k1, i )
   70                continue
                  end if
   80          continue
            end if
         else if( ( pivot.eq.'b' ).or.( pivot.eq.'b' ) )then
            if( ( direct.eq.'f' ).or.( direct.eq.'f' ) )then
               do 100 j = k1, k2 - 1
                  if( ( c( j ).ne.one ).or.( s( j ).ne.zero ) )then
                     ctemp = c( j )
                     stemp = s( j )
                     do 90 i = 1, n
                        temp = a( j, i )
                        a( j, i ) = stemp*a( k2, i ) + ctemp*temp
                        a( k2, i ) = ctemp*a( k2, i ) - stemp*temp
   90                continue
                  end if
  100          continue
            else if( ( direct.eq.'b' ).or.( direct.eq.'b' ) )then
               do 120 j = k2 - 1, k1, -1
                  if( ( c( j ).ne.one ).or.( s( j ).ne.zero ) )then
                     ctemp = c( j )
                     stemp = s( j )
                     do 110 i = 1, n
                        temp = a( j, i )
                        a( j, i ) = stemp*a( k2, i ) + ctemp*temp
                        a( k2, i ) = ctemp*a( k2, i ) - stemp*temp
  110                continue
                  end if
  120          continue
            end if
         end if
      else if( right )then
         if( ( pivot.eq.'v' ).or.( pivot.eq.'v' ) )then
            if( ( direct.eq.'f' ).or.( direct.eq.'f' ) )then
               do 140 j = k1, k2 - 1
                  if( ( c( j ).ne.one ).or.( s( j ).ne.zero ) )then
                     ctemp = c( j )
                     stemp = s( j )
                     do 130 i = 1, m
                        temp = a( i, j + 1 )
                        a( i, j + 1 ) = ctemp*temp - stemp*a( i, j )
                        a( i, j ) = stemp*temp + ctemp*a( i, j )
  130                continue
                  end if
  140          continue
            else if( ( direct.eq.'b' ).or.( direct.eq.'b' ) )then
               do 160 j = k2 - 1, k1, -1
                  if( ( c( j ).ne.one ).or.( s( j ).ne.zero ) )then
                     ctemp = c( j )
                     stemp = s( j )
                     do 150 i = 1, m
                        temp = a( i, j + 1 )
                        a( i, j + 1 ) = ctemp*temp - stemp*a( i, j )
                        a( i, j ) = stemp*temp + ctemp*a( i, j )
  150                continue
                  end if
  160          continue
            end if
         else if( ( pivot.eq.'t' ).or.( pivot.eq.'t' ) )then
            if( ( direct.eq.'f' ).or.( direct.eq.'f' ) )then
               do 180 j = k1 + 1, k2
                  ctemp = c( j - 1 )
                  stemp = s( j - 1 )
                  if( ( ctemp.ne.one ).or.( stemp.ne.zero ) )then
                     do 170 i = 1, m
                        temp = a( i, j )
                        a( i, j ) = ctemp*temp - stemp*a( i, k1 )
                        a( i, k1 ) = stemp*temp + ctemp*a( i, k1 )
  170                continue
                  end if
  180          continue
            else if( ( direct.eq.'b' ).or.( direct.eq.'b' ) )then
               do 200 j = k2, k1 + 1, -1
                  ctemp = c( j - 1 )
                  stemp = s( j - 1 )
                  if( ( ctemp.ne.one ).or.( stemp.ne.zero ) )then
                     do 190 i = 1, m
                        temp = a( i, j )
                        a( i, j ) = ctemp*temp - stemp*a( i, k1 )
                        a( i, k1 ) = stemp*temp + ctemp*a( i, k1 )
  190                continue
                  end if
  200          continue
            end if
         else if( ( pivot.eq.'b' ).or.( pivot.eq.'b' ) )then
            if( ( direct.eq.'f' ).or.( direct.eq.'f' ) )then
               do 220 j = k1, k2 - 1
                  if( ( c( j ).ne.one ).or.( s( j ).ne.zero ) )then
                     ctemp = c( j )
                     stemp = s( j )
                     do 210 i = 1, m
                        temp = a( i, j )
                        a( i, j ) = stemp*a( i, k2 ) + ctemp*temp
                        a( i, k2 ) = ctemp*a( i, k2 ) - stemp*temp
  210                continue
                  end if
  220          continue
            else if( ( direct.eq.'b' ).or.( direct.eq.'b' ) )then
               do 240 j = k2 - 1, k1, -1
                  if( ( c( j ).ne.one ).or.( s( j ).ne.zero ) )then
                     ctemp = c( j )
                     stemp = s( j )
                     do 230 i = 1, m
                        temp = a( i, j )
                        a( i, j ) = stemp*a( i, k2 ) + ctemp*temp
                        a( i, k2 ) = ctemp*a( i, k2 ) - stemp*temp
  230                continue
                  end if
  240          continue
            end if
         end if
      end if
c
      return
c
c     end of f06qxf. ( sgesrc )
c
      end
