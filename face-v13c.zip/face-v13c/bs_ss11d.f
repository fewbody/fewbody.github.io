
      SUBROUTINE D3BS (GO,KSTATE,NSTATE,MC,calmci,AMU,NRMS,
     x                 DELE,EMAX,IFAIL)
C *******************************************************************
C **** 21-MAR-86 COUP. CHAN. CALC. FOR 3-BODY IN K-HARMONICS
C *** DELTA (SHIFT)   CALCULATIONS FOR DISTORTED COULOMB
C **** FUNCTIONS OF AN ARBITRARY INDEX
C **** R IN FERMI
C **** MODE1 - SWITCH PARAMETERS: =1 - REG. & IRREG FUNCT.-S AND
C **** DERIVATIVES; =2 - REG. & IRREG FUNCT.-S;=3 REG. FUNCT.-S
C ***  KFN - =0-COULOMB FUN.;=1-SPHERICAL BESSELS;=2-CILINDRICAL
C
C ***  INPUT: IN COMMON /INTEG / , /PARPOT/
C ***  EC - KINETIC ENERGY (CM)
         use    susycom     
      IMPLICIT DOUBLEPRECISION (A-H,O-Z)
      LOGICAL ISNAN
      DIMENSION KSTATE(NSTATE),nodes(NSTATE)
      REAL*8 NRMS(NSTATE)
       real*8,allocatable::  F(:)
      LOGICAL GO,calmci
c     */INTEG/RM  ,H,EC ,AH2,DELR,IFUN   ,IIPR,AH22,WVK
c     *  ,WVK1,RINT,NINT
C ***************************************************
C ****
c	allocate(F( NSTATE ))    
	PI  = 3.14159265D0
      GO = .true.
      IFAIL = 0
       IFUN=1
       NST1 = NSTATE
       NST2 = NST1*2
       NST21 = NST2 - 1
      RMAX = RM
c      AMU  = 1.0D0
c      AMH  = AMU /20.748D0
      AMH  = AMU /H2M
      IF (EC  .EQ. 0.) EC    = 1.0D-4
C     IF (EC  .GE. 0.D0) EC    = -EC
C ***********************************************
      H2   = H**2
      HST  =   H
      AH2  = AMH
      AH22 = AMH * H*H
C *******
      DEC  =  DELE
      MAXIT=90
         M1 = abs(EC-(-5.))/DELE + 2*3/DELE + 4*2.5/DELE
      MAXIT=max(MAXIT,M1)+10
      MCI = MC
      if(MC<=0) MCI=1
      if(MC>=NSTATE) MCI=NSTATE
!      calmci = .true.
      WRITE(4,1234)NSTATE,MC,MCI,MAXIT
      write(4,*) 'cal MCI =',calmci
      MODE = 0
C     RINT = 3.0D0
C     WRITE(4,3340)RINT
      NINT = RINT/H + 0.5D0
      III  = 1
      NIT  = 0
c
      NM   = RMAX/H 
c      IF(NM-NM)227,227,228
 227  IFUN  = 1
c      GO TO 229
c 228  write(4,*)' stop NM > NM  !!!!'
C
 229  CONTINUE

        NMRAD = NM
         NMAX = NM
C *************************************************************************
         NSMAX = NSTATE
         NSM2  = NST2
	allocate(  ZF(NSMAX,NSMAX),ZB(NSMAX),
     & A(NSM2,NSM2), AA (NSM2,NSM2),    B(NSM2,1),
     & XIF1(NSMAX,NSMAX),XIF2(NSMAX,NSMAX),
     & FF(NSMAX ),GG(NSMAX),FD(NSMAX),GD(NSMAX),
     & FUN(NSMAX,NSMAX,NM+1),
     & F(NSMAX),BE(NSMAX,NM),V9(NSM2))

C *************************************************************************

C **** WE CLEAR THE ARRAY  FUN(I,K,NMAX)
       DO 3000 I = 1,NSTATE
       DO 3000 K = 1,NSTATE
       DO 3000 J = 1,NMRAD
 3000  FUN(I,K,J)  = 0.0D0
C *******
C
       INST = 0
        ISEARCH = 0
C
            DEC  =  DELE
            if(abs(EC)<5.) DEC=DEC/2.
            if(abs(EC)<2.) DEC=DEC/2.

       EC  = EC - DEC
 111   continue
         if(ISEARCH==0) then
            DEC  =  DELE
            if(abs(EC)<5.) DEC=DEC/2.
            if(abs(EC)<2.) DEC=DEC/2.
         endif
       EC  = EC + DEC
       E1  = EC

      NIT  = NIT + 1
        if(NIT .gt. MAXIT) then
        write(*,*)' failed after',NIT,'iterations'
        write(4,*)' failed after',NIT,'iterations'
        go to 808
        endif
c        write(6,*)' point 1'
      NR   = RMAX*2.D0/H  + 0.5D0

C       WRITE(4,1234)NM
      RM    = RMAX
C      IF (EC .GE.-0.05D0) GO TO 888
       IF (EC .GE. EMAX) GO TO 888
      WVK  = DSQRT(AMH*DABS(EC ))
C
C          DFN = (1.D100)**(-1.D0/NSTATE)
          DFN = 1.D0
          ADFN = 1.D0
C	  write(7,*) 'EC =',EC
C
         CALL COCHIND (KSTATE,NSTATE)
C        CALL COCHIND(FUN,NSTATE,NMRAD)

       DO 41 I = 1,NST1
       DO 47 J = 1,NST1
      A(I,J) = XIF2(I,J)
      I1 = I + NST1
C     J1 = J + NST1
      A(I1,J)= XIF1(I,J)
 47   CONTINUE
 41   CONTINUE
       DO9041 I = 1,NST1
       DO9047 J = 1,NST1
      ZF(I,J) = XIF2(I,J)
 9047  CONTINUE
 9041 CONTINUE
C
      N2 = NSTATE
C     CALL CMLID (A,B, NSMAX ,N2   ,N1  ,DET,V9,MODE)
      CALL CMLID (ZF,ZB,NSMAX,N2   ,0   ,DET,V9,MODE,IFAIL)
!     WRITE(4,9001) DET
 9001 FORMAT(1X,'DET XI IN = ',2G12.4)
      if(IFAIL>0) go to 808
	DIN = DET
	 ANDIN = (DABS(DIN))**(1.D0/N2)
       DO9141 I = 1,NST1
       DO9147 J = 1,NST1
      ZF(I,J) = XIF1(I,J)
 9147  CONTINUE
 9141 CONTINUE
C
c        write(6,*)' point 2'
      N2 = NSTATE
C     CALL CMLID (A,B, NSMAX ,N2   ,N1  ,DET,V9,MODE)
      CALL CMLID (ZF,ZB,NSMAX,N2   ,0   ,DET,V9,MODE,IFAIL)
!     WRITE(4,9002) DET
c        write(6,*)' point 3'
 9002 FORMAT(1X,'DET XID IN = ',2G12.4)
      if(IFAIL>0) go to 808
         CALL COCOUT (KSTATE,NSTATE)
C        CALL COCOUT(FUN,NSTATE,NMRAD)
C
c        write(6,*)' point 4'
       DO4441 I = 1,NST1
       DO 447 J = 1,NST1
      I1 = I + NST1
      J1 = J + NST1
      A(I,J1)=-XIF2(I,J)
      A(I1,J1)=-XIF1(I,J)
 447   CONTINUE
 4441  CONTINUE
       DO9241 I = 1,NST1
       DO9247 J = 1,NST1
      ZF(I,J) = XIF2(I,J)
 9247  CONTINUE
 9241 CONTINUE
C
c       write(4,*)'ZF',((XIF2(I,J),I = 1,NST1),J = 1,NST1)

      N2 = NSTATE
C     CALL CMLID (A,B, NSMAX ,N2   ,N1  ,DET,V9,MODE)
      CALL CMLID (ZF,ZB,NSMAX,N2   ,0   ,DET,V9,MODE,IFAIL)
!     WRITE(4,90035) DET
90035 FORMAT(1X,'DET XI OUT = ',2G12.4)
      if(IFAIL>0) go to 808
c        write(6,*)' point 5'
	DOUT = DET
	 ANDOUT = (DABS(DOUT))**(1.D0/N2)
        if(ANDOUT.lt.1.d-50)ANDOUT = 1.
       DO9341 I = 1,NST1
       DO9347 J = 1,NST1
      ZF(I,J) = XIF1(I,J)
 9347  CONTINUE
 9341 CONTINUE
C
      N2 = NSTATE
C     CALL CMLID (A,B, NSMAX ,N2   ,N1  ,DET,V9,MODE)
      CALL CMLID (ZF,ZB,NSMAX,N2   ,0   ,DET,V9,MODE,IFAIL)
!     WRITE(4,9004) DET
 9004 FORMAT(1X,'DET XID OUT = ',2G12.4)
 599  FORMAT(1X,10G12.3)
      if(IFAIL>0) go to 808

c        write(6,*)' point 3'
       DO 9988 MM = 1,NST2
         IF(MM .GT. NST1) GO TO 9954
      DO 2202 I = 1,NST2
 2202   A(I,MM  ) =   A(I,MM  )/ANDIN *ADFN
      HF1  = IFUN*H
      NF1  = RINT/HF1
      DO 2201 I = 1,NST1
      DO 2201 J = 1,NF1
 2201 FUN(I,MM,J) = FUN(I,MM,J)/ANDIN *ADFN
C
         GO TO 9988
C
 9954  CONTINUE
C
      DO 2702 I = 1,NST2
 2702   A(I,MM  ) =   A(I,MM  )/ANDOUT *ADFN
      NF2 = NF1 + 1
      JM  = MM  - NST1
      nnm2 = RMAX/(H*IFUN)
      IF(nnm2 .GE.NMAX) nnm2 = NMAX
      DO 2291 I = 1,NST1
      DO 2291 J =   NF2,nnm2
 2291 FUN(I,JM,J) = FUN(I,JM,J)/ANDOUT * ADFN
 9988  CONTINUE
 4680  CONTINUE

 9998  CONTINUE

C *** N1=0

         N1   =0
         N2   = NSTATE*2
      CALL CMLID (A,B, NSM2 ,N2   ,N1  ,DET,V9,MODE,IFAIL)
C     CALL CMLID (A,B,  N2,N2   ,N1  ,DET,V9,MODE)
      DET1  = DET
      WRITE(4,*)III,EC,DET1
      WRITE(401,*)EC,DET1,241
!      WRITE(403,*)DET1,sign(1d0,abs(DET1)),sign(1d0,abs(DET1))>0
 8769 FORMAT(1X,'III=',I5,', EC =',G14.4,'  TES DET=',G16.8/)
      if(IFAIL>0) go to 808
      if(sign(1d0,abs(DET1))<0) go to 808
!      if(isnan(DET1)) go to 808
c
      IF (III .EQ. 1) THEN
c      IF (det2/det1 .gE. 0.d0) THEN
         WRITE(4,7769)III,E1,DET1
        WRITE(401,*)E1,DET1,282
         DET2  = DET1
         E2=E1
         III   = III+1
          ISEARCH = 0
          ISEARCH2 = 0
         GO TO 111
      ENDIF
      IF (det2/det1 .gE. 0.d0) THEN
       IF(ISEARCH .EQ. 0) THEN
       IF(ISEARCH2 .EQ. 0) THEN
C         WRITE(6,7769)III,E1,DET1
         DET2  = DET1
         E2=E1
         III   = III+1
          ISEARCH = 0
C
C  !!!!!!!!!!!!!!!!!!!!!!! TEST ##################################
cc         GO TO 2222
         GO TO 111
       ENDIF
       ENDIF
      ENDIF
C
       IF(ISEARCH2 .EQ. 0) THEN
c      IF (DABS(DET1).LT. 1.0D-240)GO TO 2222
      IF (DABS(DET1).LT. 1.0D-240)GO TO 2192

          ISEARCH = 1

      DEC = DEC/2.D0*(DET1/DET2/ABS(DET1/DET2)) 
c      if (abs(DEC).Lt.0.001)  ISEARCH2 = 1
      if (abs(DEC).Lt.0.00001) go to 131 
!     WRITE(4,7768)III,DEC,DET1,E1,E1+DEC,WVK
      DET2 = DET1
      E2   = EC
       III   = III+1
      GO TO 111

C
       ENDIF
c      IF (DABS(DET1).LT. 1.0D-240)GO TO 2222
      IF (DABS(DET1).LT. 1.0D-240)GO TO 2192

          ISEARCH = 1
          ISEARCH2 = 1

      DEC = - (E2-E1)/(DET2/DET1-1.D0) 
c      if (abs(DEC).gt.0.1) DEC = sign(0.1d0,DEC)
!      WRITE(4,7768)III,DEC,DET1,E1,E1+DEC,WVK
 7768 FORMAT(1X,I3,' DEC,DET1,E1,E-NEW,k=',5G16.8/)
C      WRITE(6,7769)III,E1,DET1,DEC
 7769 FORMAT(1X,I3,': E1, DET1, DEC =',3G16.8)
      IF(III.gt.MAXIT) THEN
         WRITE(6,*) 'Failed to converge after ',III,' iterations'
	 GO = .false.
	 RETURN
         ENDIF
      IF(abs(E2-E1) .LT. 1.D-6 )GO TO 131
      DET2 = DET1
      E2   = EC
       III   = III+1
      GO TO 111

C
C *************************** FINAL CALCULATION WITH BEST EC
131   DO 5912 I = 1,NST21
       B(I ,1) = -A(I,MCI)
 5912 CONTINUE
      DO 5778 I = 1,NST21
      DO 5777 J = 1,MCI-1
 5777 AA(I,J)  =   A(I,J)
      DO 5778 J = MCI+1,NST2
 5778 AA(I,J-1)  =   A(I,J)
   

      NIT  = NIT + 1
      H   = HST
      WVK  = DSQRT(AMH*DABS(EC ))
         CALL COCHIND (KSTATE,NSTATE)
C
C  *******
       DO9741 I = 1,NST1
       DO9747 J = 1,NST1
      ZF(I,J) = XIF2(I,J)
 9747  CONTINUE
 9741 CONTINUE
C
      N2 = NSTATE
      CALL CMLID (ZF,ZB,NSMAX,N2   ,0   ,DET,V9,MODE,IFAIL)
!      WRITE(4,90015) DET
90015 FORMAT(1X,'DET XI IN = ',2G12.4)
      if(IFAIL>0) go to 808
      if(sign(1d0,abs(DET))<0) go to 808
!      if(isnan(DET)) go to 808
	DIN = DET
	 ANDIN = (DABS(DIN))**(1.D0/N2)
       DO 81 I = 1,NST1
       DO 87 J = 1,NST1
      I1 = I + NST1
      A(I,J) = XIF2(I,J)*DFN
      A(I1,J)= XIF1(I,J)*DFN
 87   CONTINUE
 81   CONTINUE
         CALL COCOUT (KSTATE,NSTATE)
C
       DO9841 I = 1,NST1
       DO9847 J = 1,NST1
      ZF(I,J) = XIF2(I,J)
 9847  CONTINUE
 9841 CONTINUE
C
      N2 = NSTATE
      CALL CMLID (ZF,ZB,NSMAX,N2   ,0   ,DET,V9,MODE,IFAIL)
!      WRITE(4,9003) DET
 9003 FORMAT(1X,'DET XI OUT = ',2G12.4)
      if(IFAIL>0) go to 808
      if(sign(1d0,abs(DET))<0) go to 808
!      if(isnan(DET)) go to 808
	DOUT = DET
	 ANDOUT = (DABS(DOUT))**(1.D0/N2)
        if(ANDOUT.lt.1.d-50)ANDOUT = 1.
       DO 481 I = 1,NST1
       DO 487 J = 1,NST1
      I1 = I + NST1
      J1 = J + NST1
      A(I,J1)=-XIF2(I,J)*DFN
      A(I1,J1)=-XIF1(I,J)*DFN
 487   CONTINUE
 481   CONTINUE
C
 2192 CONTINUE
C ****  NORMALIZING DETERMINANT AND FUNCTIONS
C       ITN = 0
C       IF(ITN .EQ. 0) GO TO 5680
C ****  NORMALIZING DETERMINANT AND FUNCTIONS
       DO 8988 MM = 1,NST2
         IF(MM .GT. NST1) GO TO 8954
      DO 2203 I = 1,NST2
 2203   A(I,MM  ) =   A(I,MM  )/ANDIN * ADFN
      HF1  = IFUN*H
      NF1  = RINT/HF1
      DO 3201 I = 1,NST1
      DO 3201 J = 1,NF1
 3201 FUN(I,MM,J) = FUN(I,MM,J)/ANDIN * ADFN
C
         GO TO 8988
C
 8954  CONTINUE
C
      DO 2293 I = 1,NST2
 2293   A(I,MM  ) =   A(I,MM  )/ANDOUT * ADFN
      NF2 = NF1 + 1
      nnm2 = RMAX/(H*IFUN)
      IF(nnm2 .GE.NM) nnm2 = NM
	JJ = MM - NST1
	  DO 3291 I = 1,NST1
      DO 3291 J =   NF2,nnm2
 3291 FUN(I,JJ,J) = FUN(I,JJ,J)/ANDOUT * ADFN
 8988  CONTINUE
 5680  CONTINUE
C
!     DO 912 I = 1,NST21
!      B(I ,1) = -A(I,MCI)
! 912 CONTINUE
!     DO 1779 I = 1,NST21
!     DO 1777 J = 1,MCI-1
!1777 AA(I,J)  =   A(I,J)
!     DO 1778 J = MCI+1,NST2
!1778 AA(I,J-1)  =   A(I,J)
!1779 CONTINUE

      do 133 I=1,NST2
      do 132 J=1,NST2
132     AA(I,J) = A(I,J)
133     B(I,1) = 0.0
	drmin = 1e3
	do 134 I=1,NST1
         dld = AA(I+NST1,I)/AA(I,I)-AA(I+NST1,I+NST1)/AA(I,I+NST1)
	write(4,'('' logders:'',i3,1p,10e12.4)') I,
     x       AA(I+NST1,I)/AA(I,I),AA(I+NST1,I+NST1)/AA(I,I+NST1),dld
	 if(abs(dld)<drmin.and.calmci) then
	   idm = I
	   drmin = abs(dld)
	 endif
134	continue
       if(calmci) then 
	  write(4,*) ' Setting MCI =',idm
          MCI = idm
	  endif

      AA(NST1+MCI,:) = 0.0
      AA(NST1+MCI,NST1+MCI) = 1.0
      B(NST1+MCI,1) = 1.0

      CALL CMLID (A,B, NSM2 ,N2   ,N1  ,DET,V9,MODE,IFAIL)
!     WRITE(4,1768)DET
 1768 FORMAT(2X,'Final DET=',G15.5)
      if(IFAIL>0) go to 808

c      WRITE(6,765)III
 765  FORMAT(1X,'NUMBER OF ITERATIONS = ',I5/)

      NS22 = NST1*NST1
 1599 FORMAT(3X,'R FM',5X,9(2X,'FUN',7X)/)
C     WRITE(6,1599)

 71   WRITE (4,771) EC
 771  FORMAT(1X,'BIND ENGY:',G12.5/)
!      WRITE (6,771) EC
      MODE = 0
      N2   = NST2
      N1   = 1
      CALL CMLID (AA,B, NSM2 ,N2   ,N1  ,DET,V9,MODE,IFAIL)
      if(IFAIL>0) go to 808
      HF1  = IFUN*H
      NF1  = RINT/HF1
      DO 20011 I1= 1,NST1
      DO 20011 J = 1,NF1
      DO 20011 I = 1,NST1
20011 FUN(I1,I,J) = FUN(I1,I,J)*B(I,1) * DFN
      NSTM1 = NST1
      NF2 = NF1 + 1
      nnm2 = RMAX/(H*IFUN)
      IF(nnm2 .GE.NM) nnm2 = NMAX
      DO 2002 I = 1,NST1
      DO 2002 I1= 1,NST1
      DO 2002 J = NF2,nnm2
 2002 FUN(I1,I,J) = FUN(I1,I,J+1)*B(I+NSTM1,1) * DFN

      DO 2004 J = 1  ,nnm2
      DO 2005 I = 1  ,NST1
      SUM  = 0.D0
      DO 2006 I1= 1  ,NST1
 2006 SUM      = SUM     +FUN(I,I1,J)
 2005 FUGS(I,J) = SUM
 2004 CONTINUE

      DO 3761 I1= 1,NST1
 3761 NRMS(I1) = 0.0D0
      DO 2014 J = 1  ,nnm2
      DO 2015 I = 1  ,NST1
 2015 NRMS(I)     = NRMS(I)    +FUGS(I  ,J)**2*H*IFUN
 2014 CONTINUE
C
      IF ( EC .lt. 0.) THEN
         DO 8015 I = 1  ,NST1
         NRMS(I) = FUGS(I ,nnm2)**2/(2.D0*WVK) + NRMS(I)
 8015    CONTINUE
      ENDIF
C
      SUM   = 0.0D0
      DO 2115 I = 1  ,NST1
 2115 SUM      = SUM     +NRMS(I)
      DO 4115 I = 1  ,NST1
      nodes(I) = 1
 4115 NRMS(I)     = NRMS(I)/SUM
      CNORM    = 1.D0/ DSQRT(SUM)
      DO 3014 J = 1  ,nnm2
      DO 3015 I = 1  ,NST1
      FUGS(I ,J)     = FUGS(I ,J) * CNORM
 3015 if(J>KSTATE(I)+2.and.FUGS(I,J)*FUGS(I,J-1)<0
     x   .and.abs(FUGS(I,J))>1e-3) nodes(I)=nodes(I)+1
 3014 CONTINUE

      WRITE(4,*) 'Bound State wave function'
       WRITE(40,4001)  EC
4001  FORMAT('# Bound State wave function at ',f10.5)
      DO 4120 N=1,nnm2
         R = N*H
!      if(mod(N,5).eq.0)WRITE(4,4121) R,(FUGS(I,N),I=1,MIN(NSTATE,10))
       if(mod(N,50).eq.0)WRITE(40,4121) R,(FUGS(I,N),I=1,MIN(NSTATE,10))
4120  continue
C4121  FORMAT(1X,F8.3,10G12.3)
4121  FORMAT(1X,F8.3,10G12.4)
      WRITE(40,*) '&'
c      stop 'GS WAVE FUN'
C
C  *** PRINT OF PARTIAL WIDTHS ***
      if(NST1>0) then
!      WRITE(6,7092)
      WRITE(4,7092)
 7092 FORMAT(4X,'NST',2X,'  L   Partial Norm nodes   E')
      DO 7088 I = 1,NST1
!      WRITE(6,7090)I,KSTATE(I),NRMS(I),nodes(I)
 7088 WRITE(4,7090)I,KSTATE(I),NRMS(I),nodes(I),EC
!      WRITE(6,*)
 7090 FORMAT(' bs:',I3,2X,I3,G12.4,i5,f12.3)
 	endif
c      stop 'GS WAVE FUN'
C
 1234 FORMAT('        D3B ',8I6)

C *************************************************************************
 7777  continue

 808	deallocate(  ZF,ZB, A, AA , B, XIF1,XIF2, FF,GG,FD,GD,
     & FUN, F,BE,V9)

      RETURN
 888  WRITE(4,889)
!      WRITE(6,889)
	deallocate(  ZF,ZB, A, AA , B, XIF1,XIF2, FF,GG,FD,GD,
     & FUN, F,BE,V9)
 889  FORMAT(1X,'**** NO BOUND STATES !!!!  ***'/)
      RETURN
      END

*==> cocou1.f <==
C    PROGRAM TO SOLVE COUPLED CHANNEL DIF. EQUATIONS BY DE VOGELAERE
C    METHOD (ACCURACY H**4) METH. IN COMP. PHYS V.10 ATOMIC & MOL. SCAT
      SUBROUTINE COCOUT (KSTATE,NSTATE)
C     SUBROUTINE COCOUT (FUN,NST1,NMR)
         use    susycom     
      IMPLICIT DOUBLEPRECISION(A-H,O-Z)
      DIMENSION KSTATE(NSTATE)

      real*8,allocatable:: XI(:,:),XID(:,:),XIM(:,:),
     * FM(:,:),F1(:,:),F(:,:),
     * SM(:,:),S(:,:),S1(:,:),XID1(:,:),
     * XI1(:,:),XI2(:,:),F2(:,:),S2(:,:),
     * ANORM(:)
c ------------------------------------------------------------------
       NSMAX = NSTATE

      allocate( XI(NSMAX,NSMAX),XID(NSMAX,NSMAX),XIM(NSMAX,NSMAX),
     * FM(NSMAX,NSMAX),F(NSMAX,NSMAX),F1(NSMAX,NSMAX),
     * SM(NSMAX,NSMAX),S(NSMAX,NSMAX),S1(NSMAX,NSMAX),XID1(NSMAX,NSMAX),
     * XI1(NSMAX,NSMAX),XI2(NSMAX,NSMAX),F2(NSMAX,NSMAX),
     * S2(NSMAX,NSMAX),ANORM(NSMAX))
     
      H2     =-0.5D0*H
      H6     =-H/6.0D0
      DLR    = DELR

      HH     = H*H
      HH6    = HH /6.0D0
      HH8    = HH /8.0D0
      HH24   = HH /24.0D0
      MN     = DELR/H
      NM     = RM/H
      NINT   = RINT/H
      MN     = DLR/H
       INORM =  0
       IFUN  = 1     
c       write(6,*)'cocout 1'

      DO93  I=1,NSTATE
      KK     =   KSTATE(I)
       KI0   =  1
      WVK1   =   DSQRT(AH2*DABS(EC))
      RINTW  =   RINT*WVK1/2.D0
      A1     =   DEXP( RINTW)*RINTW**KK
      ANORM(I) = 1.D0/A1
  93   CONTINUE
 2000  CONTINUE
c       write(6,*)'cocout 2,RINTW',RINTW

       K     =   KSTATE(NSTATE)
      DO 3 IL=1,NSTATE
      DO 3  I=1,NSTATE
      AKK    =   KSTATE(I)
      AK     =   AKK      
      XI(I,IL)=   0.000000000000D0
      XID(I,IL) =   0.000000000000D0
      IF(I-IL) 2,1,2
  1   KI0    =    NM*2
      RI0    =   NM
      RI0H   =   RI0*H

      RI0W   =   RI0H*WVK
      RIMH   =   RI0H-H2
C     DD     =   RI0W**2/(4.D0*(RI0+1.D0))
      T1     =   8.0D0*RI0W
      TT1    =   2.0D0*T1**2
      T2     =   4.0D0*AKK**2 - 1.0D0

      XI(I,IL)  = DEXP(-RI0W)*(1.D0 +T2/T1+T2*(T2-8.0D0)/TT1)*ANORM(I)
C     XID(I,IL) = RI0W**AK*(AK + 1.D0)*(1.D0-(RI0+2.5D0)*DD/(RI0+0.5))
      XID(I,IL) =-WVK*DEXP(-RI0W)*(1.D0+T2/T1+T2*(T2+8.D0)/TT1)*ANORM(I)
  2   CONTINUE
      F(I,I) =   AH2*(VVAL(I,I,KI0 )-EC)+CL(I,KI0)
      FM(I,I) =   AH2*(VVAL(I,I,KI0+1)-EC)+CL(I,KI0+1)
  3   CONTINUE

c       write(6,*)'cocout 3'
      DO 9 I = 1,NSTATE
      DO 9 J = 1,NSTATE
      IF (I-J) 9,9,33
  33  F(I,J) = AH2 * VVAL(I,J,KI0 )
      F(J,I) = F(I,J)

      FM(I,J) = AH2 * VVAL(I,J,KI0+1)
      FM(J,I) = FM(I,J)
  9   CONTINUE
      DO 5     IL=1,NSTATE
      DO 5      I=1,NSTATE
      S(I,IL)  = 0.0D0
      DO 55     J=1,NSTATE
      SI =XI(J,IL)*F(I,J)
      S(I,IL)=S(I,IL)+SI

  55  CONTINUE
      XIM(I,IL) = XI(I,IL)+H2*XID(I,IL)+HH8*S(I,IL)

  5   CONTINUE

      JJJ = 0
      KKK = 1
      NMN    =  NM/IFUN
      MAR = 0
c       write(6,*)'cocout: NINT,NM,ec',NINT,NM,ec
      DO 88     N1=NINT,NM
      N  = NM - N1 + NINT
      RN     =  N
      NN     =  N*2
      RNH    =  RN*H
      RNM    =  RNH-H2
      JJJ    =  JJJ + 1
C *** M Y(I,IL,1/2)
      DO 6     IL=1,NSTATE
      DO 6      I=1,NSTATE
      SM(I,IL)  = 0.0D0
      DO 66     J=1,NSTATE
      SI =XIM(J,IL)*FM(I,J)
      SM(I,IL)=SM(I,IL)+SI

  66  CONTINUE
      XI1(I,IL) = XI(I,IL)+H2*XID(I,IL)+HH24*(4.0D0*S(I,IL)-SM(I,IL))

  6   CONTINUE
      DO 7 I = 1,NSTATE
      F1(I,I) =   AH2*(VVAL(I,I,NN+1)-EC)+CL(I,NN+1)
      F2(I,I) =   AH2*(VVAL(I,I,NN )-EC)+CL(I,NN)
      DO 7 J = 1,NSTATE
      IF (I-J) 7,7,77
  77  F1(I,J) = AH2 * VVAL(I,J,NN+1)
      F1(J,I) = F1(I,J)
      F2(I,J) = AH2 * VVAL(I,J,NN )
      F2(J,I) = F2(I,J)
  7   CONTINUE
      DO 8     IL=1,NSTATE
      DO 8      I=1,NSTATE
      S1(I,IL)  = 0.0D0
      DO 89     J=1,NSTATE
      SI =XI1(J,IL)*F1(I,J)
      S1(I,IL)=S1(I,IL)+SI

  89  CONTINUE
      XI2(I,IL) = XI(I,IL)-H*XID(I,IL)+HH6*(S(I,IL)+2.0D0*S1(I,IL))

  8   CONTINUE
      DO 10    IL=1,NSTATE
      DO 10    I=1,NSTATE
      S2(I,IL)  = 0.0D0
      DO 100    J=1,NSTATE
      SI =XI2(J,IL)*F2(I,J)
      S2(I,IL)=S2(I,IL)+SI

 100  CONTINUE
      XID1(I,IL) = XID(I,IL)+H6*(S(I,IL)+4.0D0*S1(I,IL)+S2(I,IL))

 10   CONTINUE

C     IF(N-NM+MN) 17,18,17
C 18  DO 199 IL= 1,NSTATE
C     DO 199 I = 1,NSTATE
C 199 XIF1(I,IL) = XI2(I,IL)
  17  IF(JJJ .EQ. IFUN)GO TO 45
      GO TO 98
  45  RNN = RNH
      DO 299 IL= 1,NSTATE
      DO 299 I = 1,NSTATE
C     III = I +  2*(IL - 1)
      FUN(I,IL,NMN+1)= XI2(I,IL)

c       write(6,*)'cocout- FUN',NMN+1,FUN(I,IL,NMN+1)

C     DD        = XID(I,IL)
C     POTT    =   AH2*(VVAL(I,I,NN )-EC)+CL(I,NN)
C     CLT     =   CL(I,NN)
C     CLTM    =   CL(I,NN+1)
  299 TT        = XI2(I,IL)
      NMN  = NMN - 1
      JJJ  = 0
 1234 FORMAT('        D3B ',I6)
  98  CONTINUE
      DO499 I = 1,NSTATE
      DO499 J = 1,NSTATE
      XIM(I,J)=XI1(I,J)
      XI(I,J) =XI2(I,J)
      XID(I,J)=XID1(I,J)
      FM(I,J) =F1(I,J)
      F  (I,J)=F2  (I,J)
      SM(I,J) =S1(I,J)
  499 S  (I,J)=S2  (I,J)
 88   CONTINUE
C 9   CONTINUE
C *** NEW  5.6.89
        IF( INORM .NE. 0 ) GO TO 1585
      AMAX  = 0.D0
      DO1599 IL= 1,NSTATE
C     AMAX  = 0.D0
      DO1598 I = 1,NSTATE
C     A1=DABS     (XI2(I,IL))
C      IF(A1 - AMAX)1598,1598,1597
C1597 AMAX = A1
      AMAX = AMAX + XI2(I,IL)

 1598 CONTINUE
C     ANORM(IL) = ANORM(IL)/AMAX

 1599 CONTINUE
      AMAX = DABS(AMAX)/NSTATE**5
       DO9341 I = 1,NSTATE
       DO9347 J = 1,NSTATE
      ZF(I,J) = XI2(I,J)/AMAX
 9347  CONTINUE
 9341 CONTINUE
C
      MODE = 0
      N2 = NSTATE
      CALL CMLID (ZF,ZB,NSMAX,N2   ,0   ,DET,V9,MODE,IFAIL)
!      WRITE(4,9004) DET,AMAX
 9004 FORMAT(1X,'DET AMAX OUT= ',2G12.4,3X,G12.3)
      if(IFAIL>0) return
      ADET = DET
      ADET = DABS(ADET)
      ADET = ADET**(1./NSTATE)
C
      DO3599 IL= 1,NSTATE
      ANORM(IL) = ANORM(IL)/AMAX /ADET
 3599 CONTINUE
C
      INORM = 1
        GO TO 2000
C
 1585 CONTINUE
      DO 599 IL= 1,NSTATE
      DO 599 I = 1,NSTATE
      XIF1(I,IL) = XI2(I,IL)
C     WRITE(6,1011)XI2(I,IL),XID(I,IL)
C1011 FORMAT(1X,'X=',G15.5,'XD=',G15.5)
C 599 XIF2(I,IL) = XID(I,IL)
C*********************************** altered IJT 22 Oct 93
  599 XIF2(I,IL) = XID1(I,IL)
C     DEBUG INIT(TT,RNN,NN ,DD,NM,KI0,H2,RI0W,NINT)
C     DEBUG INIT(TT,RNN,NN ,DD,NM,KI0,H2,RI0W,NINT,XI,XID,
C    *SM,XI2,XI1,SI,F1,F2 ,S2,XID1,S1  )
C     DEBUG SUBTRACE , SUBCHK

      deallocate( XI,XID,XIM,
     * FM,F,F1,
     * SM,S,S1,XID1,
     * XI1,XI2,F2,S2,
     * ANORM)      

      RETURN
      END

*==> cochin.f <==
C    PROGRAM TO SOLVE COUPLED CHANNEL DIF. EQUATIONS BY DE VOGELAERE
C    METHOD (ACCURACY H**4) METH. IN COMP. PHYS V.10 ATOMIC & MOL. SCAT
      SUBROUTINE COCHIND (KSTATE,NSTATE)
C     SUBROUTINE COCHIND (FUN,NST1,NMR)
         use    susycom     
      IMPLICIT DOUBLEPRECISION(A-H,O-Z)
      DIMENSION KSTATE(NSTATE)

      real*8,allocatable:: XI(:,:),XID(:,:),XIM(:,:),
     * FM(:,:),F1(:,:),F(:,:),
     * SM(:,:),S(:,:),S1(:,:),XID1(:,:),
     * XI1(:,:),XI2(:,:),F2(:,:),S2(:,:),
     * ANORM(:)
c ------------------------------------------------------------------
       NSMAX = NSTATE

      allocate( XI(NSMAX,NSMAX),XID(NSMAX,NSMAX),XIM(NSMAX,NSMAX),
     * FM(NSMAX,NSMAX),F(NSMAX,NSMAX),F1(NSMAX,NSMAX),
     * SM(NSMAX,NSMAX),S(NSMAX,NSMAX),S1(NSMAX,NSMAX),XID1(NSMAX,NSMAX),
     * XI1(NSMAX,NSMAX),XI2(NSMAX,NSMAX),F2(NSMAX,NSMAX),
     * S2(NSMAX,NSMAX),ANORM(NSMAX))      
      IFUN = 1
      H2     = 0.5D0*H
      H6     = H/6.0D0
!     WRITE(4,1333)RM,H,EC,AH2,DELR,IFUN
 1333 FORMAT(1X,  'RMAX,H,EC,AH2,DELR,IFUN,AH22'/5G12.3,2I6)
C     WRITE(6,1334) EC
C1334 FORMAT(1X,'EC =',F12.6)
      DLR    = DELR
      HH     = H*H
      HH6    = HH /6.0D0
      HH8    = HH /8.0D0
      HH24   = HH /24.0D0
      MN     = DLR/H
      NM     = RM/H
      NINT   = RINT/H
       INORM =  0

      DO93  I=1,NSTATE
       KI0   =  1
      KK     =   KSTATE(I)
cbd      WVK1   =   DSQRT(AH2*DABS(VVAL(I,I,KI0)-EC))
      WVK1   =   DSQRT(AH2*DABS(EC))
      RINTW  =   RINT*WVK1/2.D0
      A1     =   DEXP( RINTW)*RINTW**KK
      ANORM(I) = 1.D0/A1
  93   CONTINUE
 2000  CONTINUE
       K     =  0
C      K     =   KSTATE(NSTATE)
      DO 3 IL=1,NSTATE
      DO 3  I=1,NSTATE
      AK     =   KSTATE(I)
      XI(I,IL)=   0.000000000000D0
      XID(I,IL) =   0.000000000000D0
      IF(I-IL) 2,1,2
C 1   KI0    =  (K+2)*2
C     RI0    =   K+2
  1   KI0    =        2
      RI0    =     1
      RI0H   =   RI0*H
cbd      WVK1   =   DSQRT(AH2*DABS(VVAL(I,I,KI0)-EC))
      WVK1   =   DSQRT(AH2*DABS(EC))
      KK     =   KSTATE(I)
      RINTW  =   RINT*WVK1/2.D0
C     ANORM  =   DEXP( RINTW)*RINTW**KK
      RI0W   =   RI0H*WVK1
      RIMH   =   RI0H-H2
      IF(RI0W .GT.0.5D0)GO TO 1000
      DD     =   RI0W**2/(4.D0*(RI0+1.D0))
      XI(I,IL)  = RI0W**(AK + 1.D0)*(1.D0-DD) * ANORM(I)
      XID(I,IL) = RI0W**AK*(AK + 1.D0)*(1.D0-(RI0+2.5D0)*DD/(RI0+0.5))
      XID(I,IL) = XID(I,IL)*WVK1 * ANORM(I)
      GO TO 2
 1000 XI(I,IL)  = DEXP( RI0W)/DSQRT(RI0W) * ANORM(I)
      XID(I,IL) = WVK1* XI(I,IL)*(1.D0-0.5D0/RI0W/DSQRT(RI0W))
  2   CONTINUE
      F(I,I) =   AH2*(VVAL(I,I,KI0)-EC)+CL(I,KI0)
      FM(I,I) =   AH2*(VVAL(I,I,KI0-1)-EC)+CL(I,KI0-1)
  3   CONTINUE
      DO 9 I = 1,NSTATE
      DO 9 J = 1,NSTATE
C     WRITE(6,333)NSTATE,I,J
C333   FORMAT(1X,'NS=',3I5/)
      IF (I-J) 9,9,33
  33  F(I,J) = AH2 * VVAL(I,J,KI0)
      F(J,I) = F(I,J)

      FM(I,J) = AH2 * VVAL(I,J,KI0-1)
      FM(J,I) = FM(I,J)
C9999 CONTINUE
  9   CONTINUE
      DO 5     IL=1,NSTATE
      DO 5      I=1,NSTATE
      S(I,IL)  = 0.0D0
      DO 55     J=1,NSTATE
      SI =XI(J,IL)*F(I,J)
      S(I,IL)=S(I,IL)+SI

  55  CONTINUE
      XIM(I,IL) = XI(I,IL)+H2*XID(I,IL)+HH8*S(I,IL)
      FUN(I,IL,1) = XI(I,IL)
  5   CONTINUE

      JJJ = 0
      KKK = 1
      NMN    =    2
C     NMN    =  K+3
C     IF(NMN .GT. IFUN) KKK = NMN/IFUN + 1
      IFU1   = IFUN*KKK
      DO 88     N=NMN,NINT
       JJJ   =   JJJ + 1
      RN     =  N
      NN     =  N*2
      RNH    =  RN*H
      RNM    =  RNH-H2
      DO 6     IL=1,NSTATE
      DO 6      I=1,NSTATE
      SM(I,IL)  = 0.0D0
      DO 66     J=1,NSTATE
      SI =XIM(J,IL)*FM(I,J)
      SM(I,IL)=SM(I,IL)+SI

  66  CONTINUE
      XI1(I,IL) = XI(I,IL)+H2*XID(I,IL)+HH24*(4.0D0*S(I,IL)-SM(I,IL))

  6   CONTINUE
      DO 7 I = 1,NSTATE
      F1(I,I) =   AH2*(VVAL(I,I,NN-1)-EC)+CL(I,NN-1)
      F2(I,I) =   AH2*(VVAL(I,I,NN)-EC)+CL(I,NN)
      DO 7 J = 1,NSTATE
      IF (I-J) 7,7,77
  77  F1(I,J) = AH2 * VVAL(I,J,NN-1)
      F1(J,I) = F1(I,J)
      F2(I,J) = AH2 * VVAL(I,J,NN)
      F2(J,I) = F2(I,J)
  7   CONTINUE
      DO 8     IL=1,NSTATE
      DO 8      I=1,NSTATE
      S1(I,IL)  = 0.0D0
      DO 89     J=1,NSTATE
      SI =XI1(J,IL)*F1(I,J)
      S1(I,IL)=S1(I,IL)+SI

  89  CONTINUE
      XI2(I,IL) = XI(I,IL)+H*XID(I,IL)+HH6*(S(I,IL)+2.0D0*S1(I,IL))

  8   CONTINUE
      DO 10    IL=1,NSTATE
      DO 10    I=1,NSTATE
      S2(I,IL)  = 0.0D0
      DO 100    J=1,NSTATE
      SI =XI2(J,IL)*F2(I,J)
      S2(I,IL)=S2(I,IL)+SI

 100  CONTINUE
      XID1(I,IL) = XID(I,IL)+H6*(S(I,IL)+4.0D0*S1(I,IL)+S2(I,IL))

 10   CONTINUE

  17  IF(N   .EQ. IFU1)GO TO 45
      IF(JJJ .EQ. IFUN)GO TO 45
      GO TO 98
  45  RNN = RNH
      DO 299 IL= 1,NSTATE
      DO 299 I = 1,NSTATE
C?    FUN(I,IL,KKK) = XI2(I,IL)
      FUN(I,IL,N  ) = XI2(I,IL)
      DD        = XID(I,IL)
  299 TT        = XI2(I,IL)
      JJJ     = 0
      KKK     = KKK + 1

  98  CONTINUE
      DO499 I = 1,NSTATE
      DO499 J = 1,NSTATE
      XIM(I,J)=XI1(I,J)
      XI(I,J) =XI2(I,J)
      XID(I,J)=XID1(I,J)
      FM(I,J) =F1(I,J)
      F  (I,J)=F2  (I,J)
      SM(I,J) =S1(I,J)
  499 S  (I,J)=S2  (I,J)

 88   CONTINUE
C 9   CONTINUE
C *** NEW 25.2.89
        IF( INORM .NE. 0 ) GO TO 1585
      DO1599 IL= 1,NSTATE
      AMAX  = 0.D0
      DO1598 I = 1,NSTATE
      A1=DABS     (XI2(I,IL))
       IF(A1 - AMAX)1598,1598,1597
 1597 AMAX = A1

 1598 CONTINUE
      ANORM(IL) = ANORM(IL)/AMAX

 1599 CONTINUE
      INORM = 1
        GO TO 2000
C
 1585 CONTINUE
C
      DO 599 IL= 1,NSTATE
      DO 599 I = 1,NSTATE
C     IF(EC .GT.0.D0)GO TO 2011
      XIF1(I,IL) = XI2(I,IL)
c     XIF2(I,IL) = XID(I,IL)
C*********************************** altered IJT 22 Oct 93
      XIF2(I,IL) = XID1(I,IL)
C     GO TO 599
C     WRITE(6,1011)XIF1(I,IL),XIF2(I,IL)
C1011 FORMAT(1X,'XI=',G15.5,'XID=',G15.5)
C2011 XIF2(I,IL) = XI2(I,IL)


  599 CONTINUE
      deallocate( XI,XID,XIM,
     * FM,F,F1,
     * SM,S,S1,XID1,
     * XI1,XI2,F2,S2,
     * ANORM)      



C     DEBUG INIT(TT,RNN,DLR,DD,NINT,NM)
C     DEBUG INIT(NN)
C     DEBUG SUBTRACE , SUBCHK
      RETURN
      END

*==> cdot.f <==
       FUNCTION CDOTD(Z,A,B,N,IASTEP,IBSTEP,ID1)
C
      IMPLICIT DOUBLEPRECISION(A-H,O-Z)
      DIMENSION A(ID1,IASTEP),B(ID1,IBSTEP)
C     DIMENSION A(2),B(2)
      W = 0D0
       IF (N .LE. 0) GO TO 2
      DO 1 J = 1,N
C     IA = 1 + (J-1)*IASTEP
C     IB = 1 + (J-1)*IBSTEP

C     W = W+A(1+(J-1)*IASTEP)*B(1+(J-1)*IBSTEP)
      W = W+A(1, J          )*B(   J,1)
 1    CONTINUE
 2    CDOTD = Z + W
C     DEBUG INIT(IA,IB)
       RETURN
        END

*==> cmlin.f <==
       SUBROUTINE CMLID(A,B,IDIM1,N,M,DET,V,MODE,IFAIL)
C DETERMINANT OF THE DOUBLE PRECISION MATRIX A AND SOLUTION OF A*Z=B
C  OPTIONS : 1)REPLACING B BY SOLUT. Z
C            2) "  = "   A BY ITS INVERSE
      IMPLICIT DOUBLEPRECISION (A-H,O-Z)
      LOGICAL DSCALE, NOTINV
      DIMENSION A(IDIM1,N    ), B(IDIM1,M+1), V(N)
C++   DIMENSION A(IDIM1,N    ), B(IDIM1,M), V(N)
!      DATA CONST/1.D-100/
      DATA CONST/1.D-200/
 1100 NMINUS = N-1
      IFAIL  = 0
      DSCALE = (MODE .GE. 2)
      NOTINV = (MODE .EQ. 0).OR.(MODE .EQ. 2)
      PTEST  = (4.0D0*CONST*DFLOAT(N))**2
C
      IF((N .LT. 1).OR.(M .LT. 0).OR.(MODE .LT. 0).OR.
     *   (MODE .GT. 3)) GO TO 5100
C    CASE N = 1
C
C     WRITE(6,3)N
C  3  FORMAT(1X,'MMM 1100, N=',I2)
 1200 IF(N .NE. 1) GO TO 1300
      DET = A(1,1)
C     WRITE(6,1)
C1    FORMAT(1X,'MMMM 1200')
      VER    = DET
      IF (DABS(VER).EQ. 0.) GO TO 5201
      A(1,1) = 1.D0/A(1,1)
      IF (M .EQ. 0) RETURN
C
 1210 DO 1219 K = 1,M
      B(1,K) = A(1,1) * B(1,K)
 1219 CONTINUE
C
      RETURN
C
C SET V(I)=1/R(I)**2, WHERE R(I) IS THE LENGTH OF ROW I, I=1(1)N.
C
 1300 DO 1309 I = 1,N
C     WRITE(6,2)N
C  2  FORMAT(1X,'MMMMM 1300, N=',I2)
      SUM = 0.
 1310 DO 1319 J = 1,N
      SUM = SUM +A(I,J)**2
 1319 CONTINUE
      V (I) = 1./SUM
 1309 CONTINUE
C
C ******************************************************************
C
C  REPLACE A BY TRIANGULAR MATRICES (L,U)   A = L*U
C    "     L(I,I) BY 1/L(I,I), I= 1(1)N, READ Y FOR SECT. 3 & 4
C  ARE PLACED IN V.)
C
 2000 DET = 1.0D0
C
 2010 DO 2019 K = 1,N
      KPLUS = K + 1
      KMINUS = K - 1
      L     = K
      PSQMAX = 0.
C
      IR = K
      IR = 2020
 2020 DO 2029 I = K,N
      CTEMP  = -CDOTD(-A(I,K),A(I,1),A(1,K),KMINUS,N,1,IDIM1)
      A(I,K) = CTEMP
      PSQ    = V(I) * CTEMP**2
      IF (PSQ .LE. PSQMAX) GO TO 2029
      PSQMAX = PSQ
      L      = I
 2029 CONTINUE
C
      VTEMP  = V(K)
      IF (L .EQ. K) GO TO 2011
C
      IR = 2040
 2040 DO 2049 J = 1,N
      CTEMP  = A(K,J)
      A(K,J) = A(L,J)
      A(L,J) = CTEMP
 2049 CONTINUE
C
      VTEMP  = V(L)
      V(L)   = V(K)
      DET    = -DET
C
 2011 DET    = A(K,K)*DET
      IF (DSCALE) DET =DSQRT(VTEMP)*DET
      V(K)   =DFLOAT(L)
C
C TEST FOR SINGULARITY
C
      IF (PSQMAX .LE. PTEST) GO TO 5200
C
      CTEMP = 1.0D0/A(K,K)
      A(K,K)= CTEMP
      IF (KPLUS .GT. N) GO TO 2019
C
      IR = 2050
 2050 DO 2059 J = KPLUS,N
      A(K,J) = -CTEMP * CDOTD(-A(K,J),A(K,1),A(1,J),KMINUS,N,1,IDIM1)
 2059 CONTINUE
C
 2019 CONTINUE
C
C ********************************************************************
C
C REPLACE B BY SOLUTION Z OF A*Z=B. SKIP IF M=0.
C
 3000 IF (M .EQ. 0) GO TO 4000
C
C INTERCHANGE ROWS OF B AS SPECIFIED BY V.
C
 3100 DO 3109 I = 1,N
      VE   =V(I)
      IROW  =IDINT(VE)
      IF (IROW .EQ. I) GO TO 3109
C
       IR = I
       IR = 3110
 3110 DO 3119 K = 1,M
      CTEMP = B(I,K)
      B(I,K)= B(IROW,K)
      B(IROW,K) = CTEMP
 3119 CONTINUE
C
 3109 CONTINUE
C
C REPLACE B BY SOL. Y OF L*Y=B

 3200 DO 3209 K = 1,M
C
 3210 DO 3219 I = 1,N
      B(I,K)  = -A(I,I)*CDOTD(-B(I,K),A(I,1),B(1,K),I-1,N,1,IDIM1)
 3219 CONTINUE
C
C REPLACE Y BY SOL. Z OF U*Z=Y
C
       IR = K
       IR = 3300
       IR = NMINUS
 3300 DO 3309 L = 1,NMINUS
      I      = N - L
       IR = I
      B(I,K) = -CDOTD(-B(I,K),A(I,I+1),B(I+1,K),L,N,1,IDIM1)
 3309 CONTINUE
C
 3209 CONTINUE
C
C ********************************************************
C
C REPLACE A BY ITS INVERCE AINV. SKIP IF MODE EQ. 0 OR 2.
C
       IR = 4000
 4000 IF (NOTINV) GO TO 6000
C
C REPLACE L & U BY THEIR INVERSES LINV & UINV
C
 4100 DO 4109 K = 1,NMINUS
      KPLUS  = K + 1
C
 4110 DO 4119 I = KPLUS,N
      A(I,K)    = -A(I,I)*CDOTD(0.D0,A(I,K),A(K,K),I-K,
     *                         N,1,IDIM1)
      A(K,I)    = -CDOTD(A(K,I),A(K,KPLUS),A(KPLUS,I),I-K-1,N,1,IDIM1)
 4119 CONTINUE
C
 4109 CONTINUE
C
C FORM AINV = UINV*LINV
C
 4200 DO 4209 K = 1,N
C
 4210 DO 4219 I = 1,N
      IF(I .GE. K) GO TO 4212
 4211 A(I,K) = CDOTD(0.D0,A(I,K),A(K,K),N-K+1,N,1,IDIM1)
      GO TO 4219
 4212 A(I,K) = CDOTD(A(I,K),A(I,I+1),A(I+1,K),N-I,N    ,1,IDIM1)
 4219 CONTINUE
C
 4209 CONTINUE
C
C INTERCHANGE COLUMNS OF AINV AS SPEC. BY V, BUT IN REVERSE ORDER
C
 4300 DO 4309 L = 1,N
      K  = N - L + 1
      KCOL =IDINT( V(K) )
       IF (KCOL .EQ. K) GO TO 4309
C
 4310 DO 4319 I = 1,N
      CTEMP  = A(I,K)
      A(I,K) = A(I,KCOL)
      A(I,KCOL) = CTEMP
 4319 CONTINUE
C
C     WRITE(6,4555)
C4555 FORMAT(1X,'***** 4309 *****'/)
 4309 CONTINUE
C
      RETURN
C
C ********************************************************
C
C ERROR MESSAGES
C
C 1.NON PERMISSIBLE PARAMETERS
C
 5100 WRITE(4,5190) N, M, MODE
 5190 FORMAT(/ 1X,'***CMLID*** NON-PERMISSIBLE VALUE OF N, M, OR MODE.'
     1       / 6X,'N  =',I5
     2       / 6X,'M  =',I5
     3       / 6X,'MODE =',I5/)
      RETURN
C
C 2. MATRIX IS SINGULAR
C
 5200 DET = 0.
 5201 IF ( (M .EQ. 0) .AND. (NOTINV) ) RETURN
      WRITE(4,5290) PSQMAX,PTEST
 5290 FORMAT( / 1X '***CMLID*** MATRIX IS SINGULAR***'/,
     * ' AS ',1P,E12.4,' < ',E12.4)
C     DEBUG INIT (A,B,DET,IROW)
C     DEBUG INIT (PSQ,PSQMAX,CTEMP,IR,NOTINV)
!      STOP 'CMLID'
       IFAIL = 1
 6000   continue
       RETURN
C *************************** END **************************************
         END

      FUNCTION VVAL(IM,JM,N)
     *                
      use susycom, only: vk,nm2,nstvk,Nkmaxss
      IMPLICIT DOUBLEPRECISION (A-H,O-Z)
      
      IF((IM.GT.1).AND.(JM.GT.1))GO TO 65
      IF(N .gt.NM2) GO TO 4
      KK=IM + JM - 1
       if(KK.gt.nstvk) go to 1005
      VVAL       = VK(KK, N)
      VREAD   =  VVAL
      RETURN
  65  IM1 = IM
      JM1 = JM
      IF(IM .LE. JM) GO TO 66
      IM1 = JM
      JM1 = IM
  66  I1  = IM1- 1
      K   = 0
      N1  = Nkmaxss
      DO 6 K1 = 1,I1
      K   = K + N1
   6  N1  = N1- 1
       KK=K - IM1+ JM1+ 1
       if(KK.gt.nstvk) go to 1005
       
   3  VVREAD= VK(KK ,N)
      VVAL   = VVREAD
      RETURN
 9001 VVREAD = 0.D0
      VVAL = VVREAD
      RETURN
 1000 WRITE(6,1001)
 1001 FORMAT(10X,' ***** VVREAD: DRO/DROPOT < 1 ****'//)
      RETURN
    4 VVAL = 0.d0
c      WRITE(6,1004) N,NM2
      
 1004 FORMAT(10X,' ***** VVREAD: N (',I5,')>',I5,' ****'//)
      RETURN
C     DEBUG INIT(NBEG,NREL,NFIN1,NBEG3)
 1005  write(6,*)' ***** VVREAD: KK (',KK,')>nstvk',nstvk,'IM,JM ****'
     * ,IM,JM
      END
