 	subroutine  readvar
	use physics
	use methodspec
	use work
	use twobody_states
!-------------------------------------------------
	implicit real*8 (a-h,o-z)    
!------------------------------------------------- Definitions
	integer pair,omit_l(momit),omit_c1(momit),omit_c2(momit),it(1000)
	character*10 kind
	character search
	real*8 jv,omit_s(momit),omit_j(momit)
	logical rescale,test
        type(specifics):: bs
	real*8 vdef(0:5)

	namelist/fname/nfile,desc
	namelist/scale/amn,hc,etacns
	namelist/nuclei/name,mass,z,radius
	namelist/identical/id,iso
	namelist/total/ngt,gtot,gparity,meigs,ndrop
	namelist/particles/ns,spin,parity,energy
	namelist/em/corek,def,Qmom,Mmom,volcon
	namelist/waves/nc,auto,sym,lx,ly,lt,sx,jp,icy,icx1,icx2,np,  &
     &		lxmax,lymax,ltmax,sxmax,jabmax,kmaxa,kmax
	namelist/poten/typc,pa,ps,pp,pd,pf,typso,pso,psop,psod,psof, &
     &   	       typss,pss,psss,pssp,pssd,pssf, &
     &			typt,pt, rcoul,acoul, detail, lpot
	namelist/pot3b/typ3b,s3b,r3b,a3b,gtvary
	namelist/gamso/gamso1,gamso2
!-------------------------------------------------  Method namelists:
	namelist/grids/rr,nlag,njac,rinner,rscreen,ascreen
	namelist/trace/potparts,vertex,pripot,vadia
	namelist/continuum/ docont,emin,emax,dec,bel,sigma
	namelist/b2states/ dx,xmax,dy,ymax,rnode,ipc,lmax,kapp,nk,de,n2states,potfile,rwpot,dxf
	namelist/b2state/ pair,kind,de,nk,ipc,test,n,nvchan,rnode,l,lmax,s,jv,search, & 
     &                    eigen,potential,rescale,nomit,omit_l,omit_s,omit_j,omit_c1,omit_c2,fermi
	namelist/solve/ eig,eimin,eimax,eqn,reduced,cfiles,nbmax,meigs, & 
     &          kmaxf,efesh,adias,kmaxeff,ndrop,shift
!------------------------------------------------- Title & version
	write(6,110)
110	format(' FACE: version 0.13c2'/)
!------------------------------------------------- Initialise defaults
        hc = 197.32705d0
        amn = 931.49432d0
        etacns = 0.157454
        
	eqn = 'F'
	reduced = .false.
	init = 0
	kmaxf(:) = -1; efesh=0.; kmaxeff(:)=-1
	do i=1,3
	 auto(i)=.false. ; id(i)=.false.; volcon(i)=.true.
	 enddo
	docont = .false.
	potparts = .false. 
	vertex = .false. 
	pripot = .false. 
	vadia = .false. 
	gtvary = .false.
	rinner = 0.0
	sym(1) = 'X'; sym(2) = 'Y'; sym(3) = 'T'; sym(0) = 'F'
	do ib=1,3
	do ich=1,mfchan
	  icx1(ich,ib) = 1 ; icx2(ich,ib) = 1 ; icy(ich,ib) = 1 
	enddo
	auto(ib)=.false.
	nc(ib)=0
	meigs(:) = 0
	meigs(1) = 1
	kmaxa(ib) = 0; kmax(:,ib) = -1
	lxmax(ib)=maxl; lymax(ib)=maxl; ltmax(ib)=maxl; jabmax(ib)=maxl
	 rcoul(ib)=0d0; acoul(ib)=0d0; lpot(ib)=0
	  do i=1,6
	  pa(i,ib)=0d0; ps(i,ib)=0d0; pp(i,ib)=0d0; pd(i,ib)=0d0; pf(i,ib)=0d0
	  pso(i,ib)=0d0; pss(i,ib)=0d0; pt(i,ib)=0d0
	  enddo
	do i=0,3
	 subst_pl(i,ib) = .false.
	 enddo
	enddo
	typc='nul'; typso='nul'; typss='nul'; typt='nul'; typ3b='nul'
	 def_pa = .false.
	do ijt=1,mjtp
	 s3b(ijt)=0d0; r3b(ijt)=0d0; a3b(ijt)=0d0
	enddo
	emin=-100d0; emax = -100d0
	eimin=-100d0; eimax = 0d0
	eig = -1001.; sigma = -1
	n2states = 0
	shift = 1000.
	ndrop(:) = -1
	rwpot = ' '
	potfile = ' '
	forb(:) = .false.
	ymax = 0d0; dy=1.0
	dx=0.1;  xmax=10.0; rnode=5.0; kapp=0.; lmax=maxl; dxf=-1
!------------------------------------------------- Read namelists!
!	open(1,file='trial2.i',status='old')
!	open(2,delim='apostrophe',recl=80,file='namelist.out')
!	open(10,recl=133,file='for010.dat')
	read(5,nml=fname,iostat=ios,end=1,err=1)
   1     if (ios.ne.0) write (6,*) ' Input FNAME nml read error: ',IOS
	nfile = nfile(1:19)
!	write(6,*) 'Open file 10 as <'//trim(nfile)//'.lis> from <'//nfile//'> as <'//trim(nfile)//'>'
	open(10,recl=133,file=trim(nfile)//'.lis')
	open(2,file=trim(nfile)//'.nl')
	 write(2,nml=fname)
	read(5,nml=scale)
	 write(2,nml=scale)
	read(5,nml=nuclei)
	 write(2,nml=nuclei)
	read(5,nml=identical)
	 write(2,nml=identical)
	read(5,nml=total,iostat=ios,end=5,err=5)
   5     if (ios.ne.0) write (6,*) ' Input TOTAL nml read error: ',IOS
	 write(2,nml=total)
	read(5,nml=particles)
!	read(5,nml=particles,IOSTAT=ios,end=10,err=10)
!   10     if (ios.ne.0) write (6,*) ' Input PARTICLES nml read error: ',IOS
	 write(2,nml=particles)
!				Some default parameters:
	do ib=1,3
	  sxmax(ib)=maxval(spin(1:ns(pairs(1,ib)),pairs(1,ib))) +   &
	       maxval(spin(1:ns(pairs(2,ib)),pairs(2,ib)))
	enddo
	read(5,nml=em)
	 write(2,nml=em)
	read(5,nml=waves,IOSTAT=ios,end=12,err=12)
   12     if (ios.ne.0) write (6,*) ' Input WAVES nml read error: ',IOS
	 write(2,nml=waves)
	read(5,nml=poten,IOSTAT=ios,end=13,err=13)
   13     if (ios.ne.0) write (6,*) ' Input POTEN nml read error: ',IOS
	 write(2,nml=poten)
	read(5,nml=pot3b)
	 write(2,nml=pot3b)
	read(5,nml=gamso)
	 write(2,nml=gamso)
!			now read variables for the method
	read(5,nml=grids)
	 write(2,nml=grids)
	read(5,nml=trace,IOSTAT=ios,end=14,err=14)
   14     if (ios.ne.0) write (6,*) ' Input TRACE nml read error: ',IOS
	 write(2,nml=trace)
	read(5,nml=continuum,iostat=ios)
      if (ios.ne.0) write (6,*) ' Input CONTINUUM nml read error: ',IOS
	 write(2,nml=continuum)
	 ipc=0;nk=0;de=0

	read(5,nml=b2states,iostat=ios)
      if (ios.ne.0) write (6,*) ' Input B2STATES nml read error: ',IOS
	 write(2,nml=b2states)
	    rnode1=rnode;ipc1=ipc; lmax1=lmax; nk1=nk; de1=de ! global defaults
	    
	 if(rwpot=='r'.or.rwpot=='R') then
	   do i2s=1,n2states
	      read(5,nml=b2state)  ! but ignore this input file namelist!!
	   enddo
	 else
	 nocc = 0; ntran = 0
	 do i2s=1,n2states
	    rnode=rnode1;ipc=ipc1; lmax=lmax1; nk=nk1; de=de1 ! global defaults
! local defaults:	    
	    n=1;nvchan=1;l=0; nomit=0; search='E'; potential=1.; eigen=0.
	    s=0;jv=0
	    rescale=.false.; test=.false.;fermi=-900.
	  read(5,nml=b2state)
     	call flush(6)
	  write(2,nml=b2state)
	  if(kind(1:3)=='occ') s_kind=0
	  if(kind(1:3)=='tra') s_kind=1
	  if(kind(1:3)=='pot') s_kind=-1
	  isc=1           ! search on 'V'
	  if(search == 'E') isc=2 ! search on E

	   if(s_kind==0) nocc=nocc+1
	   if(s_kind==1) ntran=ntran+1
	  twbod(i2s) % inf =                    & 
   &      specifics(pair,s_kind,n,nvchan,l,lmax,s,jv,rnode,fermi,&
   &             isc,nomit,omit_l,omit_c1,omit_c2,omit_s,omit_j,        &
   &             eigen,potential,de,rescale,test,nk,ipc)

	 enddo
	 endif
	read(5,nml=solve,iostat=ios)
      if (ios.ne.0) then
         write (6,*) ' Input SOLVE nml read error: ',IOS
         cfiles=.false.;nbmax=0;adias=0
       endif
	 write(2,nml=solve)
	 close(2)
!	 allocate (twbod(1)%ybs(10,10))
!-------------------------------------  ----------- Intermediate calculations
	h2sm = hc**2 * 0.5d0 / amn
	masstot = sum(mass)
!	masstot = mass(1)+mass(2)+mass(3)
!	write(6,*)  '   masstot=',masstot,' sum(mass)=',sum(mass)
!	nplag = nint(rinner/rr)
!	if(nplag.lt.1 .or. .not.cfiles) then
!	   nplag=nlag
!	 else if(nplag.ne.0) then
!	   rr = rinner/nplag
!	 endif
!	   rinner = rr*nplag
	 nplag = nlag
	 kkmax=-1
	 do ib=1,3
	 do l1=0,min(lxmax(ib),maxl)
	  kkmax = max(kkmax,kmax(l1,ib),kmaxa(ib))
	 enddo
	 enddo

	call potdef(-1,mmultipole,0d0,vdef,vdef,1)
	do ip=1,3
	do i=mmultipole,2,-1
 	 qmax(ip)=i
	 if(abs(def(qmax(ip),ip)).gt.1e-10) go to 96
	enddo
	 qmax(ip)=0
96	enddo
	do ib=1,3
	 qmaxb(ib) = max( qmax(pairs(1,ib)), qmax(pairs(2,ib)) )
	enddo
	nx=0; ny=0
	if(n2states>0) then
!	  if(ymax.lt.0.) ymax = rinner
      	  nx = xmax/dx+1.5
!       	  ny = ymax/dy+0.5
	 endif

	 if(nbmax==0) cfiles=.true.
	 if(cfiles) nbmax=0
	 if(.not.cfiles.and.nbmax>0) then
	 	nbmax = max(nbmax,5)
		endif
	 if(eig<-1000.) eig=eimin
	 fesh = maxval(kmaxf(:))>=0
	 effp = maxval(kmaxeff(:))>=0
	 effd = maxval(ndrop(:))>0

!-------------------------------------  ----------- OUTPUT!
!	call cpuuse
	write(6,111) nfile,desc
111	format(' Case file: ',a20//1x,a80)
	write(6,113) amn,hc,h2sm
113	format(/'  with constants:',/,'  unit mass =',f9.2,' MeV;  hc =',f9.3,' MeV.fm =>  h2sm =',f8.4)
	write(6,114) 1,2,3,name,mass,z,radius
114	format(/'         ',3(i3,5x)/'  Nuclei:',2x,3a8/'  masses ',3f8.4     &
     &	       /'  charges',3f8.1/'  radii  ',3f8.4/)
	write(6,115) ((pairs(i,j),i=1,2),id(j),j=1,3),iso
115	format( '  Identical ',3(2i1,': ',l1,',  '),     &
     &         /'    isospin',3(f6.1,2x))
	write(6,120) ngt,(gtot(ijt),psign(gparity(ijt)+2),meigs(ijt),ijt=1,ngt)
 120   format(/1x,i2,' coupled channels J,pi sets:',10(f5.1,a1,' #',i3))
	
	write(6,*)
	do 140 ip=1,3
	write(6,125) ip,name(ip),ns(ip)
125	format(/'  Particle',i2,': ',a8,' has',i2,' states:')
	write(6,128) (spin(i,ip),psign(parity(i,ip)+2),energy(i,ip),i=1,ns(ip))
128	format('   -- spin,parity,energy =',5(f4.1,a1,' @',f8.4,' MeV',:,';'))
 130     format('   -- Intrinsic K =',f4.1,'  Quadrupole moment =',f8.3,&
	&   ' Magnetic moment =',f8.3,:,/'   -- deformation lengths =',5f10.5,' fm')

	write(6,130) corek(ip),Qmom(ip),Mmom(ip),(def(i,ip),i=2,qmax(ip))
140	enddo
	write(6,160)
160	format(/'  Partial waves:')
	do 200 ib=1,3
	if(auto(ib)) then
	  write(6,165) ib,sym(ib),lxmax(ib),lymax(ib),ltmax(ib),sxmax(ib),jabmax(ib), &
			kmaxa(ib),(kmax(i,ib),i=0,min(maxl,lxmax(ib)))
165	  format('  Component',i2,1x,a1,': lx,ly,lt <=',3i3,', sx,jp <=',2f4.1,   &
			', Kmax(all,0:lx) =',15i3)
	else
	  write(6,170) ib,sym(ib),nc(ib)
170	  format('  Component',i2,1x,a1,': ',I2,' sets:'/  &
	          6x,2x,'  lx  ly  lt  sx  jp icx1 icx2  icy   np')
	  do 180 i=1,nc(ib)
	  write(6,185) i,lx(i,ib),ly(i,ib),lt(i,ib),sx(i,ib),  &
     &		jp(i,ib),icx1(i,ib),icx2(i,ib),icy(i,ib),np(i,ib)
180	  enddo
185	  format(1x,i5,'::',3i4,2f4.1,3i5,i5)
	endif
200	enddo
	write(6,300)
300	format(//' POTENTIALS')
	do 400 ip=1,3
  	write(6,310) ip,(name(pairs(in,ip)),in=1,2),detail(ip)
310	format(/' Potential ',i1,' between ',a8,' and ',a8,':'/3x,a80)
	if(z(pairs(1,ip))*z(pairs(2,ip))/=0)  &
	write(6,312)  rcoul(ip) !,acoul(ip)
312	format('  Coulomb potential of sphere with R =',2f8.4)
	write(6,315)  typc(ip)
315	format('  Central potential of type ''',a3,''' , ')
	def_pa      = sum(abs(pa(1:6,ip))) > 1d-9
	subst_pl(0,ip) = sum(abs(ps(1:6,ip))) > 1d-9
	subst_pl(1,ip) = sum(abs(pp(1:6,ip))) > 1d-9
	subst_pl(2,ip) = sum(abs(pd(1:6,ip))) > 1d-9
	subst_pl(3,ip) = sum(abs(pf(1:6,ip))) > 1d-9
	if(def_pa) write(6,320) 'all',(pa(i,ip),i=1,6)
	if(subst_pl(0,ip)) write(6,320) 's',(ps(i,ip),i=1,6)
	if(subst_pl(1,ip)) write(6,320) 'p',(pp(i,ip),i=1,6)
	if(subst_pl(2,ip)) write(6,320) 'd',(pd(i,ip),i=1,6)
	if(subst_pl(3,ip)) write(6,320) 'f',(pf(i,ip),i=1,6)
320	format('   for ',a3,'-waves:',7f10.5)
	write(6,321) lpot(ip)
321	format('   using lpot = ', i3)
	do i=1,3
	t = 1.
	t = vc(0,t,i)   ! perform initial read for any potential files.
	enddo

	write(6,325)  'Spin-orbit',typso(ip)
325	format('  ',a10,' potential of type ''',a3,''' , ')
	if(typso(ip).ne.'nul') then
	if(abs(pso(1,ip)).gt.1d-9) write(6,320) 'all',(pso(i,ip),i=1,6)
	if(abs(psop(1,ip)).gt.1d-9) write(6,320) 'p',(psop(i,ip),i=1,6)
	if(abs(psod(1,ip)).gt.1d-9) write(6,320) 'd',(psod(i,ip),i=1,6)
	if(abs(psof(1,ip)).gt.1d-9) write(6,320) 'f',(psof(i,ip),i=1,6)
327	  format('  ',6f12.5)
	  write(6,330) name(pairs(1,ip)),gamso1(ip),name(pairs(2,ip)),gamso2(ip)
330	  format('    acting',2(' on ',a8,' with factor',f8.4,:,','))
	endif

	write(6,325)  'Spin-spin ',typss(ip)
	if(typss(ip).ne.'nul') then
	if(abs(pss(1,ip)).gt.1d-9) write(6,320) 'all',(pss(i,ip),i=1,6)
	if(abs(psss(1,ip)).gt.1d-9) write(6,320) 's',(psss(i,ip),i=1,6)
	if(abs(pssp(1,ip)).gt.1d-9) write(6,320) 'p',(pssp(i,ip),i=1,6)
	if(abs(pssd(1,ip)).gt.1d-9) write(6,320) 'd',(pssd(i,ip),i=1,6)
	if(abs(pssf(1,ip)).gt.1d-9) write(6,320) 'f',(pssf(i,ip),i=1,6)
	endif

	write(6,325)  'Tensor    ',typt(ip)
	if(typt(ip).ne.'nul') write(6,327)  (pt(i,ip),i=1,6)
400	continue

	write(6,440) typ3b
440	format(/' Three-body potential of type ''',a3,''' , ')
	if(typ3b.ne.'nul') write(6,445) gtvary,(s3b(i),r3b(i),a3b(i),i=1,ngt)
445     format('   vary with J/pi? = ',L1,(/'   s3b,r3b,a3b =',3f10.5))

	write(6,202)
202	format(//'  METHOD parameters:')
	write(6,207)rr,nlag
207	format(/'  Hyperradial parameters =',f8.4,i5)
	write(6,*)' Hyperangular points =',njac	
!	if(cfiles) write(6,*)' radius of inner region =',real(rinner),nplag

	if(nbmax.ne.0) then
 	 if(docont) then
      	  write(6,258) emin,emax,dec
  258	  format(/'  Discretised response from',f7.3, &
       		' to ',f8.3,' in steps of ',f7.3,' MeV.'/)
      	  if(sigma>0) write(6,259) sigma
  259	  format(/'    Give Lorentz transform with sigma =',f8.3,' MeV')
	  write(6,*)
 	  endif
	  write(6,*) ' nbmax =',nbmax,', eig =',real(eig)
	  write(6,*)
	  write(6,*) ' nlag =',nlag,' recommend: >> nbmax =',nbmax
	  if(nbmax>nlag) then
 		write(6,*) ' nlag =',nlag,' must be > nbmax =',nbmax
		stop
		endif
	else
           close (20,status='delete') 
	endif
 	if(kapp.le.1d-3) kapp = 1d-3
	if(eqn==sym(1)) init=1
	if(eqn==sym(2)) init=2
	if(eqn==sym(3)) init=3
	write(6,*) ' njac =',njac,' recommend: >> kmax/2 =',kkmax/2
        write(6,*) '   (but much more, for repulsive-core interactions)'
	write(6,*)
	write(6,*)' Equations to solve = ',eqn,'=',sym(init),'  (F=Faddeev, ',&
     		'T,X,Y-Schrodinger+orthoNormal) '
	  if(njac<kkmax/2) then
 		write(6,*) ' njac =',njac,' must be > kkmax/2 =',kkmax/2
		stop
		endif
	if(reduced.and.init>0) write(6,*)' Reduced to equations = ',eqn,'=',sym(init)
	if(nbmax.ne.0) then
	  do ijt=1,ngt
	  if(meigs(ijt)==0) write(6,270) gtot(ijt),psign(gparity(ijt)+2)
 270	  format(/'  For ',f4.1,a1,' search for all eigenstates,')
	  if(meigs(ijt)/=0) write(6,275) gtot(ijt),psign(gparity(ijt)+2),meigs(ijt),eig
 275	  format(/'  For ',f4.1,a1,' search for ',i4,' eigenstates near',f8.3,' MeV,')
	  enddo
	  write(6,280) eimin,eimax
 280	  format( '  examine those between',f8.3,' &',f8.3,' MeV')
	endif

	 if(rwpot=='r'.or.rwpot=='R') then
	   open(29,file=potfile,status='old')
	   read(29,*) n2states,nocc,ntran,dx,nx
	   write(6,281) n2states,nocc,ntran,nx,dx,potfile
281 	   format(/'  ** READ ',i3,' two-body potls (',i3,' occ &',i3,' tran) in',i5,' steps of ',f8.5, &
                  ' from file ',a20)
	   do i2s=1,n2states
	   read(29,*) 
	   read(29,*) twbod(i2s)%inf%pair,twbod(i2s)%inf%s_kind,  & 
	    twbod(i2s)%inf%jv,twbod(i2s)%nch,twbod(i2s)%par,twbod(i2s)%inf%fermi,twbod(i2s)%inf%test
	     nch = twbod(i2s)%nch
	     allocate(twbod(i2s)%lv(nch),twbod(i2s)%ic1v(nch),twbod(i2s)%ic2v(nch),twbod(i2s)%sv(nch))
	   read(29,*) twbod(i2s)%lv,twbod(i2s)%sv,twbod(i2s)%ic1v,twbod(i2s)%ic2v
	    write(6,282) sym(twbod(i2s)%inf%pair),twbod(i2s)%inf%jv,psign(twbod(i2s)%par+2),nch
282          format('    Two-body ',A1,' potential for J/pi =',f5.1,a1,',',i2,' chs.')
             allocate(twbod(i2s)%vccx(nx,nch,nch))
	     do ix=1,nx
	       x=(ix-1)*dx
	       read(29,*) xval,twbod(i2s)%vccx(ix,:,:)
	       if(abs(x-xval)>1e-4) write(145,*) i2s,ix,x,xval
	     enddo
	   enddo
	   read(29,*) forb(:)
	  write(6,*) ' Numerical potentials in partitions: ',forb(:)
!	  do 284 ia=1,3
!	  if(forb(ia)) then
!	  nit=0
!	  do 283 i2s=1,n2states
!	  if(ia/=twbod(i2s)%inf%pair) go to 283
!	  nit = nit+1
!	  it(nit) = i2s
!283	  continue
!          write(6,2831) ia,detail(ia),(twbod(it(i))%inf%jv,psign(2+twbod(it(i))%par),i=1,nit)
2831       format('  In partition ',i1,':',a8,', states defined: ',10(f5.1,a1,:,','))

!	     do 2837 i=1,nit
	     do 2837 i=1,n2states
	     it(i) = i
	     ia=twbod(i)%inf%pair
	     write(10,*) 'i2s,ia =',i,ia

	     write(10,2831) ia,detail(ia),twbod(it(i))%inf%jv,psign(2+twbod(it(i))%par)
	     write(10,*)  ' with ',twbod(it(i))%nch,' channels'
	     is=0.2/dx
	     do ix=1,nx,is
	     write(10,2832) (ix-1)*dx,(twbod(it(i))%vccx(ix,j,j),j=1,min(10,twbod(it(i))%nch))
2832	     format(f7.2,1p,10g11.3)
	     enddo
2837	  continue
!	  endif
284	  continue
	   close(29)

	else if(n2states>0) then
	  write(6,285) n2states,dx,xmax,dy,ymax,kapp
 285    format(//' Number of TWO-BODY STATES =',i3,/ &
           '  x in steps of ',f6.3,' to',f6.2,' fm,',/ &
           '  spline functions y steps of ',f6.3,' to',f6.2,' fm, non-linearity =',f8.4)
	  write(6,286) rnode1,ipc1,lmax1
 286    format(/'  Default parameters:'/ & 
                '   Counting nodes out to ',f6.2,' fm only, trace level =',i2,'  maximum l =',i3)
	  if(nk1>0.or.de1>0.) write(6,287) nk1,de1
 287    format( '   Bin internal integration in ',i4,' steps of ',f8.4,' MeV each')
 	if(n2states > mocc) then
	  write(6,*) ' Parameter mocc=',mocc,' should be >= n2states =',n2states
	  stop 'mocc'
	  endif
	do i2s=1,n2states
	write(6,290) i2s
 290	format(/'  Two-body state #',i3,':')
!	write(6,*) twbod(i2s) % inf
	bs = twbod(i2s) % inf
	  if(bs%s_kind==-1) kind ='pot'
	  if(bs%s_kind==0) kind ='occ'
	  if(bs%s_kind==1) kind ='tra'
        write(6,291) bs%pair,detail(bs%pair),kind,bs%n,bs%nvchan,bs%l,bs%lmax,bs%s,bs%jv,bs%fermi,bs%rnode
 291    format('   Pair,s_kind,n,nvchan,l,lmax,s,jv,fermi,rnode =',i2,':',a8,1x,a3,4i2,2f5.1,f6.1,f5.1)
        write(6,292) bs%isc,bs%ipc,bs%nomit,bs%eigen,bs%potential,bs%test
 292    format('      isc,ipc,nomit,eigen,potential,test =',3i2,2f8.4,l3)

! still to print: rescale,de,nk,
!                 omit_l(1:nomit),omit_c1(1:nomit),omit_c2(1:nomit),omit_s(1:nomit),omit_j(1:nomit)
	enddo
	endif
!	write(6,*) ' fesh,effp,effd =',fesh,effp,effd

	 if(fesh) write(6,380) kmaxf     
 380	 format(/'  Feshbach reduction to Kmaxf =',5i3)
	 if(fesh) write(6,381) efesh     
 381	 format(/'                               ',' with Feshbach energy ',f8.3,' MeV')
	 if(effp) write(6,390) kmaxeff     
 390	 format(/'  Effective interaction Kmaxeff =',5i3)
	 maxns = maxval(ns(:))
	 if(effd) write(6,391) shift,ndrop(1:maxns)
 391	 format(/'       Number of forbidden eigensurfaces shifted to',f8.2,' is: ',5i3)
!	 write(6,*) effd,shift,ndrop     
	 if(vadia) write(6,398) 
 398	 format(/'  Calculate adiabatic energy surfaces ')

	return
	end
