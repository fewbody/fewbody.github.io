      subroutine potdef(l,qmax,rnc,vdef,def,ib)
!        deform the form factor uc(l,r) by deformation def.lengths def(k),k=2,qmax
!     	 do numerical quadrature over angles
!
	use factorials
	use parameters
      implicit real*8 (a-h,o-z)
      real*8 pl(0:mmultipole),c(0:mmultipole),sp(9),w(9),  &
         vdef(0:mmultipole),def(2:mmultipole)
      data (sp(i),i=1,5) /-.96816024,-.8360311,-.61337143,-.32425342,0./  &
           ,(w(i),i=1,5) /.08127439,.18064816,.26061070,.31234708,.33023936 /
      integer qmax
      save rsp,sp,w,c
      if(l.lt.0) then
!		it was never initialising c(k) so I changed this	!
!      if(l.le.0) then
! initialise
      rsp = 1.0/sqrt(pi)
      do 2 i=1,4
      sp(5+i) =-sp(5-i)
2     w(5+i)  = w(5-i)
      do 15 k=0,qmax
15    c(k) = sqrt((2.*k+1.)/4.)
!	write(10,*) 'potdef initialised for qmax =',qmax
      endif
      do 18 k=0,qmax
18    vdef(k) = 0.
         pl(0) = 1.
      do 50 nu=1,9
         u = sp(nu)
         pl(1) = u
         do 20 k=2,qmax
20       pl(k) = ((2*k-1)*u*pl(k-1) - (k-1)*pl(k-2))/dble(k)
      sh  = 0.0
      do 25 k=2,qmax
25       sh = sh + c(k)*rsp * pl(k) * def(k)
         r = rnc - sh
	 do 40 k=0,qmax
	    if(k.ge.2) then
	    	if(def(k).eq.0d0) go to 40
	    endif
            cns = w(nu) * pl(k) * c(k)
          vdef(k)=vdef(k) + cns * vc(l,r,ib)
40      continue
50      continue
	return
      end
