      double precision function sim6j(a,b,p,d,q,f)
        implicit doubleprecision(a-h,o-z)
c
c ********************************************
c ***    * a b p *                            ***
c ***    * d q f * 
c ***    *       *                            ***
c ********************************************
c
      dimension      w(100)
      data n/100/, k/0/, w(1),w(2)/0.d0,0.d0/, x/2.d0/
	e=p
	c=q
      if(k)1,1,2
    1 k=1
      do 3 i=3,n
      w(i)=w(i-1)+dlog(x)
    3 x=x+1.d0
    2 i1=a+b-e+1.1d0
      if(i1)100,100,5
    5 i2=a-b+e+1.1d0
      if(i2)100,100,6
    6 i3=b+e-a+1.1d0
      if(i3)100,100,7
    7 x=a+b+e+2.1d0
      i4=x
      i=x+.6d0
      i=i4-i
      if(i)100,4,100
    4 j1=c+d-e+1.1d0
      if(j1)100,100,9
    9 j2=c-d+e+1.1d0
      if(j2)100,100,10
   10 j3=d-c+e+1.1d0
      if(j3)100,100,11
   11 x=d+c+e+2.1d0
      j4=x
      i=x+0.6d0
      i=i-j4
      if(i)100,8,100
    8 k1=a+c-f+1.1d0
      if(k1)100,100,13
   13 k2=a-c+f+1.1d0
      if(k2)100,100,14
   14 k3=c+f-a+1.1d0
      if(k3)100,100,15
   15 x=a+c+f+2.1d0
      k4=x
      i=x+.6d0
      i=k4-i
      if(i)100,12,100
   12 l1=b+d-f+1.1d0
      if(l1)100,100,17
   17 l2=b-d+f+1.1d0
      if(l2)100,100,18
   18 l3=d+f-b+1.1d0
      if(l3)100,100,19
   19 x=d+f+b+2.1d0
      l4=x
      i=x+.6d0
      i=l4-i
      if(i)100,16,100
   16 continue
      x=w(i1)+w(i2)+w(i3)+w(j1)+w(j2)+w(j3)+
     *w(k1)+w(k2)+w(k3)+w(l1)+w(l2)+w(l3)-
     *w(i4)-w(j4)-w(k4)-w(l4)
      x=x*.5d0
      i1=a+b+c+d+3.1d0
      i2=a+d+e+f+3.1d0
      i3=b+c+e+f+3.1d0
      k2=min0(i1,i2,i3)-1
      i4=i4-1
      k4=k4-1
      j4=j4-1
      l4=l4-1
      k1=max0(0,i4,k4,j4,l4)+1
      j1=i1+k1-1
      j2=j1/2
      j3=j1*.5d0+.6d0
      e1=1.d0
      j1=j3-j2
      if(j1)20,21,20
   20 e1=-1.d0
   21 s=0.d0
      do 22 i=k1,k2
      ci=x+w(i)-w(i-i4)-w(i-j4)-w(i-k4)-w(i-l4)-
     *w(i1-i)-w(i2-i)-w(i3-i)
      s=s+e1*dexp(ci)
   22 e1=1.d0-e1-1.d0
	n=a+b+c+d
	n=n-2*(n/2)
      sim6j=s*(-1)**n
      return
  100 sim6j=0.d0
      return
      end
      function wraca(a,b,c,d,e,f)
        implicit doubleprecision(a-h,o-z)
c
c ********************************************
c ***                                      ***
c ***     wraca funct. w(a,b,c,d,e,f)      ***
c ***                                      ***
c ********************************************
c
      dimension      w(100)
      data n/100/, k/0/, w(1),w(2)/0.d0,0.d0/, x/2.d0/
      if(k)1,1,2
    1 k=1
      do 3 i=3,n
      w(i)=w(i-1)+dlog(x)
    3 x=x+1.d0
    2 i1=a+b-e+1.1d0
      if(i1)100,100,5
    5 i2=a-b+e+1.1d0
      if(i2)100,100,6
    6 i3=b+e-a+1.1d0
      if(i3)100,100,7
    7 x=a+b+e+2.1d0
      i4=x
      i=x+.6d0
      i=i4-i
      if(i)100,4,100
    4 j1=c+d-e+1.1d0
      if(j1)100,100,9
    9 j2=c-d+e+1.1d0
      if(j2)100,100,10
   10 j3=d-c+e+1.1d0
      if(j3)100,100,11
   11 x=d+c+e+2.1d0
      j4=x
      i=x+0.6d0
      i=i-j4
      if(i)100,8,100
    8 k1=a+c-f+1.1d0
      if(k1)100,100,13
   13 k2=a-c+f+1.1d0
      if(k2)100,100,14
   14 k3=c+f-a+1.1d0
      if(k3)100,100,15
   15 x=a+c+f+2.1d0
      k4=x
      i=x+.6d0
      i=k4-i
      if(i)100,12,100
   12 l1=b+d-f+1.1d0
      if(l1)100,100,17
   17 l2=b-d+f+1.1d0
      if(l2)100,100,18
   18 l3=d+f-b+1.1d0
      if(l3)100,100,19
   19 x=d+f+b+2.1d0
      l4=x
      i=x+.6d0
      i=l4-i
      if(i)100,16,100
   16 continue
      x=w(i1)+w(i2)+w(i3)+w(j1)+w(j2)+w(j3)+
     *w(k1)+w(k2)+w(k3)+w(l1)+w(l2)+w(l3)-
     *w(i4)-w(j4)-w(k4)-w(l4)
      x=x*.5d0
      i1=a+b+c+d+3.1d0
      i2=a+d+e+f+3.1d0
      i3=b+c+e+f+3.1d0
      k2=min0(i1,i2,i3)-1
      i4=i4-1
      k4=k4-1
      j4=j4-1
      l4=l4-1
      k1=max0(0,i4,k4,j4,l4)+1
      j1=i1+k1-1
      j2=j1/2
      j3=j1*.5d0+.6d0
      e1=1.d0
      j1=j3-j2
      if(j1)20,21,20
   20 e1=-1.d0
   21 s=0.d0
      do 22 i=k1,k2
      ci=x+w(i)-w(i-i4)-w(i-j4)-w(i-k4)-w(i-l4)-
     *w(i1-i)-w(i2-i)-w(i3-i)
      s=s+e1*dexp(ci)
   22 e1=1.d0-e1-1.d0
      wraca=s
      return
  100 wraca=0.d0
      return
      end
      function racah(a,b,c,d,e,f)
      implicit real*8(a-h,o-z)
      phase(i) = (-1)**i
      z = abs(a+b+c+d)
      i = z + 0.5
      racah = phase(i) * sim6j(a,b,e,d,c,f)
      return
      end

      function sim9j(a1,a2,a3,b1,b2,b3,c1,c2,c3)
        implicit doubleprecision(a-h,o-z)
c
c ********************************************
c ***                                      ***
c ***    9-j symbol  a1 a2 a3              ***
c ***                b1 b2 b3              ***
c ***                c1 c2 c3              ***
c ***    via sum of wraca                  ***
c ***                                      ***
c ********************************************
c
      d1=dabs(a1-c3)
      d2=dabs(a2-b3)
      d3=dabs(b1-c2)
      xn=dmax1(d1,d2,d3)
      d1=a1+c3
      d2=a2+b3
      d3=b1+c2
      xk=dmin1(d1,d2,d3)
      i=xk-xn+.1d0
      if(i)100,1,1
    1 x=xn-1.d0
      s=0.d0
      j=-1
    2 x=x+1.d0
      s=s+(x+x+1.d0)*wraca(a1,a2,c3,b3,a3,x)*
     *wraca(b1,b3,c2,a2,b2,x)*
     *wraca(a1,b1,c3,c2,c1,x)
      j=j+1
      if(i-j)2,3,2
    3 sim9j=s
      return
  100 sim9j=0.d0
      return
      end
         function wig(jj1,jj2,jj3,mm1,mm2)
c
c ********************************************************************
c ***                                                              ***
c *** 3j-simbol : jj1=2*j1, jj2=2*j2, jj3=2*j3, mm1=2*m1, mm2=2*m2,***
c ***    m1+m2+m3=0                                                ***
c ***                                                              ***
c ********************************************************************
c
         use factorials
         implicit doubleprecision(a-h,o-z)
!         common/fact/ dlfac,dl2fac
!         dimension d(99),e(99),f(99),dlfac(0:200),dl2fac(0:200)
         dimension d(99),e(99),f(99)
 	 wig = 0.0
 	 if(abs(jj1-jj2).gt.jj3.or.jj1+jj2.lt.jj3) return
 	 if(abs(mm1).gt.jj1 .or. abs(mm2).gt.jj2) return
         j21=(jj1+mm1)/2
         jj=(jj1+jj2-jj3)/2+1
         j22=(jj2+mm2)/2
         j31=(jj1-mm1)/2
         j13= jj-1
         j32=(jj2-mm2)/2
         js=(jj1+jj2+jj3)/2+1
         s=(-1)**(j21+j32)*dsqrt(gp(j21,j31-j13)*
     1gp(j31,j32-j13)*gp(j32,j22-j13)*gp(j22,j21-j13)/
     2dexp(dlfac(js)+dlfac(j13)))
         d(1)=1.d0
         e(1)=1.d0
         f(1)=1.d0
         p=1.d0
         if(jj-2) 1,2,2
  2      do 3 m=2,jj
         d(m)=d(m-1)*(j21-m+2)*(j32-m+2)
         e(m)=e(m-1)*(j22-m+2)*(j31-m+2)
  3      f(m)=-f(m-1)*(jj-m+1)/(m-1)
         p=0.d0
         do 4 m=1,jj
  4      p=p+d(jj-m+1)*e(m)*f(m)
  1      continue
         wig=p*s
         return
         end
      function cleb6(a,al,b,be,c,m)
      implicit real*8(a-h,o-z)
      real*8 m
      cleb6 = wig(nint(2*a),nint(2*b),nint(2*c),nint(2*al),nint(2*be))
     x           * sqrt(2.*c+1) * (-1)**nint(b-a-m)
      return
      end
         double precision function gp(n,j)
c **** gen.  power
         implicit doubleprecision(a-h,o-z)
         gp=1.d0
         if(j) 1,2,3
 1       j1=-j
         do 4 k=1,j1
 4       gp=gp*(n+1-k)
         gp=1.d0/gp
         return
 3       continue
         do 5 k=1,j
 5       gp=gp*(n+k)
 2       continue
         return
	 end


