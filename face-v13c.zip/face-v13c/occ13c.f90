 	subroutine  occ
	use physics
	use methodspec
	use work
	use twobody_states
        implicit real*8(a-h,o-z)
	logical bound,box,frac,fail3,occup,potl
	real*8,allocatable:: sl2(:,:),esum(:),kap2(:),etap(:),norms(:)
	integer,allocatable:: nv(:)
	real*8 jv
	integer par,it(1000)
        CHARACTER LNAMES(12),MODE*9,SRCH,MAIN,PART,search,det*9,nodc
	DATA LNAMES / 's','p','d','f','g','h','i','j','k','l','m','n' /
        frac(x) = abs(x-int(x)).gt.1e-5
        fail3(x1,x2,x3) = frac(x1+x2+x3) .or. x1.gt.x2+x3 .or. x1.lt.abs(x2-x3)

	write(6,*) 
	write(6,*) ' Calculate two-body eigenstates'
!	write(6,*) ' qmaxb(:)=',qmaxb(:)

	 if(rwpot=='w'.or.rwpot=='W') then
	   open(29,file=potfile,status='unknown')
	   write(6,*) dx,dxf,nx
	   if(dxf<dx) dxf=dx
	   lxf = nint(dxf/dx)
	   dxf = lxf*dx
	   nxf = min(nx,nint(xmax/dxf))
	   write(6,5) nxf,dxf,potfile
5	   format(/'  *** Writing TWO-BODY potentials with ',i5,' steps of',f8.4,' to file ',a20/)
	   write(29,*) n2states,nocc,ntran,dxf,nxf
	   endif

	do 100 i2s=1,n2states
         write(6,*)
	 
	ia = twbod(i2s)%inf%pair
	k1=pairs(1,ia)
	k2=pairs(2,ia)
	pmass1 = mass(k1)
	pmass2 = mass(k2)
!        write(6,*) 'k1,k2,masses,charges =',k1,k2,pmass1,pmass2,z(k1),z(k2)
	rmass=pmass1*pmass2/(pmass1+pmass2)
	fmscal=1d0/h2sm
	conv = fmscal*rmass
        gj=gamso1(ia)
        gk=gamso2(ia)
	nodes_req      = twbod(i2s)%inf%n
	isc            = twbod(i2s)%inf%isc
	jv             = twbod(i2s)%inf%jv
	fermi          = twbod(i2s)%inf%fermi
         MODE = 'Occupied'
	 if(twbod(i2s)%inf%s_kind==1) MODE = 'Transfer'
	 potl = twbod(i2s)%inf%s_kind==-1
	 if(potl) MODE = 'Potential'

	par = (-1)**twbod(i2s)%inf%l * parity(1,k1)*parity(1,k2)  
!                       parities of the two bodies with bodies in their gs
        twbod(i2s)%par = par
!               Now find real number of channels!
        nch=0
        i=0
        do inch=0,1
        do ic1=1,ns(k1)
         s1 = spin(ic1,k1)
        do ic2=1,ns(k2)
         s2 = spin(ic2,k2)
        do l=0,twbod(i2s)%inf%lmax
   	if(twbod(i2s)%inf%ipc>4..and.inch==0)   & 
           write(6,'(''Try ic1,s1,ic2,s2,l ='',2(i2,f5.1,i3),i3)') ic1,s1,parity(ic1,k1),ic2,s2,parity(ic2,k2),l
         if((-1)**l*parity(ic1,k1)*parity(ic2,k2)==par) then
           do s=abs(s1-s2),s1+s2
   	if(twbod(i2s)%inf%ipc>4..and.inch==0)   & 
           write(6,*) 'Try s,l,jv =',real(s),l,real(jv)
           if(.not.fail3(s,l+0d0,jv)) then
            if(inch==0) then
                nch=nch+1
              else
                i=i+1
	        twbod(i2s)%lv(i)=l
	        twbod(i2s)%ic1v(i)=ic1
	        twbod(i2s)%ic2v(i)=ic2
	        twbod(i2s)%sv(i)=s
	        etap(i) = z(k1)*z(k2) 
	        esum(i) = energy(ic1,k1)+energy(ic2,k2)    ! core excitation energies
!                 write(6,*) 'ic1,ic2,l,s,z1*z2,e1+e2 =',ic1,ic2,l,real(s),nint(etap(i)),real(esum(i))
              endif
           endif
           enddo
        endif
        enddo
        enddo
        enddo
          if(inch==0) then
           if(nch==0) then
             write(6,13) MODE,jv,PSIGN(2+par),detail(ia),i2s
 13	     format( '   ',A9,F4.1,A1,1x,A8,' #',i3,' NO CHANNELS FOUND')
             go to 100
           endif
	  allocate(twbod(i2s)%lv(nch),twbod(i2s)%ic1v(nch),twbod(i2s)%ic2v(nch),twbod(i2s)%sv(nch))
	  allocate(twbod(i2s)%ybs(nx,nch),sl2(nch,nch),esum(nch),kap2(nch),nv(nch),etap(nch),norms(nch))
	  occup = fermi>-800..or.twbod(i2s)%inf%s_kind==0
          allocate(twbod(i2s)%vccx(nx,nch,nch))
          endif
        enddo

	twbod(i2s)%nch = nch
	nnode=twbod(i2s)%inf%rnode/dx
	if(nnode<10) nnode=nx
	box = .false.

	sl2(:,:) = 0.	! spin-orbit coefficient
        do 10 i=1,nch
          sj=spin(twbod(i2s)%ic1v(i),k1)
          sk=spin(twbod(i2s)%ic2v(i),k2)
        do 10 j=1,nch
        if(twbod(i2s)%ic1v(i)==twbod(i2s)%ic1v(j).and.   &
   &       twbod(i2s)%ic2v(i)==twbod(i2s)%ic2v(j).and.   &
   &       twbod(i2s)%lv(i)==twbod(i2s)%lv(j)) then
        
	sl2(i,j) = VSOLS(twbod(i2s)%lv(i),twbod(i2s)%lv(j),sj,sk,  & 
   &           twbod(i2s)%sv(i),twbod(i2s)%sv(j),jv,gj,gk)
   	if(twbod(i2s)%inf%ipc>4) write(6,*) 'i,j,sl2 = ',i,j,sl2
	endif
10	continue
	etap(:) = etap(:) * etacns      ! eta*2k
        kap2(:) = esum(:) * conv
	mc=twbod(i2s)%inf%nvchan	! channel in which to count nodes
	mc = max(1,mc)
	mc = min(nch,mc)


	if(isc==1) then  ! search on V
	  u = twbod(i2s)%inf%potential
	  if(u==0.) u=1.
	  p = u  
	  theta = 0.
	  search= 'V'
	  eigen = twbod(i2s)%inf%eigen
	  kap2(:) = kap2(:) - eigen*conv
	 else            ! search on E
	  p = -twbod(i2s)%inf%eigen  
	  if(p==0.) p=5.0
	  u = 1.
	  eigen = -p 	! For bound states: eigen<0, p>0
	  theta = conv
	  search= 'E'
	 endif    ! p==search variable

         IF(eigen>0.) then
		MODE = 'Reson'
		if(LVIN.eq.0.and.abs(ETAP(mc)).lt.1e-6) MODE = 'Virtual'
		endif
         IF(BOX)          MODE = 'Box  '

!		write(6,*) 'Call  eigcc'

     	call eigcc(twbod(i2s)%ybs(:,:),etap,kap2,sl2,theta,ia,p,1./conv,box,isc, &
     &  nodes_req,mc,twbod(i2s)%lv(:),twbod(i2s)%ic1v(:),twbod(i2s)%ic2v(:), &
     &  twbod(i2s)%sv(:),jv,nv,nnode,nx,dx,nch,.false.,twbod(i2s)%vccx(:,:,:), &
     &  norms,twbod(i2s)%inf%ipc,60,1d-6,ifail,potl)
         IF(IFAIL.ne.0.and..not.potl)          MODE = 'FAIL:'

	 if(isc==1) u = p
	 if(isc==2) eigen = -p
!         if(twbod(i2s)%inf%s_kind==0.and.IFAIL==0) fermi = eigen+1.
         det = detail(ia)
         do i=1,nch
         nodc = ' '
         if(i==mc) nodc='*'
	 if(.not.potl) then
         write(6,33) MODE,jv,PSIGN(2+PAR),det,i2s,i,nch,nodc,fermi,nv(i), &
     &               lnames(twbod(i2s)%lv(i)+1),twbod(i2s)%sv(i),eigen-esum(i),u,norms(i)
     	 else
         write(6,34) MODE,jv,PSIGN(2+PAR),det,i2s,i,nch, &
     &               lnames(twbod(i2s)%lv(i)+1),twbod(i2s)%sv(i)
         endif
         det=' ';MODE=' '
         enddo
 33	format( '   ',A9,F4.1,A1,1x,A8,' #',i3,' of',i2,'/',i2,  &
     &		' chs',a1,' Ef=',f6.1,'; nls ',i1,a1,f4.1,': E=',F8.4,' in V*',f7.4, &
     &          ':',f7.4)
 34	format( '   ',A9,F4.1,A1,1x,A8,' #',i3,' of',i2,'/',i2,  &
     &		' chs: ',a1,'+',f3.1)

        if(occup.and..not.twbod(i2s)%inf%test) then
	  forb(ia) = .true.
          call susy(nch,jv,PSIGN(2+par),fermi,nbl,nbs,u,h2sm,pmass1,pmass2,nx,dx,esum,mc, &
     &              twbod(i2s)%lv(:),twbod(i2s)%ic1v(:),twbod(i2s)%ic2v(:),twbod(i2s)%sv(:), &
     &                  sl2,ia,twbod(i2s)%vccx(:,:,:))

          nodes_req = 1
         if(occup.and.nbs>0.and.nbl>0) then
!                                        RECALCULATE BOUND STATE IF STILL
!                                        ALLOWED
         if(twbod(i2s)%inf%ipc>0) write(6,*) ' Now look for bs with ',nodes_req,' nodes:'
     	   call eigcc(twbod(i2s)%ybs(:,:),etap,kap2,sl2,theta,ia,p,1./conv,box,isc, &
     &     nodes_req,mc,twbod(i2s)%lv(:),twbod(i2s)%ic1v(:),twbod(i2s)%ic2v(:), &
     &     twbod(i2s)%sv(:),jv,nv,nnode,nx,dx,nch,.true.,twbod(i2s)%vccx(:,:,:), &
     &     norms,twbod(i2s)%inf%ipc,60,1d-6,ifail)
	 if(isc==1) u = p
	 if(isc==2) eigen = -p
         MODE = 'SUSY bs'
         IF(IFAIL.ne.0)          MODE = 'FAIL:'
         det = detail(ia)
         do i=1,nch
         nodc = ' '
         if(i==mc) nodc='*'
         write(6,33) MODE,jv,PSIGN(2+PAR),det,i2s,i,nch,nodc,0.,nv(i), &
     &               lnames(twbod(i2s)%lv(i)+1),twbod(i2s)%sv(i),eigen-esum(i),u,norms(i)
         det=' ';MODE=' '
         enddo
         endif

         endif


	 if(rwpot=='w'.or.rwpot=='W') then
	   write(29,91)  i2s,jv,PSIGN(2+par)
91 	   format(' Two-body state ',i3,' of ',f5.1,a1)
	   write(29,*) twbod(i2s)%inf%pair,twbod(i2s)%inf%s_kind,  & 
	    twbod(i2s)%inf%jv,twbod(i2s)%nch,twbod(i2s)%par,twbod(i2s)%inf%fermi,twbod(i2s)%inf%test
	   write(29,*) twbod(i2s)%lv,twbod(i2s)%sv,twbod(i2s)%ic1v,twbod(i2s)%ic2v
	   do ixf=1,nxf
	    ix = (ixf-1) * lxf + 1
	    x = (ix-1)*dx
	    write(29,*) real(x),real(twbod(i2s)%vccx(ix,:,:))
	   enddo
	 endif

	deallocate(sl2,esum,kap2,nv,etap,norms)

100	continue
	 if(rwpot=='w'.or.rwpot=='W') then
	   write(29,*) forb(:)
	   close(29)
	   endif
	  write(6,*) ' Numerical potentials in partitions: ',forb(:)
	  do 120 ia=1,3
	  if(forb(ia)) then
	  nit=0
	  do 110 i2s=1,n2states
	  if(ia/=twbod(i2s)%inf%pair) go to 110
	  nit = nit+1
	  it(nit) = i2s
110	  continue
          write(6,115) ia,detail(ia),(twbod(it(i))%inf%jv,PSIGN(2+twbod(it(i))%par),i=1,nit)
!115       format('  In partition ',i1,':',a8,', states defined: ',(/9x,10(f5.1,a1,:,',')))
115       format('  In partition ',i1,':',a8,', states defined: ',10(f5.1,a1,:,','))
	     do 119 i=1,nit
	     write(10,115) ia,detail(ia),twbod(it(i))%inf%jv,PSIGN(2+twbod(it(i))%par)
	     write(10,*)  ' with ',twbod(it(i))%nch,' channels'
	        do ix=1,nx
	        do j=1,twbod(it(i))%nch
!	           twbod(it(i))%vccx(ix,j,j) = max(-20d0,twbod(it(i))%vccx(ix,j,j))
	        enddo
	        enddo
	     is=0.2/dx
	     do ix=1,nx,is
	     write(10,117) (ix-1)*dx,(twbod(it(i))%vccx(ix,j,j),j=1,min(10,twbod(it(i))%nch))
117	     format(f7.2,1p,10g11.3)
	     enddo
!	     write(10,*) twbod(it(i))%vccx(:,:,:)
119	  continue
	  endif
120	  continue
	return
	end
      subroutine pot(v,x,l1,l2,i1c1,i1c2,i2c1,i2c2,s1,s2,jv,sl2,i,j,pair)
      use parameters
      use physics
      IMPLICIT DOUBLEPRECISION(A-H,O-Z)
      Double Precision jv,vdef(0:mmultipole),c(0:mmultipole+3),defs(2:mmultipole),v(2)
      integer pair
      logical defm
      if(qmaxb(pair)>0) then
!      write(52,*) ' POT: pair,x,i,j,l1,l2,i1c1,i1c2,i2c1,i2c2=',pair,x,i,j,l1,l2,i1c1,i1c2,i2c1,i2c2
!      write(52,*) ' POT: pair,qmaxb(pair) =',pair,qmaxb(pair)
      endif

      c(:) = 0
      v(:) = 0
      potl = 0.0 
      defm = qmaxb(pair)>0
	k1=pairs(1,pair)
	k2=pairs(2,pair)
      if(defm) then
          kq1=qmax(k1)
          kq2=qmax(k2)
          defs(:) = def(:,k1) + def(:,k2)  ! ASSUME only ONE nucleus deformed!!!
             if(lpot(pair)==0) LU=min(L1,l2)
             if(lpot(pair)==1) LU=(L1+l2)/2
             if(lpot(pair)==2) LU=max(L1,l2)
             if(lpot(pair)==3) LU=L1
             if(lpot(pair)>=10) LU=mod(lpot(pair),10)  ! specified quadrupoles etc
          call potdef(LU,qmaxb(pair),x,vdef,defs,pair)
             if(lpot(pair)>=10) vdef(0) = vc(l1,x,pair)    ! original monopole
          endif
      if(i.eq.j)  then
        if(.not.defm) potl = vc(l1,x,pair) 
        if(     defm) potl = vdef(0)
        write(53,10) x,vdef(0)
	c(0) = 1.0
      	if(i.eq.-1) return
        if(i.eq.j) potl=potl + vcoul(x,pair)
	V(1) = potl                      ! variable: to multiply by pmul
	endif
        V(2) = sl2*vls(l1,x,pair)       ! fixed
	c(1) = sl2

!			deformed n-core potential
      do 50 KK=2,qmaxb(pair)
	T = FANCDEF3(l1,l2,i1c1,i1c2,i2c1,i2c2,s1,s2,jv,KK,spin(:,k1),spin(:,k2),corek(k1),corek(k2))
	V(1) = V(1) + vdef(KK) * T
	c(KK)=T
      if(qmaxb(pair)>0.and.i+j>1) then
!        write(52,10) ' POT: i,j,KK,T,x,vdef(KK) =',i,j,KK,T,x,vdef(KK)
!10      format(a,3i3,F8.4,2f10.6)
        write(52,10) x,vdef(KK),T
10      format(F8.4,2f10.6)
      endif
50	continue

!			(tensor and core-so potls. not implemented yet)
!      if(l1.eq.l2.and.i1.eq.i2) then
!        V(2) = V(2) + ULSC(l1,x)*FANCLSC(l1,0,l1,l1,s,j1,j2,i1,jtot)
!        V(2) = V(2) + ULL(l1,x)*FANCLL(l1,0,l1,l1,s,s,j1,j2,i1,jtot)
!	endif
!      if(i1.eq.i2) then
!        V(2) = V(2) + UT(l1,x)*FANCT(l1,l2,0,l1,l2,s,s,j1,j2,i1,jtot)
!	endif

!!			tensor n-n potential
!	if(j1.ge.1d0.and.j2.ge.1d0) then
!!					S1 >= 1, S2 >= 1 only
!	V(2) = V(2) + FANNT(l1,l2,0,l1,l2,nint(jtot),1)*VT(l1,x) 
!	if(l1.eq.l2) V(2)=V(2)+FANNLL(l1,0,l1,l1,nint(jtot),1)*VLL(l1,x)
!	endif
!      endif
!        if(qmaxb(pair)>1) write(51,51) i,j,(C(icc),icc=0,qmaxb(pair)),(vdef(icc),icc=2,qmaxb(pair))
51	format(2I3,10f9.5)
      return
      end
      FUNCTION VSOLS(L,LP,S1,S2,S,SP,JT,G1,G2)
      implicit real*8(a-h,o-z)
      real*8 J1,J2,JT,J1MIN,J1MAX,J2MIN,J2MAX
	Z = 0
	VSOLS = 0.
       write(4,1) L,LP,S1,S2,S,SP,JT
1      format(' VSOLS: L,LP=',2i2,' S1,S2,S,SP=',4f5.1,' JT=',f5.1)

!           T(1) = r/1 . s/1(S1 S1)   = 2 l.S1  = S1 spin-orbit
!           T(2) = r/1 . s/1(S2 S2)   = 2 l.S2  = S2 spin-orbit

      IF(L.NE.LP) RETURN
      J1MIN = MAX(ABS(L-S1),ABS(S2-JT),ABS(LP-S1))
      J1MAX = MIN(    L+S1 ,    S2+JT ,    LP+S1 )
      T = 0.0
      DO 40 J1=J1MIN,J1MAX
  40  T = T + (2*J1+1) * RACAH(L+Z, S1,JT,S2,J1,S)  &
     &                 * RACAH(LP+Z,S1,JT,S2,J1,SP)  &
     &                 * (J1*(J1+1) - L*(L+1.) - S1*(S1+1))
      VSOLS1 = T * SQRT((2*SP+1)*(2*S+1))

      J2MIN = MAX(ABS(L-S2),ABS(S1-JT),ABS(LP-S2))
      J2MAX = MIN(    L+S2 ,    S1+JT ,    LP+S2 )
      T = 0.0
      DO 50 J2=J2MIN,J2MAX
      T = T + (2*J2+1) * RACAH(L+Z ,S2,JT,S1,J2,S)  &
     &                 * RACAH(LP+Z,S2,JT,S1,J2,SP)  &
     &                 * (J2*(J2+1) - L*(L+1.) - S2*(S2+1))
!       write(6,*) 'VSOLS2: J2,T =',J2,T
   50 CONTINUE
      VSOLS2 = T * SQRT((2*SP+1)*(2*S+1)) * (-1)**NINT(S-SP)
      
      write(4,60) G1,VSOLS1,G2,VSOLS2
60    format(' VSOLS = ',f4.1,'*',f8.3,' + ',f4.1,'*',f8.3)
      VSOLS = (G1*VSOLS1 + G2*VSOLS2)*0.5d0   ! need coefficient of l.s not 2l.s
      RETURN
      END

      FUNCTION FANCDEF3(l,lp,i1v,i1pv,i2v,i2pv,s,sp,jv,KK,spin1,spin2,ck1,ck2)
      IMPLICIT DOUBLEPRECISION(A-H,O-Z)
      real*8 jv,spin1(*),spin2(*),i1,i2,i1p,i2p
      z = 0d0
!-----     FANCDEF3 calculates the matrix elements for a 2 body problem
!-----                 with core excitation:
!-----     <l,(i1,i2)s,jv | C(KK(l)).C(KK(i1)) | lp,(i1p,i2p)sp,jv >=A
!-----   + <l,(i1,i2)s,jv | C(KK(l)).C(KK(i2)) | lp,(i1p,i2p)sp,jv >=B
!-----           times sqrt(2*KK+1) factor.

        i1 = spin1(i1v)
        i1p= spin1(i1pv)
        i2 = spin2(i2v)
        i2p= spin2(i2pv)
        
        FANCDEF3 = Z
        if(abs(l-lp).gt.KK .or.l+lp.lt.KK) return
        if(abs(s-sp).gt.KK .or.s+sp.lt.KK) return

        A = Z
        if(i2v==i2pv.and.KK>=abs(i1-i1p).and.KK<=i1+i1p) then
          A = (-1)**nint(lp+l+s+sp+i1+i2+jv+KK)  & 
             * sqrt((2*l+1)*(2*lp+1)*(2*s+1)*(2*sp+1)*(2*i1+1))  & 
             * sim6j(l+z,lp+z,KK+z,sp,s,jv) &
             * sim6j(s,sp,KK+z,i1p,i1,i2)   & 
             * wig(l*2,KK*2,lp*2,0,0)       &
             * (-1)**nint(KK+i1p+ck1) * sqrt(2*i1p+1.)  & 
             * wig(nint(2*i1),nint(2*i1p),2*KK,       &
                   nint(-2*ck1),nint(2*ck1))
        write(54,'(a,f12.5,f5.1)') 'DEF3: A',A * sqrt(2.*KK+1.),ck1
        endif

        B = Z
        if(i1v==i1pv.and.KK>=abs(i2-i2p).and.KK<=i2+i2p) then
        write(54,'(a,6f5.1)') 'DEF3: s,sp,i1,i2,i2p,jv',s,sp,i1,i2,i2p,jv
        write(54,'(a,5i5)') 'DEF3: l,lp,k',l,lp,KK
          t0 = (-1)**nint(lp+l+2*s+i1+i2p+jv+KK)  
          t1 = sqrt((2*l+1)*(2*lp+1)*(2*s+1)*(2*sp+1)*(2*i2+1))  
          t2 = sim6j(l+z,lp+z,KK+z,sp,s,jv) 
          t3 = sim6j(s,sp,KK+z,i2p,i2,i1)   
          t4 = wig(l*2,KK*2,lp*2,0,0)       
          t5 = (-1)**nint(KK+i2p+ck2) * sqrt(2*i2p+1.) 
          t6 = wig(nint(2*i2),nint(2*i2p),2*KK,       &
                   nint(-2*ck2),nint(2*ck2))
          t7 = sqrt(2.*KK+1.)
	  B = t0*t1*t2*t3*t4*t5*t6*t7
        write(54,'(a,9f12.5)') 't0-t7',t0,t1,t2,t3,t4,t5,t6,t7,B
        write(54,'(a,f12.5,4f5.1)') 'DEF3: B',B,i2,ck2,i2p,ck2
        endif
        FANCDEF3 = (A + B) !* sqrt(2.*KK+1.)  !* sqrt(18.)

!       FANCDEF3=(-1)**nint(s+2*j2+KK+JT+KTARG)
!    &              *Sqrt((2*j1+1)*(2*j2+1)*(2*l1+1)*(2*l2+1)
!    &              *(2*I1+1)*(2*I2+1)*(2*KK+1))
!    &              *SIM6J(j1,j2,KK+Z,I2,I1,JT)
!    &              *SIM6J(j1,j2,KK+Z,l2+Z,l1+Z,s)
!    &              *WIG(2*l2,2*l1,2*KK,0,0)
!    &              *WIG(nint(2*I2),nint(2*I1),2*KK,
!    +                     nint(2*KTARG),-nint(2*KTARG))
!    &              *(-1)**nint(J1+J2-Lx1-Lx2-s-s)
        return
        end
