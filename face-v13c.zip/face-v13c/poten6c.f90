	function vc(l,r,ip)
	use physics
	use potentials
	implicit real*8(a-h,o-z)
	real*8 p(6)
	character*80   comment
	p = pa(:,ip)
	if(subst_pl(0,ip).and.l.eq.0) p=ps(:,ip)
	if(subst_pl(1,ip).and.l.eq.1) p=pp(:,ip)
	if(subst_pl(2,ip).and.l.eq.2) p=pd(:,ip)
	if(subst_pl(3,ip).and.l.eq.3) p=pf(:,ip)
	pot = 0d0
	if(typc(ip).eq.'gau') then
	  do i=1,5,2
	   if(p(i) /= 0d0 .and. p(i+1) /= 0d0)  &
	     pot = pot + p(i)*ddexp(-(r/p(i+1))**2)
	  enddo
	else if(typc(ip).eq.'ws') then
	  do i=1,4,3
	   if(p(i) /= 0d0 .and. p(i+2) /= 0d0)  &
	     pot = pot + p(i)/(1d0+ddexp((r-p(i+1))/p(i+2)))
	  enddo
	else if(typc(ip).eq.'alf') then
	   if(p(5) /= 0d0 .and. p(3) /= 0d0)  then
             ee=1. + p(4)*dexp(-(r/p(5))**2)
	     pot=pot+p(1)*ee/(1.d0+dexp((r-p(2))/(2.*p(3))))**2 
	     endif
	else if (typc(ip).eq.'rnp') then
	if (r.ne.0) then
	  x=0.7*r
	  ex=exp(-x)
	  pot=ex*(-10.463+ex*(102.012+ex*ex*  &
		(-2915.0+7800.0*ex*ex)))/x
!	print*,'vc: ',l,r,pot
	endif
	else if (typc(ip).eq.'rnn') then
	if (r.ne.0) then
	  x=0.7*r
	  ex=exp(-x)
	  pot=ex*(-10.463-ex**3*(1650.6-ex**3*6484.2))/x
	endif
	else if (typc(ip).eq.'rea') then
	  if(.not.readin(ip)) then  ! read in potentials for first time
	    numfile = nint(p(1))
	    lset(ip)  = nint(p(2)); if(lset(ip)<1) lset(ip)=1
	    loop(ip)  = nint(p(3)) > 0 
	    open(numfile,status='unknown')
            read(numfile,'(a)') comment
            read(numfile,*) npoints(ip),rstep(ip),rfirst(ip)
            write(6,71) ip,comment,npoints(ip),rstep(ip),rfirst(ip),lset(ip),loop(ip)
71          format(/'  Potential ',i1,' read in :',a80/ &
     &   '   Reading ',i4,' data points at ',f8.4,' intervals, starting from r =',f8.4,&
     &  /'   as set of ',i3,' L-values,  looping=',l1/)
            if(.not.allocated(potls)) allocate(potls(npoints(ip),lset(ip),3))
            do i=1,lset(ip)
             read(numfile,*) potls(1:npoints(ip),i,ip)
             enddo
	     write(10,*) ' Potentials read in'
             write(10,71) ip,comment,npoints(ip),rstep(ip),rfirst(ip),lset(ip),loop(ip)
	     rad=rfirst(ip)
	     do ir=1,npoints(ip)
	     write(10,72) rad,(potls(ir,i,ip),i=1,lset(ip))
72	     format(f7.2,1p,10g11.3)
	     rad = rad + rstep(ip)
	     enddo
	    readin(ip) = .true.
	    close(numfile)	  
	   endif
          
          iset = mod(l,lset(ip))+1
          if(l>lset(ip)-1.and..not.loop(ip)) then
             pot = 0.
           else
             pot = ff(r-rfirst(ip),rstep(ip),potls(1,iset,ip),npoints(ip))
           endif
	
	else if(typc(ip).ne.'nul') then
	 write(6,*) ' Unknown central potential ',typc(ip),ip
	endif
!				Do NOT add here the Coulomb part:
!	vc = pot+vcoul(r,ip)
 	vc = pot
	end
        
	function vcoul(r,ip)
	use physics
	use potentials
	implicit real*8(a-h,o-z)
	   rr = max(r,1d-3)
           sc = 1d0/rr
           if (rr<rcoul(ip)) sc = (1.5d0 -0.5d0*(r/rcoul(ip))**2)/rcoul(ip)
	   vcoul = coulcn * z(pairs(1,ip))*z(pairs(2,ip)) * sc
        return
        end

	function vls(l,r,ip)
	use physics
	implicit real*8(a-h,o-z)
	parameter(rtrim=0.5)
	real*8 p(6)
	pot = 0d0
	p=pso(:,ip)
	if (l.eq.1.and.abs(psop(1,ip)).gt.1d-9) p=psop(:,ip)
	if (l.eq.2.and.abs(psod(1,ip)).gt.1d-9) p=psod(:,ip)
	if (l.eq.3.and.abs(psof(1,ip)).gt.1d-9) p=psof(:,ip)
	 trim=1.0
	 if(r<rtrim.and.rtrim>0.) trim=r/rtrim
	if(typso(ip).eq.'gau') then
	  do i=1,5,2
	   if(p(i) /= 0d0 .and. p(i+1) /= 0d0)  &
	     pot = pot + p(i)*ddexp(-(r/p(i+1))**2)
	  enddo
	else if(typso(ip).eq.'ws') then
	  do i=1,4,3
	   if(p(i) /= 0d0 .and. p(i+2) /= 0d0.and.r>0d0)  then
	     ex = ddexp((r-p(i+1))/p(i+2))
	     pot = pot + p(i)*ex/((1d0+ex)**2*r*p(i+2))
	     endif
	  enddo
	else if (typso(ip).eq.'rnp'.or.typso(ip).eq.'rnn') then
	if (r.ne.0) then
	  x=0.7*r
	  ex=exp(-x)
	  pot=251.572*ex**4/x
	endif
	else if(typso(ip).ne.'nul') then
	 write(6,*) ' Unknown spin-orbit potential ',typso(ip),ip
	endif
	vls = pot * trim
	end

	function vss(l,r,ip)
	use physics
	implicit real*8(a-h,o-z)
	real*8 p(6)
	pot = 0d0
	p=pss(:,ip)
	if (l.eq.0.and.abs(psss(1,ip)).gt.1d-9) p=psss(:,ip)
	if (l.eq.1.and.abs(pssp(1,ip)).gt.1d-9) p=pssp(:,ip)
	if (l.eq.2.and.abs(pssd(1,ip)).gt.1d-9) p=pssd(:,ip)
	if (l.eq.3.and.abs(pssf(1,ip)).gt.1d-9) p=pssf(:,ip)
	if(typss(ip).eq.'gau') then
	  do i=1,5,2
	   if(p(i) /= 0d0 .and. p(i+1) /= 0d0)  &
	     pot = pot + p(i)*ddexp(-(r/p(i+1))**2)
	  enddo
	else if(typss(ip).eq.'ws') then
	  do i=1,4,3
	   if(p(i) /= 0d0 .and. p(i+2) /= 0d0)  &
	     pot = pot + p(i)/(1d0+ddexp((r-p(i+1))/p(i+2)))
	  enddo
	else if(typss(ip).ne.'nul') then
	 write(6,*) ' Unknown spin-spin potential ',typss(ip),ip
	endif
	vss = pot
	end

	function vt(l,r,ip)
	use physics
	implicit real*8(a-h,o-z)
	real*8 p(6)
	pot = 0d0
	p=pt(:,ip)
	if(typt(ip).eq.'gau') then
	  do i=1,5,2
	   if(pt(i,ip) /= 0d0 .and. pt(i+1,ip) /= 0d0)  &
	     pot = pot + pt(i,ip)*ddexp(-(r/pt(i+1,ip))**2)
	  enddo
	else if (typt(ip).eq.'rnp'.or.typt(ip).eq.'rnn') then
	if (r.ne.0) then
	  x=0.7*r
	  y=1.0/x
	  ex=exp(-x)
	  pot=ex*y*(-10.463*(1.+3.*y*(1.+y)-3.*y*(4.+y)*ex**3) &
		+ex**3*163.016)	  
	endif
	else if(typt(ip).ne.'nul') then
	 write(6,*) ' Unknown tensor potential ',typt(ip),ip
	endif
	vt = pot
	end

	function v3b(ich,jch,r,ijt)
	use physics
	implicit real*8(a-h,o-z)
	v3b = 0d0
	if(ich/=jch) return
	if(typ3b.eq.'gau') then
	   if(s3b(ijt) /= 0d0 .and. r3b(ijt) /= 0d0)  &
	     v3b = s3b(ijt)*ddexp(-(r/r3b(ijt))**2)
	else if(typ3b.eq.'ws') then
	   if(s3b(ijt) /= 0d0 .and. a3b(ijt) /= 0d0)  &
	     v3b = v3b + s3b(ijt)/(1d0+ddexp((r-r3b(ijt))/a3b(ijt)))
	else if(typ3b.eq.'pow') then
	   if(s3b(ijt) /= 0d0) &
	     v3b = v3b + s3b(ijt)/(1d0+(r/r3b(ijt))**a3b(ijt))
	else if(typ3b.ne.'nul') then
	 write(6,*) ' Unknown 3-body potential ',typ3b,ijt
	endif
	end
      FUNCTION FF(Y,H,F,N)
      IMPLICIT REAL*8(A-H,O-Z)
      REAL*8 F(N),P,Y,H,P1,P2,Q,X,FF
      DATA X/.16666666666667D0/
      P=Y/H
      I=P
      IF(I.LE.0) GO TO 2
      IF(I.GE.N-2) GO TO 4
    1 P=P-I
      P1=P-1.
      P2=P-2.
      Q=P+1.
      FF=(-P2*F(I)+Q*F(I+3))*P*P1*X+(P1*F(I+1)-P*F(I+2))*Q*P2*.5
      RETURN
    2 IF(I.LT.0) GO TO 3
      I=1
      GO TO 1
    3 FF=F(1)
      RETURN
    4 IF(I.GT.N-2) GO TO 5
      I=N-3
      GO TO 1
    5 FF=0.
      RETURN
      END
