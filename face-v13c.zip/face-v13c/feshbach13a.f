      subroutine feshbach
        use physics
        use methodspec
        use work
      implicit double precision (a-h,o-z)
      DIMENSION  XM(imaxe,imaxe),B(imaxe,imaxe),GG(imaxe,imaxe)
      INTEGER IPIV(imaxe)
      LOGICAL SING,OK,PRT
      parameter(PRT=.false.)

c		NF counts channels to include  -> IFO(*,1)
c		ND counts channels to eliminate  -> IFO(*,2)
C		IFO(*,3) indexes from original to new channel (or 0 if none)
       NF = 0
       ND = 0
       do 4 I=1,imaxe
	k = kkh(I)
  	 ic1=iih(I,1)
	 ic2=iih(I,2)
	 ic3=iih(I,3)
	 ICORE = max(ic1,ic2,ic3)
        OK = k.le.abs(KMAXF(ICORE)).or..not.FESH
        if(OK) then
         NF = NF+1
         IFO(NF,1) = I
         IFO(I,3) = NF
        else
         ND = ND+1
         IFO(ND,2) = I
         IFO(I,3) = 0
	endif
4	continue
	imaxh = NF
	if(ND==0) go to 101
 	write(6,10) KMAXF,NF,ND
10      format(/'  Feshbach reduction K <=',3i3,' to ',i3,
     x	     ' channels, omit',i4)

C
C----  REDUCE THE COUPLING TERMS WW  to K<=KMAXF
c
	rewind iwf
	iwn = 121-iwf
	rewind iwn
        open(iwn,access='sequential',status='scratch',
     x            form='unformatted')
	do 100 ir=1,nlag
	R =  rr*xl(ir)
	if(PRT) write(6,41) NF,R
41        format('  Reduced ',i3,' coupling matrix at R =',F8.3)
	read(iwf) ww(1:imaxe,1:imaxe)
	 IFAIL = 0
	do 60 I=1,ND
	ICI = IFO(I,2)
	do 50 J=1,ND
	ICJ = IFO(J,2)
50	XM(J,I) = WW(ICI,ICJ)
	k = kkh(ICI)
	ic1=iih(ICI,1)
	ic2=iih(ICI,2)
	ic3=iih(ICI,3)
	ib = ibh(ICI)
	 et = energy(ic1,ib) + energy(ic2,pairs(1,ib)) 
     x		  	     + energy(ic3,pairs(2,ib))
	XM(I,I)=XM(I,I) + et + h2sm*(K+1.5)*(K+2.5)/(R*R) - EFESH
60	continue
C
C		Now do Feshbach reduction in the Pauli-allowed subspace

C				RHS:
	DO 70 I=1,ND
	ICI = IFO(I,2)
	DO 70 J=1,NF
	 ICJ = IFO(J,1)
	XM(I,J+ND) = WW(ICJ,ICI)
70	B(I,J) = WW(ICI,ICJ)

	  call dgetrf(ND,ND,XM,imaxe,IPIV,ifail)
		if(ifail.ne.0) then
	     write(6,*)' Eigenstate at rho=',r,'!'
	      stop 'Feshbach'
		endif
          call dgetrs('N',ND,NF,XM,imaxe,IPIV,XM(1,ND+1),imaxe,info)

	DO 75 I=1,ND
	DO 75 J=1,NF
75	GG(J,I) = XM(I,J+ND)

	DO 80 I=1,NF
	DO 80 J=1,NF
80	XM(I,J) = WW(IFO(I,1),IFO(J,1))

	ONE = 1d0
	call dgemm ('n','n',NF,NF,ND,-ONE,GG,imaxe,B,imaxe,ONE,XM,imaxe)

C				So here Matrix reformatted from 1
	write(iwn) XM(1:NF,1:NF)
100	continue
            close(iwf,status='delete')
	iwf = iwn
C			The quantum numbers now rearranged!
	do i=1,NF
	i1 = IFO(i,1)
	kkh(i) = kkh(i1)
	iih(i,1:3) = iih(i1,1:3)
	ibh(i) = ibh(i1)
	enddo
!     	write(6,*) ' Hamiltonian reduced to ',NF,' orthoNormal channels'
	if(PRT) write(6,*) ' kkh:',(kkh(I),I=1,NF)
	if(PRT) write(6,*) ' iih:',(iih(I,1:3),I=1,NF)
	
	write(6,*) ' New Feshbach reduced Basis:'
      	do i1=1,imaxh,16
        nchl = min(i1+15,imaxh)
	write(6,1480)
	write(6,1480)'i',(mod(i,1000),i=i1,nchl)
	write(6,1480)'K',(kkh(i),i=i1,nchl)
	write(6,1480)'Ch',(IFO(i,1),i=i1,nchl)
        write(6,1480)'iy',(iih(i,1),i=i1,nchl)
        write(6,1480)'ix',(iih(i,2),i=i1,nchl)
        write(6,1480)'iz',(iih(i,3),i=i1,nchl)
	write(6,1481)'ic',(sym(ibh(i)),i=i1,nchl)
	enddo
 1480   format(1x,a2,2x,16i4,:,/(2x,i2,16i4))	
 1481   format(1x,a2,2x,16(3x,a1),:,/(2x,i2,16(3x,a1)))	

101	return
	end

