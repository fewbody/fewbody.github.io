	subroutine eigen
	use physics
	use methodspec
	use work
	use groundstate
	implicit real*8(a-h,o-z)
	real*8,allocatable:: wm(:,:),rl(:,:),vecsr(:,:),vecsi(:,:)
	real*8,allocatable:: trwf(:,:),trchan(:,:)
	real*8 valr(meig),vali(meig),belv(meig)
	real*8 pvec(jjmax),vecnm(jjmax),sum(3),chnm(imaxs),pchnm(imaxs)
	real*8 rpower(0:nbmax,0:nbmax),uses(imaxh)
	real*8 lagnorm,vec(jjmax)
	real*8 dsde(jjmax),cnorm(maxl),cnnorm(0:maxl,maxl)
	real*8 xjj,yjj,tjab,jabmin,plnorm(-1:maxl)
	integer niter(jmax)
	character*6 eigt
	logical prmats, pr
	real time(2)

	prmats = .false.
	zero = 0d0
	iff1 = 6
	iff2 = 10
	iff = iff1
	call flush(6)
1	continue
	write(6,*) '   allocate wm array of ',int(jmax**2*8/1e6)+1,' Mb'
	allocate (wm(jmax,jmax),rl(0:nbmax,nlag),stat=ial)

	if(ial/=0) then
	  nbmax = nbmax-1
	  write(6,*) '   ALLOCATION FAILED. Try nbmax =',nbmax
	  jmax = imaxh*(nbmax+1)
	  jjmax = imaxs*(nbmax+1)
	  meig = meigs(ijt)
	  if(meig==0) meig=jmax
	  if(nbmax>5) go to 1
	  stop
	endif
	allocate (vecsr(jjmax,meig),vecsi(jmax,meig),stat=ial)
	if(ial/=0) then
	  write(6,*) '   Tried to allocate vecs arrays of ',int(2*jjmax*meig*8/1e6)+1,' Mb'
	  write(6,*) '   Not enough room for these ',meig,' eigensolutions'
	  stop
	endif

! storing hyperradial functions
	open(9,recl=132,access='sequential')
	s2 = 1d0/sqrt(rr)
	do 202 j=1,nlag
	u=xl(j)
	s=u**2.5d0 * exp(-u*0.5d0)
	do 20 n=0,nbmax
20	rl(n,j)=polag(n,5.d0,u)*lagnorm(n,5.d0)	* s
	write(9,201) u*rr,(s2*rl(n,j),n=0,min(10,nbmax))
201     format(f7.3,12g11.3)
202	continue
	  do 212 n=0,nbmax
	  do 212 n1=0,nbmax
	   r2 = 0.0
	   do 211 i=1,nlag
211	   r2 = r2 + (xl(i)*rr)**2 * wl(i) * rl(n,i) * rl(n1,i)
212	   rpower(n,n1) = r2

!			Kinetic, centrifugal and core energies
	wm(:,:)=0.
	hh=h2sm/(rr*rr)
	do 22 i=1,imaxh
	do 22 n=0,nbmax
	j=(nbmax+1)*(i-1)+n+1
	   i1=i ! do 23 i1=1,imaxh
	do 23 n1=0,nbmax
	j1=(nbmax+1)*(i1-1)+n1+1
	k=kkh(i)
	ic1=iih(i,1)
	ic2=iih(i,2)
	ic3=iih(i,3)
	ib = ibh(i)
	 et = energy(ic1,ib) + energy(ic2,pairs(1,ib)) + energy(ic3,pairs(2,ib))
	if(i.eq.i1) wm(j,j1)=wm(j,j1)+ekin(n,n1,k)*hh
	if(j.eq.j1) wm(j,j1)=wm(j,j1)+et
23	continue
22	continue

!			Potential couplings
	rewind iwf
	do 25 il=1,nlag
	read(iwf) ww(1:imaxh,1:imaxh)
	do 24 i1=1,imaxh
	do 24 n1=0,nbmax
	 j1=(nbmax+1)*(i1-1)+1+n1
	do 24 i=1,imaxh
	 j0=(nbmax+1)*(i-1)+1
	 t = rl(n1,il) * ww(i,i1) * wl(il)
	do 24 n=0,nbmax
	 j=j0+n
	wm(j,j1)=wm(j,j1) + t*rl(n,il)
24	continue
25	continue

	write(6,*) ' Matrix elements found in Gauss-Laguerre Basis'
	call flush(6)

	if(eqn.ne.'F') then
	do i=1,jmax
	do j=1,i
	if(abs(wm(i,j)-wm(j,i)) > 1d-3*max(1d0,abs(wm(j,i)))) then
	  write(55,*) i,j,wm(i,j),wm(j,i)
	  endif
	  enddo
	  enddo
	endif
! --------------------------------------------
 	if(prmats) then
 	   write(6,*) 'WM interaction matrix:',jmax
 	   call wrtmat(wm,jmax,jmax,jmax,6)
 	 endif	
! --------------------------------------------
	write(6,*) ' Diagonalise matrix of size ',jmax
	call flush(6)
	niter(:)= 0
	  if(meig<jmax) then
	   iv2 = min(meig,10)
	    write(6,*) ' Search for ',iv2,' eigenstates near ',real(eig)
	   call invitrm(wm,jmax,jjmax,jmax,valr,vecsr,iv2,eig,1d-5,50)
	     do i=1,iv2
	        vali(i) = 0d0
	     enddo
	  else 
! 			     find all eigenvalues (complex in general)
	  ifail=0
	  write(6,*) '  find all eigensolutions'
	  call f02agf(wm,jmax,jmax,valr,vali,vecsr,jjmax,vecsi,jmax,niter,ifail)
	  iv2=jmax
	  write(6,*) '  found ',iv2,' eigensolutions' 
	  endif

	if(iv2>0) write(6,50) jtot,psign(jparity+2),(valr(i),i=1,iv2)
50	format(' Found',f6.1,a1,' Evals at:',(1x,10f10.3))
	  thresh = 0.001
	  if(eqn.eq.'F'.and.iv2.gt.1) write(6,62) thresh
62	format(/' Renormalising eigenstates with threshold =',1p,e12.2)
	  call flush(6)
!
	egs = 1d5
	iv0 = 0
        do 70 iv=1,iv2
	 if(valr(iv).lt.egs) then
		iv0  = iv
		egs = valr(iv)
		endif
70	continue

	belv(:) = 0.
!	do 500 iv=iv2,1,-1
	do 500 iv=1,iv2
	if(iv2.gt.1) then
	 write(19,'(i4,2f12.5,i4)') iv,valr(iv),vali(iv),niter(iv)
	 call flush(19)
	endif
	if(valr(iv).gt.max(2*emax,eimax)) go to 500
!	if(eimax.gt.eimin.and.valr(iv).gt.0.0.and.iv.ne.iv0) go to 500
!	  write(6,*) ' analyse E-state ',iv
! ***** normalise solution vector with norm matrix wn1
!	  write(6,*) ' normalise e-state ',iv
	if(.not.(fesh.or.effp)) then
	  vec(:) = vecsr(:,iv)
	else
	  write(6,*) 'Redistribute from ',IMAXH,' reduced basis'
	  vec(:) = 0d0
	  do 3131 i=1,imaxh
	  i1 = IFO(i,1)		! undo Feshbach
 	  i1 = IEO(i1,1)	! undo Effpot
	  do 3131 N=0,nbmax
	    j=(nbmax+1)*(i-1)+N+1
	    j1=(nbmax+1)*(i1-1)+N+1
3131	  vec(j1) = vecsr(j,iv)
	endif

	if(eqn.ne.'F'.and..false.) then
	  s2 = 0.0
	  do 120 i1=1,imaxh
	  uses(i1) = 0.0
	  do 118 N=0,nbmax
	    j1=(nbmax+1)*(i1-1)+N+1
118	    uses(i1) = uses(i1) + vec(j1)**2
120	  s2 = s2 + uses(i1)
	write(6,122) (i1,uses(i1)/s2,i1=1,imaxh)
122	format(1x,8(i3,f8.5),/(1x,8(i3,f8.5)))
	endif

	if(init>0) then		! reform the full eigenstate
!	write(6,*) 'Reexpand eval ',iv,' from ',imaxh,' to ',imaxs
	  DO 320 I=1,imaxs
	  DO 320 N=0,nbmax
	    j=(nbmax+1)*(I-1)+N+1
	    S = 0d0
	    do 318 i1=1,imaxh
	        j1=(nbmax+1)*(i1-1)+N+1
318		S = S + CTN(I,i1)*vec(j1)
320	    pvec(j) = S
	  DO 321 j=1,jjmax
321	    vec(j) = pvec(j)
	  jmax = jjmax
	endif
!				 Now have full imaxs channels
	s2 = 0.0
	do 90 i=1,imaxs
	do 90 n=0,nbmax
	j=(nbmax+1)*(i-1)+n+1
	s=0.
	do 88 i1=1,imaxs
	  n1=n
	  j1=(nbmax+1)*(i1-1)+n1+1
	  s=s+wn1(i,i1)*vec(j1)
88	  continue
	s2 = s2 + s*vec(j)
	pvec(j) = s
90	continue
!	  write(6,*) '  e-state ',iv,' has initial norm',real(s2)
	if(s2.le.thresh) then 
	   write(6,*) '  e-state ',iv,' @ ',real(valr(iv)),		&
     &				' with norm ',real(s2),' ignored'
	   valr(iv) = 1d6
!				Find new gs if required
		iv0 = 0
        	do iv1=1,iv2
	 	if(valr(iv1).lt.egs) then
			iv0  = iv1
			egs = valr(iv1)
			endif
		enddo
	   go to 500
	endif
	s2 = 1.0/sqrt(s2)
	sum(:)=0d0
	do 95 i=1,imaxs
	chnm(i) = 0.0
	pchnm(i) = 0.0
	ik = iba(i)
	xz=1.0
	  ip = mod(ik,3)+1   ! find ip which might have id(ip)
          if(id(ip)) xz=0.5
	do 95 n=0,nbmax
	j=(nbmax+1)*(i-1)+n+1
	vecnm(j) = vec(j) * s2
	pvec(j) = pvec(j) * s2 * xz
	chnm(i) = chnm(i) + vecnm(j)**2
	pchnm(i) = pchnm(i) + pvec(j)**2
	sum(ik) = sum(ik) + pvec(j)**2
95	continue
!	  write(6,*) ' normalised e-state ',iv
	eigt = 'Scatt'
	if(valr(iv).lt.0) eigt = 'Bound'
	if(abs(vali(iv)).gt.0d0) then
	 write(iff,102) eigt,jtot,psign(jparity+2),iv,valr(iv),vali(iv)
	else
	 write(iff,101) eigt,jtot,psign(jparity+2),iv,valr(iv)
	endif
	 call flush(6)
101	format(/1x,a5,f5.1,a1,' eig',i5,' =',f12.6,:,' @ ',i4)
102	format(/1x,a5,f5.1,a1,' eig',i5,' =',f12.6,g11.2,:,' @ ',i4)

!			calculate rms of full wfn:
	rms = 0.0
	do 203 i=1,imaxs
	do 203 n=0,nbmax	
	  j=(nbmax+1)*(i-1)+n+1
	do 203 i1=1,imaxs
	do 203 n1=0,nbmax	
	  j1=(nbmax+1)*(i1-1)+n1+1
	rms = rms + vec(j) * vec(j1) * rpower(n,n1) * wn1(i,i1)
203	continue
	rms =  rms * s2*s2
	rmat = 0d0
	do ip=1,3
	 rmat = rmat +  mass(ip) * radius(ip)**2
	enddo
	rmat = sqrt((rmat + rms)/masstot)
	write(iff,208) sqrt(rms),rmat
208	format( '  rms <rho> =',f7.3,' fm., rms matter radius =',f7.3,' fm.')

	if(valr(iv)<eimax) then
	do iff=iff1,iff2,iff2-iff1
          write(iff,250) 
250	  format(/'  Probability norms in eigenstate:'//, &
     &   '   i:  K  L  sx lx ly jp  i#        normalised      permuted')
	 do 270 ib=1,3
	    if(imax(ib)>0) write(iff,*) ' '//sym(ib)//':'
	    plnorm(-1) = 0.0
	    do 252 ll=0,5
252	    plnorm(ll) = 0.0
	 do 260 ic=1,imax(ib)
	    i = ic + imax0(ib)
	    write(iff,255) i,kk(ic,ib),lltot(ic,ib),ssx(ic,ib),   &
     &                 ll1(ic,ib),ll2(ic,ib), jab(ic,ib), &
     &                 (ii(ic,in,ib),in=1,3),             &
     &                 chnm(i),pchnm(i)
255	    format(1x,i4,2i3,f4.1,2i3,f4.1,3i2,2f14.8)	
!	print*, chnm(i),pchnm(i)
 	if(iff.eq.10) then
	  write(iff,256) 'norm',(vecnm((nbmax+1)*(i-1)+n+1),n=0,min(4,nbmax))
 	  write(iff,256) 'perm',(pvec((nbmax+1)*(i-1)+n+1),n=0,min(4,nbmax))
256	  format(15x,a4,':',5f12.8)
	endif
	call flush(iff)
	ll=lltot(ic,ib)
	if(ll1(ic,ib).eq.0.d0.and.ll2(ic,ib).eq.0.d0) ll=-1
	if (ll.le.5) plnorm(ll) = plnorm(ll) + pchnm(i)   
260 	continue
!        write(iff,*) ' Summary of components:'
	write(iff,262) (plnorm(li),li=-1,2)
262	 format(/'   P(S) =',f9.6,',  P(S'') =',f9.6, &
     &           ', P(P) =',f9.6,', P(D) =',f9.6/)
270 	continue
	write(iff,280) (sym(ib),sum(ib),ib=1,3)
280	format('   norm of ',a1,' channels =',f10.6)

!	norms in jj coupling from X, Y and T components
	do 380 ib=1,3
	if(imax(ib).gt.0) then
	write(iff,*) ' '
	write(iff,*) ' JJ coupling: ',sym(ib)
	s3 = 0.0
!	defining the number of core states
	if (ns(1)>1) icore=1
	if (ns(2)>1) icore=2
	if (ns(3)>1) icore=3
	 if (icore.eq.ib) then
	 	ii1max=ns(ib)
	 else
		ii1max=1
	 endif
	 if (icore.eq.pairs(1,ib)) then
	 	ii2max=ns(pairs(1,ib))
	 else
	 	ii2max=1
	 endif
	 if (icore.eq.pairs(2,ib)) then
	 	ii3max=ns(pairs(2,ib))
	 else
	 	ii3max=1
	 endif
	cnorm(:) = 0.
	cnnorm(:,:) = 0.
	do 372 ii1=1,ii1max
	do 372 ii2=1,ii2max
	do 372 ii3=1,ii3max
	 sn1=spin(ii1,ib)
	 sn2=spin(ii2,pairs(1,ib))
	 sn3=spin(ii3,pairs(2,ib))
	 do 372 tjab=jtot-sn1,jtot+sn1
	 if (tjab.lt.0.d0) goto 372
	 jab1=nint(tjab)
	 l1max=lxmax(ib)
	 l2max=lymax(ib)
	 do 371 l1=0,l1max
	 do 371 l2=0,l2max
	 do 371 xjj=l1-sn2,l1+sn2
	 if (xjj.lt.0.d0) goto 371
	 do 370 yjj=l2-sn3,l2+sn3
	 if (yjj.lt.0.d0) goto 370
!	 if(fesh.and.l1+l2.gt.kmaxf) go to 370       !is this needed?
	 pr=.false.
	 s = 0.0
	 do 367 k=0,kmaxa(ib)
	  sk = 0.0
	    do 362 n=0,nbmax
362	    dsde(n+1) = 0.
	  do 365 ic=1,imax(ib)
	   i=ic+imax0(ib)
	   if (ii1.ne.ii(ic,1,ib).or.ii2.ne.ii(ic,2,ib).or.ii3.ne.ii(ic,3,ib)) goto 365
	   if(l1.ne.ll1(ic,ib).or.l2.ne.ll2(ic,ib).or.tjab.ne.jab(ic,ib).or. &
     &	   abs(xjj-yjj).gt.tjab.or.xjj+yjj.lt.tjab)    goto 365
           xj1=l1-sn2
	   yj1=l2-sn3
           if (max(xj1,0d0).gt.xjj.or.(l1+sn2).lt.xjj) goto 365
           if (max(yj1,0d0).gt.yjj.or.(l2+sn3).lt.yjj) goto 365
	   if(k.ne.kk(ic,ib)) goto 365
	   pr=.true.
	   t = sqrt((2*ssx(ic,ib)+1)*(2*lltot(ic,ib)+1)*(2*xjj+1)*(2*yjj+1)) &
     &		 * sim9j(l1+zero,l2+zero,lltot(ic,ib)+zero, &
     &                   sn2,    sn3,    ssx(ic,ib)+zero, &
     &			 xjj,     yjj,     tjab)
	   if(prmats.and.abs(t).gt.10E-3)  write(iff,364) ic,k,l1,l2,xjj,yjj,tjab,t
364	   format('angular: ',4i5,3f6.1,f10.4)
	   do 363  n=0,nbmax
	    j=(nbmax+1)*(i-1)+n+1
363	    dsde(n+1) = dsde(n+1) + t*pvec(j)
365	  continue
	  do 366 n=0,nbmax
366	    sk = sk + dsde(n+1)**2
367	 s = s + sk
	 if(pr.and.abs(s).gt.10E-3) write(iff,368) l1,nint(2*xjj), &
     &			       l2,nint(2*yjj),tjab,sn1,jtot,s
368	 format(2x,'[ ',I1,I2,'/2 + ',I1,I2,'/2 ]',F3.1,',', &
     &		F5.1,';',F5.1,' :',f14.8)
369	 format(/ 2x,'[ ',I1,F5.1,' + ',I1,F5.1,']',F3.1,',', &
     &		F5.1,';',F5.1,' @ K=',I3,':',f14.8 /)
	 s3 = s3 + s
	 
	 iicore=max(ii1,ii2,ii3)
	 cnorm(iicore) = cnorm(iicore) + s
	 cnnorm(jab1,iicore) = cnnorm(jab1,iicore) + s
!	 write(iff,*) 'tjab,jab1,iicore,cnnorm: ',tjab,jab1,iicore,cnnorm(jab1,iicore)
370     continue
371     continue
372     continue
	iicoremax=max(ii1max,ii2max,ii3max)
	if (iicoremax.gt.1) then
	do 375 ii1=1,iicoremax
375	write(iff,376) name(icore),ii1,cnorm(ii1),(cnnorm(j,ii1), &
     &                  j=nint(jabmin),min(nint(jabm(icore)),5))
376	format('  Prob(',a4,' in state',i2,') =',f10.6,' from Jab',6f10.6)
	endif
	if(abs(s3-1d0).gt.1e-6) write(iff,377) s3
377	format('  Total norm in jj basis =',F10.6)
	endif
380	continue


	enddo
	endif

	iff = 6



!		Calculate wave functions in ib basis
	ib = 3
	do i=1,3
	if(id(i)) ib=i
	enddo
          drr = 0.25
          NR = xl(nlag)*rr/drr
          write(18,385) drr,NR,imax(ib),jtot,jparity,valr(iv), & 
           		iv,valr(iv),sym(ib),sum(ib)
385       format('#',f8.4,2i4,f4.1,i2,f10.5/'# Eigensolution ',i4, &
     &       ' at E = ',g12.4,' in T basis, with ',a1,'-basis norm',f10.6&
     &         / '#    i:  K  L   S L1 L2 Jnn I#')

          S = 1d0/sqrt(rr)
          NS1 = (imax(ib)-1)/10+1
          do 396 IS=1,NS1
           nc1 = min(10,imax(ib)-(IS-1)*10)
	   if(nc1>0) then
           do 387 ic1=1,nc1
           ic=(IS-1)*10 + ic1
           write(18,386) ic,kk(ic,ib),lltot(ic,ib),ssx(ic,ib),   &
     &        ll1(ic,ib),ll2(ic,ib), jab(ic,ib),(ii(ic,in,ib),in=1,3)
!386       format('#',1x,I4,':',6I3,I4,I3)
386	  format('# ',2i4,i3,f4.1,2i3,f4.1,3i2)
387        continue
          do 390 ir=1,NR
            r = ir*drr
            U = r/rr
            S=U**2.5d0 * exp(-U*0.5d0) / sqrt(rr)
           chnm(1:nc1) = 0.0
          do 388 n=0,nbmax
            RLL = polag(n,5.d0,u)*lagnorm(n,5.d0) * s
          do 388 ic1=1,nc1
           ic=(IS-1)*10 + ic1
           iy=imax0(ib)+ic
           j=(nbmax+1)*(iy-1)+n+1
388       chnm(ic1) = chnm(ic1) + RLL*pvec(j)
!          write(118,395) r,(polag(n,5.d0,u)*lagnorm(n,5.d0)*s,n=0,min(9,nbmax))
390       write(18,395) r,(chnm(ic1),ic1=1,nc1)
395       format(f7.3,1p,10e12.4)
        write(18,*) '&'
	endif
396     continue
        call flush(18)
        
!			First J,pi : save ground state configuration
!			Later J,pi : calculate E1,E2 transitions from gs

	if(ijt==1.and.iv==iv0) then
!			First J,pi : save ground state configuration

	allocate(pvecgs(jjmax))
	allocate (kkgs(imaxs,3),lltotgs(imaxs,3),ll1gs(imaxs,3),ll2gs(imaxs,3))
        allocate (ssxgs(imaxs,3),jabgs(imaxs,3),iigs(imaxs,3,3),ibags(imaxs))
	jtotgs = jtot
	jparitygs = jparity
	imaxgs(:) = imax(:)
	imaxgs0(:) = imax0(:)
	imaxsgs = imaxs
	pvecgs(:) = pvec(:)
	kkgs = kk; lltotgs=lltot; ll1gs=ll1; ll2gs=ll2; ssxgs=ssx; jabgs=jab
	iigs = ii; ibags=iba
	write(6,*) '   Saved ',imaxsgs,' gs channels for transitions'
	
	else
!			Later J,pi : calculate E1,E2 transitions from gs
	if(.not.allocated(trwf)) allocate(trwf(imaxs,imaxsgs),trchan(imaxs,imaxsgs))

	ll= 2
	if(jparitygs*jparity<0) ll=1		! calculate multipoles LL
	write(6,*) ' Look for E',ll,' transitions: ',bel,' to ',valr(iv)
	
	if(ll.le.jtot+jtotgs .and. ll.ge.abs(jtot-jtotgs).and.bel) then
	do 530 n=0,nbmax
        do 530 n1=0,nbmax
        rp = 0.
        do 528 i=1,nlag
528        rp = rp + (xl(i)*rr)**ll * wl(i) * rl(n,i) * rl(n1,i)
530        rpower(n,n1) = rp
!       `Radial' integrals:
            do 545 iygs=1,imaxsgs
            do 545 iy=1,imaxs
            t = 0.0
            do 542 n=0,nbmax
             jgs=(nbmax+1)*(iygs-1)+n+1
             j=(nbmax+1)*(iy-1)+n+1
542         t = t +  pvecgs(jgs) * pvec(j)
	    trwf(iy,iygs) = t
	    t = 0.
            do 543 n=0,nbmax
            do 543 n1=0,nbmax
             jgs=(nbmax+1)*(iygs-1)+n+1
             j=(nbmax+1)*(iy-1)+n1+1
543         t = t +  pvecgs(jgs) * pvec(j) * rpower(n,n1)
545         trchan(iy,iygs) = t
	write(10,*) ' trchan(:,2) '
	write(10,*)  trchan(:,2)

          call belmag(ib,valr(iv),belv(iv),ll,trchan,trwf,10+ll)
          write(6,*) ' BE',ll,' from gs:',belv(iv)
          write(10,*) ' BE',ll,' calculated:',belv(iv)

	endif
	endif
500	continue
	if(sigma>0.) then  ! Calculate Lorentz transform

	write(6,*) 'emax,emin,dec =',emax,emin,dec
	ne = nint((emax-emin)/abs(dec))+1
	dec1 = (emax-emin)/(ne-1)
	 if(iv2==1) NE=0
	write(6,*) 'Sigma,ne,dec1 =',sigma,ne,dec1,iv2
	 
	do 630 ie=1,ne
	  ec = emin + (ie-1)*dec1
	belt = 0
	  do 620 iv=1,iv2
	  DEN = sigma*0.25/((ec-valr(iv))**2 + sigma**2)
620	belt = belt + belv(iv) * DEN

	if(abs(belt).gt.-1e-9) write(20+ll,629) ec,belt
629	format(f8.4,4f12.6)
630	continue	
	if(abs(belt).gt.-1e-9) write(20+ll,*) '&'
631	continue	
	endif


	call memuse
	write(iff,510) jtot,psign(jparity+2),egs
!	print*,egs
510	format(/' Ground state',f5.1,a1,' ENGY =',f12.6)
	deallocate(wm,rl)
	if(allocated(trwf)) deallocate(trwf,trchan)

	return
	end
