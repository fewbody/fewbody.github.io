	subroutine openfiles(nfile,docont,analgs,vadia)
	character*20 nfile
	logical docont,analgs,vadia

!         open (8,file = trim(nfile)//'.pw'				&
!    &		access='sequential',form='formatted',status='unknown')
          open (18,file =trim(nfile)//'.wf',				&
     &		access='sequential',form='formatted',status='unknown')
!         open (35,file =trim(nfile)//'.gseig',				&
!    &		access='sequential',form='formatted',status='unknown')
!         open (37,file =trim(nfile)//'.vha',				&
!    &		access='sequential',form='formatted',status='unknown')
!         open (38,file =trim(nfile)//'.vrr',				&
!    &		access='sequential',form='formatted',status='unknown')

  	 if(docont) then
           open (11,file =trim(nfile)//'.be1df',				&
      &		access='sequential',form='formatted',status='unknown')
           open (12,file =trim(nfile)//'.be2df',				&
      &		access='sequential',form='formatted',status='unknown')
!           open (13,file =trim(nfile)//'.strdf',				&
!      &		access='sequential',form='formatted',status='unknown')
           open (21,file =trim(nfile)//'.be1lt',				&
      &		access='sequential',form='formatted',status='unknown')
           open (22,file =trim(nfile)//'.be2lt',				&
      &		access='sequential',form='formatted',status='unknown')
!           open (23,file =trim(nfile)//'.strlt',				&
!      &		access='sequential',form='formatted',status='unknown')
 	 endif

 	 if(analgs) then
!          open (19,file =trim(nfile)//'.wfp',				&
!     &		access='sequential',form='formatted',status='unknown')
          open (44,file =trim(nfile)//'.md',				&
     &		access='sequential',form='formatted',status='unknown')
          open (45,file =trim(nfile)//'.sph',				&
     &		access='sequential',form='formatted',status='unknown')
          open (78,file =trim(nfile)//'.gs',				&
     &		access='sequential',form='unformatted',status='unknown')
!          open (79,file =trim(nfile)//'.rr',
          open (79,file ='sturm.rr', 					&
     &		access='sequential',form='formatted',status='unknown')
	 endif

 	 if(vadia) then
          open (91,file =trim(nfile)//'.ead',				&
     &		access='sequential',form='formatted',status='unknown')
          open (92,file =trim(nfile)//'.eadr',				&
     &		access='sequential',form='formatted',status='unknown')
	 endif
	end
