      subroutine rrcoe(k,l,l1,l2,c,s,t,a,j,j1)
!****  r.r. coefficients or hypersph. brackets are calculated here
!****  with the help of eqs. (28),(47) in yad.fiz. 17(1973)210 .
!****  l1 and l2 are jacobi momenta.two jacobi momenta in an another
!****  pair are designated below as l11 and l21. brackets with all
!****  possible l11,l12 values at given k,l,l1,l2 are calculated.

!****   version (april 1996, ijt) to handle c=0, t=inf

      use factorials
      implicit doubleprecision(a-h,o-z)
      dimension a(499,29)
!      common/rot/c,s,t,a(499,29),j1,j
!****    quantities c,s,t,a,j1,j,dlfac and dl2fac are defined
!****  as follows.
!****  c = cos(fi), s = sin (fi), t = tan(fi) with
!****  ksi11 = c*ksi1+s*ksi2, ksi21 = s*ksi1-c*ksi2, see eq.(6)
!****  in yad.fiz. 17(1973)210. the h.h. are defined as in eqs.
!****  (1) - (4) in that paper.
!      a = a(m,n) is a required array of brackets with given k,l,l1,l2
!      values. m and n variables specify
!      other pair of jacobi momenta l11 and l21 as follows
!      l11 = .5*(k-(l-nn))+n-m, l21 = .5*(k+(l-nn))-n-m+2.
!      the nn value equals 0 if k-l is even and 1 otherwise.
!      the m and n variables take all the integer values from
!      unity to j1=.5*(k-l-nn)+1 and j=l-nn+1 correspondingly
!      that gives all the l11 and l12 values permissible
!****  at given k,l,l1 and l2.
!****  dlfac(n)=ln(n!), dfacl(n)=ln((2n+1)!!).
      dimension b(499,29)
!****  the b array is an auxiliary one.
!****  dimensions of arrays a(i1,i) and b(i1,i) should be not less
!****  than i1=j1=.5(k-l-nn)+1 and i=j = l-nn+1 with j1 and j defined
!****  above.
      al(jp,jq,lx) =sqrt((jp+jq+lx)*(jp+jq+lx+1.d0)*(jp+jq-lx)*    &
      (jp+jq-lx-1.d0)/((2.d0*jp-1.d0)*(2.d0*jp+1.d0)*(2.d0*jq-1.d0)*    &
     &(2.d0*jq+1.d0)))
      be(jp,jq,lx) = sqrt((lx+jp-jq+1.d0)*(lx+jp-jq+2.d0)*(lx+jq-jp)*    &
     &(lx+jq-jp-1.d0)/((2.d0*jp+1.d0)*(2.d0*jp+3.d0)*(2.d0*jq-1.d0)*    &
     &(2.d0*jq+1.d0)))

!  eq.(48) ***********************************************
!            calculation of br.of eq.(28)
      p1=sqrt((2.d0*l1+1.d0)*(2.d0*l2+1.d0))
      p=dlfac(l1+l2+1)+.5d0*(dlfac(l1+l2+l+1)+dlfac(l1+l2-l))
      nnkl=k-l
      nn = nnkl-2*(nnkl/2)
      if(nnkl) 31,30,30
  31  write(6,40) k,l
      stop
  30  ldif=iabs(l1-l2)
      if(l1+l2-l) 32,33,33
  32  write(6,41) l1,l2,l
      stop
  33  if(l1+l2-k) 35,35,34
  34  write(6,42) l1,l2,k
      stop
  35  kpar=k-2*(k/2)
      l12par=l1+l2-2*((l1+l2)/2)
      if(kpar-l12par) 36,37,36
  36  write(6,43) l1,l2,k
  40  format(' check k and l value. k=',i4,' l=',i4)
  41  format(' check l1,l2 and l value. l1=',i4,' l2=',i4,' l=',i4)
  42  format(' check l1,l2 and k value. l1=',i4,' l2=',i4,' k=',i4)
  43  format(' check parity l1+l2 & k. l1=',i4,' l2=',i4,' k=',i4)
      stop
  37  if(l-ldif) 32,38,38
  38  ll = l-nn
      j1 = (l1+l2-l-nn)/2 +1
      j  = ll+1
	if(abs(c).le.1.1e-3) go to 90
      do 1 m=1,j1
      do 1 n=1,j
      l11 = (l1+l2-ll)/2+n-m
      l21 = (l1+l2+ll)/2-n-m+2
      ls1  = (l1+l2-l11-l21)/2
      lt1  = (l1+l2+l11+l21)/2
      q1=sqrt((2.d0*l11+1.d0)*(2.d0*l21+1.d0))
      q=dlfac(ls1)+dlfac(lt1+1)+dl2fac(ls1+l11)+dl2fac(ls1+l21)
! eq.(29)    *************************************************
      f  = 0.000d0
      lp1 = l1-ls1
      lq1 = l2-ls1
      i1 = iabs(lp1-l11)+1
      i2 = min0(lp1+l11,lq1+l21)+1
      do 2 mm=i1,i2,2
      lz1  = l11-mm+1
      lz2  = mm-l21-1
      lx1  = (lp1+lz1)/2
      lx2  = (lp1-lz1)/2
      lx3  = (lq1+lz2)/2
      lx4  = (lq1-lz2)/2
	if(abs(lp1-lq1).gt.l .or. lp1+lq1.lt.l .or.    &
     &     abs(lz1).gt.lp1   .or. abs(lz2).gt.lq1) go to 2
      f=f+(-1)**lx4*exp(.5*(dlfac(2*lx1)+dlfac(2*lx2)+    &
     &dlfac(2*lx3)+dlfac(2*lx4))-dlfac(lx1)-dlfac(lx2)-    &
     &dlfac(lx3)-dlfac(lx4))*t**(mm-1)*    &
     & wig(2*lp1,2*lq1,2*l,2*lz1,2*lz2)
 2    continue
      i   = -(l11+l21)
      a(m,n)=s**ls1*c**lt1*2.d0**i*p1*q1*exp(p-q)*f
 1    b(m,n) = a(m,n)
      k1  = l1 + l2 +2
      if(k-k1)25,4,4
 4    c2  = c**2 -s**2
      s2  = s*c
!  eq. (47), see label 19 in below  ***************************
      do 5 i=k1,k,2
      j1   = j1 +1
      lp11  = (i-ll)/2
      lp21  = (i+ll)/2
      do 6 m=1,j1
      do 6 n=1,j
      l11  = lp11+n-m
      l21  = lp21 -n-m+2
      if(m-2) 7,8,9
 7    a1   = 0.0000000
      a3   = 0.0000000
      a4   = 0.0000000
      a5   = 0.0000000
      go to 10
 8    a3   = 0.0000000
      go to 11
 9    a3   = b(m-2,n)*al(l11+1,l21+1,l)
 11   a1   = b(m-1,n)
      if(n-1)12,12,13
 12   a5   = 0.00000000
      go to 14
 13   a5   = b(m-1,n-1)*be(l21,l11,l)
 14   if(j-n) 15,15,16
 15   a4   = 0.00000000
      go to 10
 16   a4   = b(m-1,n+1)*be(l11,l21,l)
 10   if(j1-m) 17,17,18
 17   a2   = 0.0000000
      go to 19
 18   a2   = b(m,n)*al(l11,l21,l)
 19   a(m,n) = c2*a1+s2*(a2-a3+a4-a5)
  6   continue
      do 26 m=1,j1
      do 26 n=1,j
      b(m,n) = a(m,n)
  26  continue
  5   continue
!  eq.(12) *********************************************************
 25   ccc   =.5d0*(dlfac((k-l1-l2)/2)+    &
     &dlfac(1+(k+l1+l2)/2)+dl2fac((k-l1+l2)/2)+    &
     &dl2fac((k+l1-l2)/2))
      lp11  = (k-ll)/2
      lp21  = (k+ll)/2
      do 20 m=1,j1
      do 20 n=1,j
      l11  = lp11+n-m
      l21  = lp21-n-m+2
      fafun   =.5d0*(dlfac((k-l11-l21)/2)+    &
     &dlfac(1+(k+l11+l21)/2)+dl2fac((k-l11+l21)/2)+    &
     &dl2fac((k+l11-l21)/2))
      a(m,n)=a(m,n)*exp(fafun-ccc)
 20   continue
	if(j1.gt.499.or.j.gt.29) then
		write(6,*) j1,j,' needed in rrcoe'
		stop 'rrcoe'
	endif
      return
90    k1  = l1 + l2 +2
      do 91 i=k1,k,2
91    j1   = j1 +1
      do 95 m=1,j1
      do 95 n =1,j
	a(m,n) = 0.0
      l11 = (k-ll)/2+n-m
      l21 = (k+ll)/2-n-m+2
95    if(l11.eq.l2.and.l21.eq.l1) a(m,n) = (-1)**((k+l1+l2)/2 - l)
      end
