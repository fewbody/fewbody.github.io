	subroutine memuse
	end
	subroutine cpuuse
	real time(2)
	call etime(time)
	write(6,1) time
1	format(/'  User time =',f9.3,', system time =',f9.3,' secs'/)
!	call flush(6)
!	call system('echo On `hostname` at  `date`')
	return
	entry cpuuse0
	end
