      subroutine belmag(ib,ec,BEL,ll,trchan,trwf,nfi)
      use parameters
      use physics, charge=>z
      use work
      use groundstate
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      REAL*8 JCLI,JCHE,JNI,JNF
      integer ICI(3),ICF(3)
C    ***********************************************************
C  CALCULATION OF B(E1,2) FOR DISCRETISED EIGENSTATE OF REACTION
C  PRODUCTS FOR 3-BODY CONTINUUM
C	Assuming all charge is in particle ib and that other two are identical,
C	so using wavefunctions in ib basis (here called T).
C	Here, '3' refers to ib,
C	      '1' refers to mod(ib,3)+1, and '2' to mod(ib+1,3)+1
C
C    ***********************************************************
      DIMENSION TRCHAN(imaxs,imaxsgs),TRWF(imaxs,imaxsgs)
      INTEGER PHASE
	LOGICAL TR,TR1,TR2
	TR = .true.
	TR1= .true.
	TR2= .true.
	Z = 0d0
C######################################################################
	ib1 = mod(ib,3)+1; ib2 = mod(ib+1,3)+1
	A1 = mass(ib1); A2 = mass(ib2) ; A3 = mass(ib)
	S1 = spin(1,ib1); S2 = spin(1,ib2); Z3 = charge(ib)
C######################################################################
	
      ASUM = A1 + A2 + A3
CC
C ***   IE - MULTIPOLARITY OF TRANSITION
      IE = LL
        WRITE(64,151) IE
        WRITE(64,*) 'A, spins1,2, Z3 =',A1,A2,A3,S1,S2,Z3,NFI
        WRITE(64,*) 'charge ',charge
  151 FORMAT(3X,'B(E',I1,')   CALCUL. BEGINS          '/)
        AJ = (2.D0*jtot+1)/(2.D0*jtotgs + 1)
C
      IF(IE .EQ. 1) GO TO 2000
      IF(IE .EQ. 2) GO TO 3000
         GO TO 4000
C
C  ##########################################################################
C
C  ****  E1 TRANSITION
C
C
C
C ****** LOOP ON CONTNUUS SPECTRA  (RADIUS)
2000   AL1 = 1.D0/(4.D0*3.14159D0)*Z3**2*((A1+A2)/(ASUM*A3))

       if(TR1) write(64,*) ' BE:',imaxs,imaxsgs,real(EC)
       SUMR = 0.0
       DO 2002  i1 = 1,imax(ib)
       IF = imax0(ib)+i1
       KF = kk(i1,ib)
        LF = lltot(i1,ib)
         SF = ssx(i1,ib); ISF = nint(SF)
          LXF = ll1(i1,ib)
           LYF = ll2(i1,ib)
             JNF = jab(i1,ib); IJNF = nint(JNF)
               ICF(:) = ii(i1,:,ib)
	       JCHE= spin(ICF(3),ib)
C ****** LOOP ON DISCRET SPECTRA
      DO 2003  j1 = 1,imaxgs(ib)
       JI = imaxgs0(ib)+j1
       KI = kkgs(j1,ib)
        LI = lltotgs(j1,ib)
         SI = ssxgs(j1,ib); ISI = nint(SI)
          LXI = ll1gs(j1,ib)
           LYI = ll2gs(j1,ib)
             JNI = jabgs(j1,ib); IJNI = nint(JNI)
               ICI(:) = iigs(j1,:,ib)
               JCLI = spin(ICI(3),ib)
C *****  GENERAL CHECK ON INACTIVE Q.N.
	PHASE = (-1)**nint(LI+ISI- jtotgs + LF+ISF-jtot)
       IF(ICF(1) .NE. ICI(1)) GO TO 2003
       IF(ICF(2) .NE. ICI(2)) GO TO 2003
       IF(ICF(2) .NE. ICI(3)) GO TO 2003
        IF(SF .NE. SI) GO TO 2003
         IF(LXF .NE. LXI) GO TO 2003
          IF((KF+1) .LT. KI) GO TO 2003
C
      if(TR1) WRITE(64,1011) KI,LI,ISI,LXI,LYI,JNI,ICI,nint(JCLI),
     X                       KF,LF,ISF,LXF,LYF,IJNF,ICF,nint(JCHE)
1011  FORMAT(1X,' < GS ',10I3,' /START/  ',10I3,' > ')
C ********  LOOP ON LY+-1 **************************************
C
            DO 2004 NNL = 1,2
             IF(NNL .EQ. 1) IDLY = -1
             IF(NNL .EQ. 2) IDLY =  1
                  LYI1 = LYI + IDLY
C  *** SELECTION  ON LY
        IF(LYI1 .LT. 0) GO TO 2004
         IF(LYI1 .NE. LYF) GO TO 2004
C ********  LOOP ON KI+-1 **************************************
            DO 2005 NKI = 1,2
             IF(NKI .EQ. 1) IDKI = -1
             IF(NKI .EQ. 2) IDKI =  1
                  KI1 = KI + IDKI
C  *** SELECTION  ON K - 1
        IF(KI1 .LT. 0) GO TO 2005
         IF(KI1 .NE. KF) GO TO 2005
          IF(KI1 .LT. (LXI + LYI1)) GO TO 2005
C  *** SELECTION  ON L - 1, L, L + 1
C ********  LOOP ON L **************************************
C
                  DO 2020 JL = 1,3
        IDL = JL - 2
        LI1 = LI + IDL
            IF (LI1 .LT. 0) GO TO 2020
             IF (LI1 .NE. LF) GO TO 2020
C ***  2020 - END OF LOOP
C
      W = racah(1.D0,1.D0*LYI,1.D0*LI1,1.D0*LXI,1.D0*LYI1,1.D0*LI)
        CF = (-1)**nint(1-jtotgs) * sqrt((2.*jtot+1.)*(2.*jtotgs+1.)) *
     x       racah(jtotgs,jtot,JNI+Z,JNF+Z,1d0,JCHE)
      if(TR1) WRITE(64,*) 'W,CF =',real(W),real(CF)
        W = W * CF
          IF(W .EQ. 0.D0) GO TO 2020

C   *** 2006 - CALC OF RADAL M.E.
C
	RSU = TRCHAN(IF,JI)
	RSU = RSU*PHASE
C
C  ******  CHOICE OF K-DEPENDED COEFFICIENTS
C
        IF((IDLY .EQ. -1) .AND. (IDKI .EQ. -1)) GO TO 2021
                  GO TO 2122
 2021      ALP = -DSQRT(LYI*(KI-LXI+LYI+1.D0)*(KI+LXI+LYI+2.D0)/
     *             (KI+1.D0)/(KI+2.D0))
                  GO TO 2007
C
 2122     CONTINUE
        IF((IDLY .EQ. -1) .AND. (IDKI .EQ. 1)) GO TO 2022
                  GO TO 2123
 2022      ALP = -DSQRT(LYI*(KI-LXI-LYI+2.D0)*(KI+LXI-LYI+3.D0)/
     *             (KI+3.D0)/(KI+2.D0))
                  GO TO 2007
C
 2123     CONTINUE
        IF((IDLY .EQ.  1) .AND. (IDKI .EQ. -1)) GO TO 2023
                  GO TO 2124
 2023      ALP = DSQRT((LYI+1.D0)*(KI-LXI-LYI)*(KI+LXI-LYI+1.D0)/
     *             (KI+1.D0)/(KI+2.D0))
                  GO TO 2007
C
 2124     CONTINUE
        IF((IDLY .EQ. 1) .AND. (IDKI .EQ. 1)) GO TO 2024
                  GO TO 2020
 2024      ALP = DSQRT((LYI+1.D0)*(KI-LXI+LYI+3.D0)*(KI+LXI+LYI+4.D0)/
     *             (KI+3.D0)/(KI+2.D0))
C
 2007   CONTINUE
c     WRITE(64,100) KI,LI,ISI,LXI,LYI,JNI,ICI,
c    *	KF,LF,ISF,LXF,LYF,IJNF,ICF,RSU,W,ALP,PHASE
c100  FORMAT(' <GS ',9I2,' |E1|',9I2,'>=',3G12.4,I2)
C  *** PARTIAL
	 hch = ALP*0.5D0*DSQRT(2*LI1 + 1.D0)
	
        RSUP = RSU*0.5D0*DSQRT(2*LI1 + 1.D0)*ALP*W * sqrt(AL1)
        SUMR = SUMR + RSUP*(-1)**(1+LI1+LI)
C
       if(TR1) write(64,33) EC,IF,JI,sqrt(AL1*W),rsu,hch,rsup,sumr
 33    format('BE:',f6.3,2i4,';',5f9.4)
 2020     CONTINUE
C             END DO
 2005     CONTINUE
 2004     CONTINUE
 2003     CONTINUE
 2002     CONTINUE
 2200     CONTINUE
CC
C   **** SUM OF B(E1) CALCUL   ********************************
C
          BEL = AJ * SUMR**2

C ***** FOR PRINT
C
        WRITE(NFI,378) EC,BEL
	call flush(NFI)
C   **** END OF B(E1) CALCUL   ********************************
C
           GO TO 5000
C-------------------------------------------------------------------------
C
C  *****   E2 CALCUL  ********
C
 3000   CONTINUE
         ALF = Z3*(A1 + A2)/ASUM/A3

           J  = IE
	   L  = IE
	   ISIG=0
C
	SUMR= 0.D0
C
C  **** LOOP ON LI=INIT QUANT. NUMBERS ****
C
      DO 3101  j1 = 1,imaxgs(ib)
       JI = imaxgs0(ib)+j1
       KI = kkgs(j1,ib)
        LI = lltotgs(j1,ib)
         SI = ssxgs(j1,ib); ISI = nint(SI)
          LXI = ll1gs(j1,ib)
           LYI = ll2gs(j1,ib)
             JNI = jabgs(j1,ib); IJNI = nint(JNI)
               ICI(:) = iigs(j1,:,ib)
	       JCLI= spin(ICI(3),ib)
	     
        if(TR) write(64,94) 'K,L,S,l1,l2,Jn,ii:',
     &              KI,LI,ISI,LXI,LYI,IJNI,ICI
94      format(a20,5i3)
C
C  **** LOOP ON HE=FIN QUANT. NUMBERS ****
C
      DO 3101  i1 = 1,imax(ib)
       IF = imax0(ib)+i1
       KF = kk(i1,ib)
        LF = lltot(i1,ib)
         SF = ssx(i1,ib); ISF = nint(SF)
          LXF = ll1(i1,ib)
           LYF = ll2(i1,ib)
             JNF = jab(i1,ib); IJNF = nint(JNF)
               ICF(:) = ii(i1,:,ib)
	       JCHE= spin(ICF(3),ib)

          if(TR) write(64,94) '-----prime>',
     &            KF,LF,ISF,LXF,LYF,IJNF,ICF

	PHASE = (-1)**nint(LI+ISI- jtotgs + LF+ISF-jtot)
C
	if(TR2) then
       WRITE(64,4646) LXF ,LYF ,LF,ISF,nint(jtot),KF
 4646  FORMAT(1X,'<  LXF1,LYF ,LF,ISF,jtot,KF =',6I3,' /')
       WRITE(64,4648) L,ISIG,J  
 4648  FORMAT(1X,'/  L  ,ISIG,J   =',3I3,' /')
       WRITE(64,4647) LXI ,LYI ,LI,ISI,nint(jtotgs),KI
 4647  FORMAT(1X,'/  LXI1,LYI2,LI,ISI,jtotgs,KI =',6I3,' >')
	endif

C ****  QUADRUPOLE SELECTION RULES  *************
C
      IF(ICI(1).NE. ICF(1)) GO TO 600
      IF(ICI(2).NE. ICF(2)) GO TO 600
      IF(ICI(3).NE. ICF(3)) GO TO 600
      IF(ISI.NE. ISF) GO TO 600
      IF(IABS(KI - KF).GT.2) GO TO 600
      IF(IABS(LYI - LYF).GT.2) GO TO 600
        IF(LXF  .NE. LXI )GO TO 600
C  *****


      CALL ANGSPI(S1,S2,LXF ,LYF ,LF,ISF,IJNF,L ,ISIG,J,
     *                  LXI ,LYI ,LI,ISI,JNI,AS)
        CF = (-1)**nint(2-jtotgs) * sqrt((2.*jtot+1.)*(2.*jtotgs+1.)) *
     x       racah(jtotgs,jtot,JNI+Z,IJNF+Z,2d0,JCHE)
        AS = AS * CF

      CALL HANGMEQ(KF,LXF,LYF,KI,LXI,LYI,HANG)

	if(TR2) WRITE(64,4649) JFK,IF,JI,AS,HANG
4649  FORMAT(1X,3I3,': AS,HANG=',2G12.3)

      IF(ABS(AS) .LT. 1.D-10) GO TO 600
C
	  RSU = TRCHAN(IF,JI)
	RSU = RSU*PHASE
       SUMR = SUMR + RSU * ALF * AS * HANG

       if(TR) then
	WRITE(64,5515) IF,JI,RSU,SUMR
 5515 FORMAT(3X,2I3,' E2,sum E2 =',4G12.4)
 9515 FORMAT(' *** CLUSTER  A=',F3.0,'  Z=',F3.0,' BE2 =',G12.4/)

c      WRITE(64,3120)KF,LF,LXF ,LYF ,RSU,KI,LI,LXI,LYI
c3120  FORMAT(' <ex:K,LL,L1,L2=',4I2,'/M=',G11.3,'/gs: ',4I2,'>')
      WRITE(64,3120)IF,KF,LF,LXF,LYF ,RSU,AS,HANG,
     x		KI,LI,LXI,LYI,SUMR
3120  FORMAT(' <ex:#,K,LL,L1,L2=',i3,4I2,'/M=',G11.3,2f8.3,
     x		'/gs: ',4I2,'> =',2g11.3)
	endif
600     continue
C                               CORE E2 contribution using Qmom(ib) and coreK(ib)
c                               QN must agree for all neutrons, not core:
	if(KI/=KF.or.LI/=LF.or.ISI/=ISF.or.LXI/=LXF) go to 3101
	if(IJNI/=IJNF.or.LYI/=lYF) go to 3101
	if(ICI(1)/=ICF(1).or.ICI(2)/=ICF(2).or.ICI(3)/=ICF(3)) go to 3101

        if(nint(JCLI+JCHE).lt.2 .or. abs(JCLI-JCHE).gt.2) go to 3101
        CORE = Qmom(ib) * sqrt(2.*JCLI+1.)
     x          * cleb6(JCLI,coreK(ib),2d0,0d0,JCHE,coreK(ib))
        AS = (-1)**nint(IJNF+2-jtotgs-JCHE) * sqrt((2.*jtotgs+1.))
     x    *  racah(jtotgs,jtot,JCLI,JCHE,2d0,IJNF+Z)
        E2core = AS*CORE

	RSU = TRWF(IF,JI)
        RSU = RSU*PHASE

       SUMR = SUMR + RSU * E2core
        if(TR) write(64,590) ' core  ',
     x                  AS,CORE,RSU,E2core*RSU
590     format(a20,5g10.3)

3101  CONTINUE

CC
C   **** B(E2) CALCUL   ********************************
C
          BEL =AJ*SUMR**2
C
C ***** FOR PRINT
C
        WRITE(NFI,378) EC,BEL
	call flush(NFI)
 378     FORMAT(1X,2F10.5)
C   **** END OF B(E2) CALCUL   ********************************

C
 4000   CONTINUE
 5000   RETURN
        END
C
      SUBROUTINE ANGSPI(S1,S2,L1H,L2H,LF,ISF,jtot,L ,ISIG,J,
     *                  L1L,L2L,LI,ISI,jtotgs,AS)
        IMPLICIT REAL*8(A-H,O-Z)
        real*8 jtot,jtotgs
C *********************************************************************
C       SPIN - ANGULAR MATRIX ELEMENT FOR DENSITY OPERATOR            *
C               < L,M, SIG,M(SIG)/J,M(J)>                             *
C             IT ACTS ON A SUBSYSTEM 2    (L1H = L1L)                 *
C          CASE OF NUCLON  S1 = S2 = 1/2      *
C *********************************************************************
C                                                                     *
            PI = 3.14159D0
 100     RMES =  DSQRT(6.D0)
        IF(ISIG .EQ. 0) RMES = DSQRT( 2.D0*S1 + 1.D0)
         RMEL =  DSQRT(  2* L2H+1.D0)
         RMEL =  DSQRT(  2* L2L+1.D0)*RMEL
         RMEL =  DSQRT(  2* L  +1.D0)*RMEL
C         WRITE(*,*)' ANGSPI '
C         WRITE(*,*)' ANG 1',L2H,L,L2L,'LH,L,LL'
C         WRITE(64,*)' ANG 1',L2H,L,L2L,'LH,L,LL'
       IF((L+L2L).LT.L2H.OR.(L+L2H).LT.L2L.OR.(L2H+L2L).LT.L)GO TO 1000
         WIG1 =                 WIG(2*L2H,2*L,2*L2L,0,0)
C         WRITE(64,*)' ANG 2'

          IF(WIG1 .EQ. 0.D0) GO TO 1000
C            WRITE(*,8)L2H,L,L2L,WIG1
    8    FORMAT('WIG: L2H,L,L2L=',3I3,G12.3/)
         RMEL =  (-1)**L2H*RMEL*WIG1/DSQRT(4.D0*PI)
 1002     CONTINUE
C
C   ****  NUCLEON CASE : S1 = S2 = 1/2     S1+S2 = 1
C
  311     IF(ISI.NE. ISF) GO TO 1000
         A = (-1)**nint(L1H - L2H + LF +L + jtot - jtotgs)*RMES*RMEL
         A = DSQRT( 2.D0*LF  + 1.D0) * A
         A = DSQRT( 2.D0*LI  + 1.D0) * A
         A = DSQRT( 2.D0*jtotgs  + 1.D0) * A
         A = A/DSQRT( 2.D0)
C         WRITE(64,*)' ANG 3',A
	 A0 = A

        A =
     *  racah(1.D0*L2H,1.D0*LF,1.D0*L2L,1.D0*LI,1.D0*L1L,1.D0*L)* A
C         WRITE(64,*)' ANG 4',A

        AS=
     *  racah(1.D0*ISF,1.D0*LI,jtot,1.D0*L,jtotgs,1.D0*LF)* A
C         WRITE(*,*)' ANG 5'
c        WRITE(64,10) WIG1,RMEL,A0,A,AS
10	format(' ANG 5',5g11.3)

             RETURN
C ***
 1000   AS= 0.D0
c       WRITE(64,*)' !!!!!!!  ANGSPI: SLECTION RULES !!!!!!!'
c       WRITE(64,*) ' WIG1,ISI,ISF=',WIG1,ISI,ISF
                END
C
C ************************************************************************
C
        SUBROUTINE HANGMEQ(K,L1,L2I,K1,L12,L22,HANG)
C
        IMPLICIT REAL*8(A-H,O-Z)
C######################################################################
C     Calcul. of hyperangle Mat. El-s for <f/cos(alpha)**2/i>
C             f = He, i = Li
C    *******************************************************************
C
C   *** EL - MAGN RO*COS(TETA)**2 M.E. ****
C
C ***  CALC OF <K L1 L2/RO**2*COS(TETA)**2/K1 L12 L22>    ****
C
	L2 = L2I
      IF( L1 .NE. L12) GO TO 8765
      IF( L2 .NE. L22) GO TO 9765
       IF(K .NE. K1) GO TO 8767
      IF( L1 .EQ.  L2) GO TO 8766
C
C  ****  LX .NE. LY CASE  ****
C
      AN = (K1-L1-L2)/2.D0
      C1 = (AN+L2+1.5D0)*(AN+L1+L2+2.D0)/(K+3)
      C2 =  AN*(AN+L1+.5D0)/(K+1)
      C1 =  (C1+C2)/(K + 2)
C
	HANG = C1

	RETURN
C
C __________________________________________________________
C   *** CASE KF=KI, LX=LY
C
 8766  C1 = 0.5D0
C
	HANG = C1

	RETURN
C
C
C _________________________________________________________
C  *** CASE ABS(KI - KF) = 2
C
 8767  CONTINUE
C  ***
      IF(IABS(K - K1) .NE. 2) GO TO 8765
	K11 = MAX0(K,K1)
      AN = (K11-L1-L2)/2.D0
      C1 = (AN+L2+0.5D0)*(AN+L1+L2+1.D0)/(K11+2)
      C1 =  AN*(AN+L1+.5D0)/ K11   * C1
      C1 =  DSQRT(C1)/(K11+1)
C
	HANG = C1

	RETURN
C
C _________________________________________________________
C  ****  LYI .NE. LYF CASE  ****
C
 9765 CONTINUE
C
	IF(L2 - L22) 1,8765,2

 2	L2 = L22
         KK = K
          KK1 = K1

	GO TO 10

 1	KK = K1
         KK1 = K

 10     IF (KK1 - KK) 4,5,6

C *****  K1 = K - 2
 4       AN = (KK1-L1-L2)/2.D0
C        WRITE(*,*)'m4 ',KK1,L1,L2
           C1 = (AN+L2+1.5D0)*(AN+L2+2.5D0)*(KK1+2)
      C1 = C1/((AN+L1+L2+3.D0)*(AN+L1+L2+2.D0)*(KK1+4))
	C1 = DSQRT(C1)
      C2 = (AN+L1+L2+2.D0)*(AN+L1+L2+3.D0)/((KK1+2.D0)*(KK1+3.D0))

      C1 =  C1*C2
C
	HANG = C1

	RETURN
C
C

C *****  K1 = K
 5       AN = (KK1-L1-L2)/2.D0
C         WRITE(*,*)'m5 ',KK1,L1,L2

      C1 = (AN+L2+1.5D0)*AN
      C1 = C1/((AN+L1+0.5D0)*(AN+L1+L2+2.D0))
	C1 = DSQRT(C1)
      C2 = 2.D0*(AN+L1+L2+2.D0)*(AN+L1+0.5D0)/((KK1+1.D0)*(KK1+3.D0))

      C1 =  C1*C2

C
	HANG = C1

	RETURN
C
C *****  K1 = K + 2
 6       AN = (KK1-L1-L2)/2.D0
C        WRITE(*,*)'m6 ',KK1,L1,L2,AN
        IF(DABS(AN-1.D0).LE. 1.D-10) GO TO 8765

      C1 = AN*DABS(AN - 1.D0)*(KK1+2)
C        WRITE(*,*)'C1',C1
      C1 = C1/((AN+L1+0.5D0)*(AN+L1-0.5D0)*KK1)
C        WRITE(*,*)'C1',C1
        C1 = DSQRT(C1)
      C2 = (AN+L1+0.5D0)*(AN+L1-0.5D0)/((KK1+2.D0)*(KK1+1.D0))

      C1 =  C1*C2
C
	HANG = C1

C        WRITE(*,*)'M6',HANG
	RETURN
C
C
 8765 CONTINUE
C
	HANG = 0.D0
        WRITE(*,*)'HANGMEQ: SELECTION RULES HANG=',HANG

C
C   **** END OF HYPERANGLE MAT. EL. CALCUL   ********************************
       RETURN
	END
