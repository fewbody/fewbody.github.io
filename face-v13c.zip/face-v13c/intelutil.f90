	subroutine memuse
        INTEGER*4 TOTAL_DOS_PAGES,TOTAL_EXTENDED_PAGES, &
             REMAINING_DOS_PAGES,REMAINING_EXTENDED_PAGES, &
             TOTAL_DISK_SWAP_PAGES,REMAINING_DISK_SWAP_PAGES, &
             TOTAL_PAGE_TURNS

!        CALL GET_MEMORY_INFO@(TOTAL_DOS_PAGES, &
!             TOTAL_EXTENDED_PAGES,REMAINING_DOS_PAGES, &
!             REMAINING_EXTENDED_PAGES,TOTAL_DISK_SWAP_PAGES, &
!             REMAINING_DISK_SWAP_PAGES,TOTAL_PAGE_TURNS)
!	write(6,10) &!REMAINING_DOS_PAGES, TOTAL_DOS_PAGES, &
!	  	REMAINING_EXTENDED_PAGES,TOTAL_EXTENDED_PAGES, &
!		REMAINING_DISK_SWAP_PAGES,TOTAL_DISK_SWAP_PAGES, &
!		TOTAL_PAGE_TURNS
!10	format(/'  Memory space remaining-'/   &
!	        '   Dos pages:        ',i6,'/',i6/   &
!	        '   Extended-mem pages',i6,'/',i6/   &
!                '   Disk swap pages   ',i6,'/',i6,',  Page turns:',i6)
!	write(6,20) TOTAL_EXTENDED_PAGES-REMAINING_EXTENDED_PAGES,TOTAL_EXTENDED_PAGES, &
!		TOTAL_DISK_SWAP_PAGES-REMAINING_DISK_SWAP_PAGES,TOTAL_DISK_SWAP_PAGES, &
!		TOTAL_PAGE_TURNS
!20	format(/'  Page use: Mem ',i6,'/',i6,', Disk ',i6,'/',i6,' io',i6)
	return
	end
	subroutine flush(i)
	end
	subroutine cpuuse
        real time,time0
	common/cpuuses/time0
! Intel/ifc
      	call cpu_time(time)
	write(10,1) time-time0
1	format(/'  User time =',f9.3)
	entry cpuuse0
	call cpu_time(time0)
	return
	end
	subroutine exit
	stop
	end
