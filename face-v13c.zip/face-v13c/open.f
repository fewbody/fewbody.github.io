	open(iwf,access='sequential',status='scratch',form='unformatted')
