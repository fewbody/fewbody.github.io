      SUBROUTINE EIGCC(PSI,ETAP,KAP2,SL2,THETA,pair,P,H2SM,BOX,ISC,
     #		       NREQ,MC,LVAL,IC1V,IC2V,SV,JV,NODES,NRANGE,
     #		       NP,H,M,USEVCC,VCC,NORMS,PCON,MAXC,EPS,IFAIL,POTL)
      IMPLICIT REAL*8(A-H,O-Z)
      PARAMETER(MAXEQ=20, MM2=2*MAXEQ, MM21 = MM2+1)
      REAL*8 PSI(NP,M),F(NP+1,M,M),K,KP,IHL1,SV(M),JTARG(5),JV,
     #       KAP2(M),ETAP(M),SL2(M,M),MAT(MM2,MM21),VCC(NP,M,M),
     x       NORMS(M),V(2),VV(NP,M,M,2)
      INTEGER LVAL(M),PCON,COUNT,BC,CCP,CC,NODES(M),IC1V(M),IC2V(M),pair
      REAL*8 CENT(MAXEQ),ZI(MAXEQ,MAXEQ),ZM(MAXEQ,MAXEQ),ZP(MAXEQ,MAXEQ)
     #     ,COUT(MAXEQ),COUTP(MAXEQ),COUPL(MAXEQ,MAXEQ)
      LOGICAL SING,BOX,VIRT,USEVCC,POTL
      COMPLEX*16 HLA,HLAP
      REAL*8 FACT(101)
C
	if(PCON>4) then
      write(6,*) 'Eigcc1:',ETAP,KAP2,SL2,THETA,pair,P,H2SM,BOX,ISC
      write(6,*) 'Eigcc2:',NREQ,MC,LVAL,IC1V,IC2V,SV,JV
      write(6,*) 'Eigcc3:',NRANGE,NP,H,M,PCON,MAXC,EPS,IFAIL
      	endif

      COUNT = 1
      CCP = 1
      BC = 0
      PP=P
      N = NP-1
      RN = (NP-1)*H
      HP = H*H
      R12= 1./12.
      HP12=HP/12.
      NR = 2*M+1
      IFAIL = 0
      DETEPS = 1D-50
      VIRT = .false.
      iit = 0
      FACT(1) = 0.0
      DO 5 I=1,100
       C = I
5      FACT(I+1) = FACT(I) + LOG(C)
      IF(NR.GT.MM21.OR.M.GT.MAXEQ) GO TO 225
      IF(PCON.GE.3) WRITE(6,207) NREQ,(NRANGE-1)*H,MC
  207 FORMAT(/'    Parameters      Mismatch    Nodes  ->',I3,
     x ' inside',f6.2,' fm in ch.',I3/)
        do 600 L=1,M
        do 600 J=1,M
	if(PCON>2) write(402,*)'# L,J =',L,J
        do 600 I=1,NP
        R = (I-1)*H
        call POT(V,R,LVAL(L),LVAL(J),IC1V(L),IC1V(J),IC2V(L),IC2V(J),
     X 		    SV(L),SV(J),JV,SL2(L,J),L,J,pair)
	if(PCON>2) then
      if(mod(I-1,20)==0) write(402,599) R,V,vc(0,R,pair)+vcoul(R,pair)
599      format(f8.3,2f12.5,4x,3f10.4)
	endif
600       VV(I,L,J,:) = V(:)
      if(POTL) then
         VCC(:,:,:) = VV(:,:,:,1)+VV(:,:,:,2)
	 return
	 endif
	
102   DO 21 J=1,M
C
C ***  Determine asymptotic energies and Whittaker functions
C
	LT = LVAL(J)
      CENT(J) = LT * (LT+1)
      KP = KAP2(J) + THETA*P
      K = SQRT(ABS(KP))
      ETA  = 0.5*ETAP(J)/K

      B=RN+H
      C=RN
      PIB=K*B
      PIC=K*C
      IF(BOX) THEN
C                 Use box limits
         COUTP(J) = 0.0
         COUT(J) = 1E-10
      ELSE IF(KP.gt.0) THEN
C                 Use decaying Whittaker function
        COUTP(J)=EXP(-LOG(B)*ETA)*IHL1(LT,PIB)*PIB
        COUT(J)=EXP(-LOG(C)*ETA)*IHL1(LT,PIC)*PIC
c       CALL WHIT(ETA,RN+H,K,E,LT+1,CFP,CFD)
cc       CALL WHIT(ETA,RN  ,K,E,LT+1,CF,CFD)
c          IF(COUNT.EQ.1 .AND. PCON.GE.5)
c     #    WRITE(6,*) 'ASY:',J,LT,COUT(J),CF(LT+1),COUTP(J),CFP(LT+1)
c          IF(COUNT.EQ.1 .AND. PCON.GE.5)
c     #    WRITE(6,*) 'ASY-R:',COUTP(J)/COUT(J),CFP(LT+1)/CF(LT+1)
c       COUTP(J) = CFP(LT+1)
c       COUT(J) = CF(LT+1)
      ELSE
C                 Use scattering asymptotics for S=-1:  Y == G.
        CALL HANKEL(PIB,LT,HLAP)
        CALL HANKEL(PIC,LT,HLA)
	if(LT.gt.0.or.abs(ETA).gt.1e-5) then
          COUTP(J) = REAL(HLAP)
          COUT(J) = REAL(HLA)
	else
C		neutral s-waves: try to find E for delta=pi/4: S=i, Y=G+F
          COUTP(J) = REAL(HLAP) + AIMAG(HLAP)
          COUT(J) = REAL(HLA) + AIMAG(HLA)
	  VIRT = .true.
	endif
      ENDIF
21    CONTINUE
	PMUL = P
	IF(ISC.eq.2) PMUL = 1.0

c------------------------------------------TEST
 	 
      I   = NP + 1
         IMAX = NP/2
         DEL = -1E20
22    I=I-1
C
C ***  Determine mid-point for matching integrations,
C      near classical turning point in channel MC.
C
      UDIAG = -KAP2(MC) - THETA*P
	if(UDIAG.gt.0) then
	   MAM = NP/4
	   GO TO 24
	   endif
	R = (I-1)*H
      if(USEVCC) then
      UDIAG = UDIAG -VCC(I,MC,MC)/H2SM
      else
      UDIAG = UDIAG - (VV(I,MC,MC,1)*PMUL+VV(I,MC,MC,2))/H2SM
!       POT(R,LVAL(MC),LVAL(MC),
!    X               IC1V(MC),IC1V(MC),IC2V(MC),IC2V(MC),
!    X 		    SV(MC),SV(MC),JV,PMUL,SL2(MC,MC),MC,MC,pair)/H2SM
      endif

      DEN = -CENT(MC)/(R)**2 + UDIAG
         IF(DEL.LT.DEN) THEN
            DEL = DEN
            IMAX = I
            ENDIF
      IF(DEN.LT.0 .AND. I.GT.10) GO TO 22
      MAM = I
      IF(I.EQ.10) MAM = IMAX
      MAM = min(MAM,NP-7)
      if(Pcon>4)write(6,*) 'Matching point at ',MAM,' Theta,K =',theta,k
24      MAP = MAM+1
      IF(COUNT.EQ.1 .AND. PCON.GE.5)
     #WRITE(6,*) MC,LVAL(MC),K,ETA,RN+H,COUTP(MC),RN,COUT(MC),MAM,MAP
     #             ,CENT(MC)
103   DO 30 J=1,M
      DO 25 IT=1,M
      ZM(IT,J) = 0.0
25    ZI(IT,J) = 0.0
      ZM(J,J) = COUTP(J)
30    ZI(J,J) = COUT(J)
	PMUL = P
	IF(ISC.eq.2) PMUL = 1.0
C
C      outer integration,  zi from np to map
      NT = -1
      NF = NP
      NO = NT * (MAP-NP) + 1
40    DO 60 III=1,NO
         I = NF + (III-1)*NT
         II= (I + MIN0(NT,0)) + 1
         RRI= 1.0/(II-1.)**2
	 R = (II-1)*H
      DO 42 IT=1,M
      DO 42 J=1,M
42    F(I,J,IT) = ZI(IT,J) * (1. + CENT(J)*RRI*R12 )
       DO 45 J=1,M
       DO 45 L=1,M
        if(USEVCC) then
        C = -VCC(II,L,J)/H2SM
        else
        C = - (VV(II,L,J,1)*PMUL+VV(II,L,J,2))/H2SM
!       C = -POT(R,LVAL(L),LVAL(J),
!    X              IC1V(L),IC1V(J),IC2V(L),IC2V(J),
!    X 		    SV(L),SV(J),JV,PMUL,SL2(L,J),L,J,pair)/H2SM
        endif
         IF(L.EQ.J) C = C - KAP2(J) - THETA * P
       COUPL(L,J) = C
       IF(C.EQ.0) GO TO 44
       C = C * HP12
          DO 43 IT=1,M
43         F(I,L,IT) = F(I,L,IT) - C * ZI(IT,J)
44    CONTINUE
45    CONTINUE
      DO 49 IT=1,M
         DO 49 L=1,M
49       MAT(IT,L) = 0.0
      DO 54 L=1,M
      DO 54 J=1,M
      C = COUPL(L,J)
      IF(C.EQ.0.0) GO TO 54
      C = C * HP
      DO 53 IT=1,M
53    MAT(IT,L) = MAT(IT,L) + C * F(I,J,IT)
54    CONTINUE
      DO 55 J=1,M
      DO 55 IT=1,M
      ZP(IT,J) = 2*ZI(IT,J) - ZM(IT,J) - MAT(IT,J)
     #                      + F(I,J,IT) * CENT(J) * RRI
      ZM(IT,J) = ZI(IT,J)
55    ZI(IT,J) = ZP(IT,J)
C                              now check for incipient overflows:
      DO 59 IT=1,M
      C = 0.
      DO 57 J=1,M
57    C = MAX(C,ABS(F(I,J,IT)))
      IF(C .LT. 1d40) GO TO 59
      C = 1d-20
      DO 58 J=1,M
         ZI(IT,J) = ZI(IT,J) * C
         ZM(IT,J) = ZM(IT,J) * C
         DO 58 L=1,III
            I = NF + (L-1)*NT
58       F(I,J,IT) = F(I,J,IT) * C
59    CONTINUE
60    CONTINUE
C
      NT = -NT
      IF(NT.LE.0) GO TO 3
      DO 65 J=1,M
      DO 64 IT=1,M
      ZM(IT,J) = 0.0
64    ZI(IT,J) = 0.0
65    ZI(J,J) = 1e-10 * H**(LVAL(J)+1) / EXP(0.5 * FACT(LVAL(J)+1))
c	write(50,*) ' Start at origin with ',real(ZI(MC,MC))
C      inner integration,  zi from 1 to mam
      NF = 1
      NO = NT * (MAM-1) + 1
      GO TO 40
3     COUNT = COUNT + 1
C   now calc. derivatives at matching pt. inner(zm) & outer(zp)
      DO 80 J=1,M
         MAT(J,NR) = 0.0
         MAT(J+M,NR) = 0.0
      DO 75 IT=1,M
      DEL =147.0*F(MAM,J,IT)-360.0*F(MAM-1,J,IT)+450.0*F(MAM-2,J,IT)
     1 -400.0*F(MAM-3,J,IT)+225.0*F(MAM-4,J,IT)
     2 -72*F(MAM-5,J,IT)+10.0*F(MAM-6,J,IT)
      ZM(IT,J) = 1  * DEL / (60.0 * H)
      DEL =147.0*F(MAP,J,IT)-360.0*F(MAP+1,J,IT)+450.0*F(MAP+2,J,IT)
     1 -400.0*F(MAP+3,J,IT)+225.0*F(MAP+4,J,IT)
     2 -72*F(MAP+5,J,IT)+10.0*F(MAP+6,J,IT)
      ZP(IT,J) =(-1)* DEL / (60.0 * H)
c      WRITE(50,*) 'INT:',j,it,zm(it,j)/f(mam,j,it),zp(it,j)/f(map,j,it)
      MAT(J,IT) = F(MAM,J,IT)
      MAT(J,IT+M) = -F(MAP,J,IT)
      MAT(J+M,IT) = ZM(IT,J)
75    MAT(J+M,IT+M) = - ZP(IT,J)
80    CONTINUE
      DO 78 IT=1,MM2
78    MAT(M+MC,IT) = 0.0
      MAT(M+MC,M+MC) = 1.0
      MAT(M+MC,NR)  = 1.0
!      do 81 j=2,nr
!      write(4,'(i3,1p,10e12.4)') (j-1),(mat(j-1,it),it=1,nr)
!81    continue
       CALL GAUSSR(2*M,1,MM2,MAT,SING,DET,DETEPS,.FALSE.)
       IF(SING) GO TO 200
       DO 88 L=1,M
          DO 85 I=1,NP
85        PSI(I,L) = 0.0
       DO 88 IT=1,M
       DO 87 I=2,MAM
87     PSI(I,L) = PSI(I,L) + F(I-1,L,IT) * MAT(IT,NR)
       DO 88 I=MAP,NP
88     PSI(I,L) = PSI(I,L) + F(I,L,IT) * MAT(IT+M,NR)
C
C ***  Find inside derivative (DERIN) & outside derivative (DEROUT) for
C      channel MC, their difference to be used to correct eigenvalue P.
C
       DERIN = 0.0
       DEROUT= 0.0
       DO 90 IT=1,M
       DERIN = DERIN + ZM(IT,MC) * MAT(IT,NR)
       DEROUT= DEROUT+ ZP(IT,MC) * MAT(IT+M,NR)
90     CONTINUE
C
C ***   Count number of radial nodes in channels (Require NODES(MC)=NREQ).
C
       DO 91 J=1,M
       NODES(J) = 1
       DO 91 I=3,NRANGE
91     IF(PSI(I,J)*PSI(I-1,J).LT.0.) NODES(J) = NODES(J) + 1
       DEN = 0.0
       DO  96 J=1,M
       DO  96 L=1,M

c         DO 94 JF=1,NFM
c         T = CCOEF(J,L,JF,2)
c         IF(ABS(T).LT.1E-30) GO TO 94
c            DO 92 IMAX=NP,1,-1
c92          IF(ABS(FORMF(IMAX,JF)).GT.1E-20) GO TO 925
c925         DO  93 I=2,IMAX
c93          DEN = DEN + PSI(I,J) * T * FORMF(I,JF) * PSI(I,L)
c94       CONTINUE
         IF(ISC.eq.1) then
	  DO  93 I=2,NP
	    T =  0.0
	    R = (I-1)*H
	    if(J.eq.L) then
              if(USEVCC) then
              T = -VCC(I,L,J)/H2SM
              else
              T = - (VV(I,L,J,1)*PMUL+VV(II,L,J,2))/H2SM
!	      T = -POT(R,LVAL(L),LVAL(J),
!    X                           IC1V(L),IC1V(J),IC2V(L),IC2V(J),
!    X 		          SV(L),SV(J),JV,PMUL,SL2(L,J),-1,-1,pair)/H2SM
              endif
              endif
93          DEN = DEN + PSI(I,J) * T  * PSI(I,L)
	 ELSE IF(J.EQ.L) THEN
            DO 95 I=2,NP
95          DEN = DEN - PSI(I,J) * THETA * PSI(I,L)
	 ENDIF
96    CONTINUE
       DEL =(DEROUT - DERIN) / PSI(MAP,MC)
c	write(50,*) '# #,DEL,PSI,DEN =',COUNT,DEL,PSI(MAP,MC),DEN
c      IF(PCON.GE.3) WRITE(6,217) P,DEL,NODES(MC)
c	if(PCON.ge.5)write(6,*) '# #,DERIN,DEROUT,PSI,DEN =',
c    x				COUNT,DERIN,DEROUT,PSI(MAP,MC),DEN
C 217    format(e14.6,e15.3,i6)
c 217    FORMAT(1X,F13.6,F15.8,I6)
	NCO=NODES(MC)
       IF(PCON.GE.3)WRITE(6,217)P,DEL,NCO,mam ,DERIN,DEROUT,
     x				PSI(MAP,MC),DEN,iit
  217    FORMAT(1X,F13.6,F15.8,I3,i5,4f9.5,i5)
c      IF(COUNT.GT.MAXC) GO TO 210
       IF(COUNT.GT.MAXC) GO TO 7
       IF(NODES(MC).NE.NREQ) GO TO 6
       IF(ABS(DEL).LT.EPS) GO TO 7
         IF(DEN.EQ.0.0) GO TO 220
       Q =-DEL * PSI(MAP,MC)**2 / (DEN * H)
c      IF(P.LT.-Q) Q = -0.5*P
c      P = P+Q
	iit = 0
   50 P1 = P+Q
	iit = iit+1
       IF(ABS(P1).gt.2.*ABS(P) .or. ABS(P1).lt.0.5*ABS(P)
     X     .or. P1*P.lt.0.) THEN
         Q=0.5*Q
         GO TO 50
         ENDIF
c     IF(VIRT) Q = 4.0*Q
       P = P+Q
       BC = 1
       Q = 2*Q
99     IF(ISC.eq.2) GO TO 102
       GO TO 103
6     IF(BC.NE.0) GO TO 61
      CC = 1
      IF(NREQ.LT.NODES(MC)) CC = -1
      IF(DEN.LT.0.0) CC = -CC
      IF(CC.LT.0) CCP = -IABS(CCP)
      IF(CCP.GT.0) PP = P
      IF(CCP.LT.0) PP = 0.5*PP
      P = PP*CC + P
      GO TO 99
61    Q = 0.5*Q
      P = P - 0.5*Q
      GO TO 99
7     Q = 0.0
      DO 700 J=1,M
      DO 700 I=1,NP
700   Q = Q + PSI(I,J)**2
	if(Q==0d0) go to 210
         PIC = 1.0
      Q = SIGN(PIC,PSI(3,MC)) / SQRT(Q * H)
C
C ***  Rescale output PSI to unity, such that channel MC is positive
C         for small radii.
C

        NORMS(:) = 0.
      DO 710 I=2,NP
	    R = (I-1)*H
	T = Q / R
      DO 710 J=1,M
      PSI(I,J) = PSI(I,J) * T
710   NORMS(J) = NORMS(J) + (R*PSI(I,J))**2 * H
      DO 711 J=1,M
711   if(LVAL(J).eq.0) PSI(1,J) = 2*PSI(2,J) - PSI(3,J)

      if(.not.USEVCC) VCC(:,:,:) = VV(:,:,:,1)*PMUL+VV(:,:,:,2)

       IF(COUNT.GT.MAXC) GO TO 210
       
      IF(PCON.EQ.0) RETURN
        do J=1,M
       	write(121,994) J,LVAL(J),P
  994	format('# Bound state #,L =',2i3,' at ',f10.5)
	do I=1,NP
	write(121,*) (I-1)*real(H),PSI(I,J)
	enddo
	write(121,*) '&'
	call flush(121)
	enddo

      IF(MOD(PCON,2).EQ.0)      RETURN
      DO 996 J=1,M
      WRITE(6,992) J,LVAL(J)
  992 FORMAT(/' For channel #',I3,' with L =',I2//,'   N    Y(R)')
      WRITE(6,993)(I,PSI(I,J),I=1,NP,5)
  993 FORMAT(6(I4,2X,1P,E11.4,3X))
  996 continue
      RETURN
200   IFAIL = 1
      PRINT 202,DET
202   FORMAT(' ***** FAIL IN EIGCC : DETERMINANT =',1P,2E12.4)
      RETURN
210   IFAIL = 2
!      PRINT 212,DEL,MAXC
212   FORMAT(/' ***** FAIL IN EIGCC : DISCREPANCY =',1P,E12.4,
     #       ' EVEN AFTER',I3,' ITERATIONS')
      RETURN
220   IFAIL = 3
!     PRINT *,' ***** FAIL IN EIGCC : NO VARIABLE PART FOUND !!!!!'
      RETURN
225   IFAIL = -1
      PRINT *,' ***** FAIL IN EIGCC : INVALID INPUT PARAMETERS !!'
      RETURN
      END
      SUBROUTINE GAUSSR(N,M,NR,A,SING,DET,EPS,SHOW)
C
C    solve by Gaussian elimination sum(j): A(i,j).P(j,k) = A(i,N+k)
C             where P(j,k) is left in A(j,N+k)   i,j=1,N, k=1,M
C
       IMPLICIT DOUBLE PRECISION(A-H,O-Z)
       DOUBLE PRECISION A(NR,100),DET,RA
       LOGICAL SING,SHOW
      PARAMETER(KO=10)
       SING  = .FALSE.
      NPM = N + M
c      WRITE(50,*) 'GAUSSR:'
c      DO 201 I=1,N
c201   WRITE(50,402) (            A(I,J)  ,J=1,NPM)
      DET = 1
      DO 9 K = 1, N
      if(SHOW) DET = DET * A(K,K)
      IF (ABS (A(K,K)) .GT. EPS ) GO TO 5
         SING = .TRUE.
         WRITE(KO,3) K,DET
    3    FORMAT(//' THE MATRIX IS SINGULAR AT',I3,'  determinant is ',
     #  E16.8/)
      DO 401 I=1,N
401   IF(SHOW) WRITE(KO,402) (            A(I,J)  ,J=1,NPM)
C402   FORMAT( 1X,20F6.3/(1X,20F6.3))
402   FORMAT( 1X,11G11.2/(11X,10G11.2))
         RETURN
    5 KP1 = K + 1
         RA = 1.0/A(K,K)
      DO 6 J = KP1, NPM
    6 A(K,J) = A(K,J) * RA
      A(K,K) = 1
      DO 9 I = 1, N
      IF (I .EQ. K  .OR. ABS (A(I,K)) .EQ. 0) GO TO 9
         DO 8 J = KP1, NPM
    8    A(I,J) = A(I,J) - A(I,K)*A(K,J)
         A(I,K) = 0
    9 CONTINUE
      IF(SHOW) WRITE(KO,15 ) DET
c      WRITE(4,15 ) DET
15    FORMAT(/' The determinant is ',E16.8)
      RETURN
      END
C     SUBROUTINE WHIT(HETA,R,XK,E,LL,F,FD,IE)
      SUBROUTINE WHIT(HETA,R,XK,E,LL,F,FD)
C
C     CALCULATES  WHITTAKER  FUNCTION  WL(K,R)  WITH
C     ASYMPTOTIC  FORM  EXP(-(KR + ETA(LOG(2KR)))
C     E  IS  NEGATIVE
C     If IE = 0, allowed to return result E**IE larger than Whittaker,
C                for the IE value returned.
C     If IE > 0, must scale results by that amount.
C
      IMPLICIT DOUBLE PRECISION(A-H,O-Z)
      DIMENSION F(100),FD(100) ,T(12),S(7)
      PARAMETER(FPMAX=1d100)
      L = LL+1
C              NOW L = NO. OF VALUES TO FIND
      EE=-1.0
      AK=XK
      ETA=HETA
      LP1=L+1
      RHO=AK*R
      IF(L-50)1,1,2
    1 LM=60
      GO TO 3
    2 LM=L+10
    3 IS=7
      PJE=10.0*RHO+1.0
      H=INT(PJE)
      H=RHO/H
      RHOA=10.0*(ETA+1.0)
      IF(RHOA-RHO)13,13,14
   13 IFEQL=1
      RHOA=RHO
      GO TO 15
   14 IFEQL=0
   15 PJE=RHOA/H+0.5
      RHOA=H*INT(PJE)
      IF(IFEQL)16,16,18
   16 IF(RHOA-RHO-1.5*H)17,18,18
   17 RHOA=RHO+2.0*H
   18 IF(EE)55,55,19
   19 STOP 'WHIT'
   27 A=2.0-10.0/12.0*H*H*EE
      B=1.0/6.0*H*ETA
      C=1.0+1.0/12.0*H*H*EE
      M1=INT(RHOA/H-0.5)
      M2=INT(RHO/H-1.5)
      T(2)=B/FLOAT(M1+1)
      T(3)=B/FLOAT(M1)
      JS=M1
      DO 29 IS=M2,M1
      DO 28 I=1,6
      S(I)=S(I+1)
   28 CONTINUE
      T(1)=T(2)
      T(2)=T(3)
      T(3)=B/FLOAT(JS-1)
      S(7)=((A+10.0*T(2))*S(6)-(C-T(1))*S(5))/(C-T(3))
      JS=JS-1
   29 CONTINUE
      T(1)=S(4)
      T(2)=(1.0/60.0*(S(1)-S(7))+0.15*(S(6)-S(2))+0.75*(S(3)-S(5)))/H
      GO TO 60
   55 C=1.0/RHOA
      A=1.0
      B=1.0-C*ETA
      F(1)=A
      FD(1)=B
      DO 56 M=1,26
      D=0.5*(ETA+FLOAT(M-1))*(ETA+FLOAT(M))*C/FLOAT(M)
      A=-A*D
      B=-B*D-A*C
      F(1)=F(1)+A
      FD(1)=FD(1)+B
   56 CONTINUE
      A=-ETA*LOG(2.0*RHOA)-RHOA
      FPMINL = -LOG(FPMAX)
      if(IE.eq.0.and.A.LT.FPMINL) IE = INT(FPMINL-A)
      A=EXP(A+IE)
      F(1)=A*F(1)
      FD(1)=A*FD(1)
      IF(IFEQL)57,57,61
   57 S(IS)=F(1)
      IF(IS-7)27,58,27
   58 IS=6
      RHOA=RHOA+H
      GO TO 55
   60 F(1)=T(1)
      FD(1)=T(2)
   61 C=1.0/RHO
      IF(L)64,64,62
   62 DO 63 M=1,L
      A=ETA/FLOAT(M)
      B=A+C*FLOAT(M)
      F(M+1)=(B*F(M)-FD(M))/(A+1.0)
      FD(M+1)=(A-1.0)*F(M)-B*F(M+1)
   63 CONTINUE
   64 DO 65 M=1,L
      FD(M)=AK*FD(M)
   65 CONTINUE
      RETURN
      END
