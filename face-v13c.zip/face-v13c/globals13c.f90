	module parameters
 	parameter(mstates=3, mjtp=4,mmultipole=4,mfchan=3,mocc=30,maxl=10,mbs=10)
	end module parameters
!-------------------------------------------------  Physics variables
	module physics
	use parameters
	implicit real*8 (a-h,o-z)   
	real*8 iso,Mmom,jtmax,mass
	parameter (coulcn = 1.4398523d0 )
	character*3 typc(3),typso(3),typss(3),typt(3),typ3b
	character*80 desc,detail(3)
	character*8 nfile*20,name(3),potfile*20
	character sym(0:3),rwpot
	logical auto(3),id(3),gtvary,volcon(3),subst_pl(0:3,3),def_pa
	integer ngt,gparity,parity,qmax(3),qmaxb(3),kmax, lpot(3)
	integer n2states,kmaxf(mstates),kmaxeff(mstates),ndrop(mjtp)
	dimension z(3),radius(3),mass(3),iso(3),gtot(mjtp),gparity(mjtp),meigs(mjtp)
	dimension spin(mstates,3),parity(mstates,3),energy(mstates,3),ns(3)
	dimension def(2:mmultipole,3),rcoul(3),acoul(3)
	dimension nc(3),lx(mfchan,3),ly(mfchan,3),lt(mfchan,3),sx(mfchan,3),  &
     &		icx1(mfchan,3),icx2(mfchan,3),icy(mfchan,3),jp(mfchan,3),np(mfchan,3),  &
     &		kmaxa(3),kmax(0:maxl,3),lxmax(3),lymax(3),ltmax(3),sxmax(3),jabmax(3),jabm(3)
	dimension corek(3),Qmom(3),Mmom(3)
	dimension pa(6,3),ps(6,3),pp(6,3),pd(6,3),pf(6,3)
	dimension pso(6,3),psop(6,3),psod(6,3),psof(6,3)
	dimension pss(6,3),psss(6,3),pssp(6,3),pssd(6,3),pssf(6,3)
	dimension pt(6,3)
	dimension s3b(mjtp),r3b(mjtp),a3b(mjtp)
	dimension gamso1(3),gamso2(3)
	real*8 amc,hc,etacns,jp,jabmax,efesh,shift,jabm
	data gtot/mjtp*0.d0/, gparity/mjtp*0.d0/
	integer pairs(3,3)
	data pairs(:,1)/2,3,1/, pairs(:,2)/3,1,2/, pairs(:,3)/1,2,3/	
	character psign(3)
      	data psign / '-',' ','+' /
	end module physics

!-------------------------------------------------  Two body  eigenstates
	module twobody_states
	use parameters
	parameter (momit=1)
	logical forb(3)
	type specifics
	 integer pair,s_kind,n,nvchan,l,lmax
	 real*8 s,jv,rnode,fermi
	 integer isc,nomit,omit_l(momit),omit_c1(momit),omit_c2(momit)
	 real*8 omit_s(momit),omit_j(momit)
	 real*8 eigen,potential,de
	 logical rescale,test
	 integer nk,ipc
	end type specifics

	type state
	 type(specifics):: inf
	 integer,pointer:: lv(:),ic1v(:),ic2v(:)
	 real*8,pointer:: sv(:)
	 integer nch,par
	 real*8,pointer:: ybs(:,:),vccx(:,:,:)
	end type state

	type(state) ::  twbod(mocc)
	end module twobody_states

!-------------------------------------------------  Numerical potentials
	module potentials
	integer npoints(3),lset(3)
	real*8 rstep(3),rfirst(3)
 	real*8,allocatable:: potls(:,:,:)
	logical readin(3),loop(3)

	end module potentials
!-------------------------------------------------  Method variables
	module methodspec
	use parameters
 	parameter(npmax=100)
	integer nlag,njac,nplag
	real*8 rr,rinner,rscreen,ascreen
	logical potparts,vertex,pripot,vadia,docont,cfiles,bel
	character eqn
	integer ipc,lvmax,nocc,init
        logical reduced
	real*8  emin,emax,dec,eimin,eimax,eig,sigma
	real*8  dx,xmax,dy,ymax,rnode,kapp,dxf
	integer nbmax,meig,nx,ny
	end module methodspec

!-------------------------------------------------  Array and global work variables
	module work
	real*8 h2sm,masstot
	integer imax(3),imax0(3),imaxx,imaxs,imaxr,imaxe,imaxh,jmax,jjmax
 	integer,allocatable:: kk(:,:),ll1(:,:),ll2(:,:),lltot(:,:),ii(:,:,:),iba(:)
 	integer,allocatable:: kkh(:),iih(:,:),ibh(:),ifo(:,:),ieo(:,:)
 	real*8,allocatable:: ssx(:,:),jab(:,:)
       	real*8,allocatable:: xj(:),wj(:),  xl(:),wl(:), xlag(:)

 	real*8,allocatable:: aspl(:,:),bspl(:,:)	
	real*8 jtot
	integer ijt,jparity,nsrc,iwf,inf
	integer l1max,l2max,nmax,mchan
	logical fesh,effp,effd

 	real*8,allocatable:: pj(:,:,:,:),ww(:,:),wn1(:,:),ctn(:,:),dtn(:,:),wfn(:,:)
 	integer,allocatable:: mp12(:)
	end module work

!-------------------------------------------------  Array and global work variables
	module factorials
	parameter (maxfac=200)
	real*8 pi
	data pi/3.1415926535897932384626433832795d0  /
	real*8  dlfac(0:maxfac),dl2fac(0:maxfac)
	end module factorials

	module groundstate
	real*8 jtotgs,egs
	real*8,allocatable:: pvecgs(:)
	integer jparitygs,imaxgs(3),imaxgs0(3),imaxsgs
 	integer,allocatable:: kkgs(:,:),ll1gs(:,:),ll2gs(:,:), &
		lltotgs(:,:),iigs(:,:,:),ibags(:)
 	real*8,allocatable:: ssxgs(:,:),jabgs(:,:)
	end module groundstate
