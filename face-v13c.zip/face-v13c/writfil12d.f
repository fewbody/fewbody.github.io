	subroutine writefiles
	use physics
	use methodspec
	use work
	implicit real*8(a-h,o-z)
	parameter(ipmax=5,ncoup=4,lxtra=9)
	character*3 qnum(lxtra+1)
	real*8 cf(ipmax)
	real*8 wwl(imaxh,imaxh,nlag)
	character*40 fmel,fspec,focc
	integer io(imaxs,2),i,cupord(3,ncoup),mult(lxtra+1),fc(3)
	data qnum / '  K','  L',' Sx',' lx',' ly',' jp',
     X		    ' Iy',' Ix',' Iz',' JT'/
	data mult / 1,1,2,1,1,2,2,2,2,2 /, jgt / 10/
	data cupord / 4,5,2, 8,9,3, 2,3,6, 6,7,10 /
	data fc(2)/1/, fc(3)/2/, fc(1)/3/
	logical ytorder,details,symm
!---------------------------------- give files for sturm diagonalisation:

       if(ijt.eq.1) then
!---------------------------------- open files 
       fmel =trim(nfile)//'.mel'
       fspec=trim(nfile)//'.spec'
       focc =trim(nfile)//'.occ'
       write(6,*)  '  writing files: ',
     x        trim(fmel),', ',trim(fspec),', ',trim(focc)
       write(10,*)  '  writing files: ',
     x        trim(fmel),', ',trim(fspec),', ',trim(focc)
            open (40,file = fmel,access = 'sequential',
     x         form='unformatted',status = 'unknown')
            open (41,file =fspec,access = 'sequential',
     x         form='formatted',status = 'unknown',delim='apostrophe')
            open (15,file =focc,access = 'sequential',
     x         form='unformatted',status = 'unknown')
       endif
!				write out channels in order io(i,1),i=1,imax
!				io(*,2) is reverse mapping
	ytorder = .true.
	ytorder = .false.
	 if(ytorder.or.eqn.eq.'Y'.or.eqn.eq.'N') then
	   do 100 i=1,imaxs
	   io(i,1) = i
100	   io(i,2) = i
	 else
	   do 101 i=1,imax(3)
	   io(i,1) = imax(2)+i
101	   io(imax(2)+i,2) = i
	   do 1011 i=1,imax(2)
	   io(imax(3)+i,1) = i
1011	   io(i,2) = i+imax(3)
	   do 1012 i=1,imax(1)
	   io(imax(2)+imax(3)+i,1) = i
1012	   io(i,2) = i+imax(2)+imax(3)
	 endif
!
!---------------------------------- calculate forbidden states in hh basis:
!	if(ny.gt.0) call ppx

!	if(eqn.ne.'F') call redchs

!---------------------------------- write files 

       if(ijt.eq.1) then
	scent=1.5d0
	mfad = 3
	if(eqn.eq.'T') mfad = 1
	details = .true.
	symm = mfad==1
	write(41,'(a80)')   desc
	write(41,*) real(h2sm),real(coulcn)
	write(41,102) rr,rr,nlag,rr,rr,nplag,rinner
102	format(2f8.4,i5,2f8.4,i5,f10.5)
	write(41,*) 3,real(scent),lxtra,ncoup,ipmax,mfad,symm,details,
     X			1,mstates,0
	write(41,'(30a3)') qnum(1:lxtra+1)
	write(41,'(30i3)') mult(1:lxtra+1),jgt
	if(ncoup>0) write(41,'(20i3)') ((cupord(i,j),i=1,3),j=1,ncoup)
	if(details) then
	  write(41,104) mass,z,radius
104	  format(3f10.4,3f6.1,3f8.4)
	  do ib=1,3
	    write(41,1045) name(ib),ns(ib),corek(ib),Qmom(ib),
     X          Mmom(ib),(energy(i,ib),parity(i,ib),i=1,ns(ib))
1045      format(a8,i3,f4.1,2f10.4,10(f8.4,i4))
	  enddo
	  write(41,1046) (id(i),iso(i),i=1,3)
1046 	  format(3(L2,f4.1))
!			For sturmxx, the components 1,2,3 are labelled 2,3,1 !!
!			so fc(2)=1, fc(3)=2, fc(1)=3
!			ie fc(sturmxx label) = face-label
	  if(mfad>1)
     x	  write(41,*) (fc(is),pairs(1,fc(is)),pairs(2,fc(is)),is=1,mfad)
	  endif
       endif

   	write(41,105) jtot,psign(jparity+2)
105   	format(' coupled channels set ',f5.1,1x,a1)

	xla = 0d0
	  write(41,106) nint(2*jtot),jparity,imaxh,0,xla,0d0
106	  format(4i5,f10.5,g12.4)

	if(details) then
! Sturmx requires channels to be labelled 1,2,3,4 in the order
!			 FADS / 'T','Y','X','M' /
	if(eqn.eq.'F') then
	  if(ytorder) write(41,*) (3,i=1,imax(3)),
     X			          (2,i=1,imax(2)),(1,i=1,imax(3))
	  if(.not.ytorder) write(41,*) (1,i=1,imax(3)),
     x       		 	       (2,i=1,imax(2)),(3,i=1,imax(1))
	 else if(eqn.eq.'N') then
	  write(41,*) (1,i=1,imax(3)),(4,i=imax(3)+1,imaxs)
	 else if(eqn.eq.'T') then
	  write(41,*) (1,i=1,imax(3))
	 else if(eqn.eq.'Y') then
	  write(41,*) (2,i=1,imaxh)
	 endif
	do ib=1,3
 	  write(41,*) (ii(io(i,1),ib,1),i=1,imaxh)
	enddo
	endif

! quantum numbers written in order  given in qnum!
 	write(41,*) (kk(io(i,1),1),i=1,imaxh)
 	write(41,*) (lltot(io(i,1),1),i=1,imaxh)
 	write(41,*) (nint(2*ssx(io(i,1),1)),i=1,imaxh)
   	write(41,*) (ll1(io(i,1),1),i=1,imaxh)
   	write(41,*) (ll2(io(i,1),1),i=1,imaxh)
	write(41,*) (nint(2*jab(io(i,1),1)),i=1,imaxh)
!						Put proper core states in later
	do ib=1,3
 	write(41,*) (nint(2*spin(ii(io(i,1),ib,1),ib)),i=1,imaxh)
	enddo
 	write(41,*) (nint(2*jtot),i=1,imaxh)
	write(41,*) nsrc,0

	  cf(:) =  0d0
	  rewind iwf
	  do i=1,nlag
	  read(iwf) ww(1:imaxh,1:imaxh)
	  wwl(:,:,i) = ww(:,:)
	  enddo
	if(eqn.eq.'F') then
        do 762 j=1,imaxh
        do 762 k=1,imaxh
762     write(40) (wwl(io(j,1),io(k,1),i),i=1,nlag),cf(1:ipmax)
        do 763 i=1,imaxh
763     write(40) (wn1(io(i,1),io(j,1)),j=1,imaxh)
        write(40) (mp12(io(i,1)),i=1,imaxh)
 	else
        do 765 j=1,imaxh
        do 765 k=j,imaxh
765     write(40) (wwl(j,k,i),i=1,nlag),cf(1:ipmax)
	endif

	end
