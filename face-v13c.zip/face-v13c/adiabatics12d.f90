	subroutine adiabatics
	use physics
	use methodspec
	use work
	use groundstate
	implicit real*8(a-h,o-z)
	real*8 wm(imaxh,imaxh)
	real*8 valr(imaxh),vali(imaxh),vecsr(imaxh,imaxh),vecsi(imaxh,imaxh)
	integer niter(imaxh)
!        RL(X,XLIM) = max(-XLIM,min(XLIM,x))
        RL(X,XLIM) = x
	 
	  write(6,*) '  find adiabatic surfaces'
	  rewind iwf
	do  il=1,nlag
	  r = xl(il)*rr
	  write(10,*) '  find adiabatic surfaces at rho = ',real(r)
	  
	  read(iwf) wm
	  !wm(:,:) = ww(:,:,il)
	  do i=1,imaxh
		k=kkh(i)
		ic1=iih(i,1)
		ic2=iih(i,2)
		ic3=iih(i,3)
		ib = ibh(i)
	    et = energy(ic1,ib) + energy(ic2,pairs(1,ib)) + energy(ic3,pairs(2,ib))
	  wm(i,i) = wm(i,i) + et + h2sm*(k+1.5)*(k+2.5)/(r*r)
	  enddo
	  
	  call f02agf(wm,imaxh,imaxh,valr,vali,vecsr,imaxh,vecsi,imaxh,niter,ifail)
          call m01daf(valr,1,imaxh,'a',niter,ifail)
          call m01zaf(niter,1,imaxh,ifail)
          write(91,10) r,(rl(valr(niter(i))    ,1000d0),i=1,min(imaxh,20))
          write(92,10) r,(rl(valr(niter(i))*r*r,1000d0),i=1,min(imaxh,20))
10      format(f8.3,1p,20e10.2)
	
	
	enddo
	end
