      subroutine printco(im)
	use physics
	use methodspec
	use work
      implicit double precision (a-h,o-z)
	parameter(mxfile=10)
	real, allocatable:: wwl(:,:,:)

c
c----  print some of the coupling terms ww 
c
!	write(10,*) 'im, nlag,nbmax =',im,nlag,nbmax
!	write(10,*) 'rr =',rr
	if(.not.cfiles) then
	  do i=mxfile,mxfile,4
	  write(i,*)
	  write(i,*) 'All Gauss-Laguerre points:'
	  write(i,755) (rr*xl(j),j=1,nlag)
	  write(i,*)
	  write(i,*) 'Gauss-Laguerre points for nbmax =',abs(nbmax),':'
	  write(i,755) (rr*xlag(j),j=1,abs(nbmax))
	  enddo
	else
	  do i=mxfile,mxfile,4
	  write(i,*)
	  write(i,*) 'All radial points:'
	  write(i,755) (rr*xl(j),j=1,nlag)
	  enddo
	  endif
c	ninc = max(nlag/8,1)
	ninc = max(nlag/5,1)
c	ninc = 1
	nlv = (nlag-1)/ninc+1
	allocate (wwl(im,im,nlv+1))
	
	wwl(:,:,:) = 0.
	rewind iwf
	do il=1,nlag
	read(iwf) ww(1:im,1:im)
	ilv = (il-1)/ninc+1
	if(il==(ilv-1)*ninc+1) wwl(:,:,ilv) = ww(:,:)
!	if(il==(ilv-1)*ninc+1) write(10,*) 'Saving ',il,'@',ilv
	if(il==2) wwl(:,:,nlv+1) = ww(:,:)
	enddo
!	write(10,*) 'Printing',(i,i=1,nlag,ninc)
	
	
	write(10,*) 
	write(10,*) 'Diagonal couplings:'
	write(10,755) (rr*xl(i),i=1,nlag,ninc)
	do 658 k=1,im
658	write(10,760) k,k,(wwl(k,k,i),i=1,nlv)
	write(10,*) 
	write(10,*) 'selected couplings:'
	write(10,755) (rr*xl(i),i=1,nlag,ninc)
c755	format(' radii:   ',8f8.3,:,/(10x,8f8.3))
c755	format(' radii:   ',7f10.3,:,/(10x,7f10.3))
755	format(' radii:   ',9f12.3,:,/(10x,9f12.3))

	do 758 j=1,im
	do 758 k=1,im
758	write(10,760) j,k,(wwl(j,k,i),i=1,nlv)
c760	format(1x,i3,'<-',i3,':',8f8.3,:,/(10x,8f8.3))
c760	format(1x,i3,'<-',i3,':',7g10.2,:,/(10x,7g10.2))
760	format(1x,i3,'<-',i3,':',9g12.4,:,/(10x,9g12.4))

	k=2
	write(10,7611) rr*xl(k)
 7611   format(/'  coupling matrix at r =',f8.3,':'/)
  	do 7631 i=1,im
 7631	write(10,7651) i,(wwl(i,i1,nlv+1),i1=1,im)
c7651	format(1x,i3,10f8.3,:,/(4x,10f8.3))
 7651	format(1x,i3,16f8.3,:,/(4x,16f8.3))

	write(10,770) 
 770    format(/'  normalisation & permutation matrix:'/)
  	do 780 i=1,im
 780	write(10,790) i,(wn1(i,i1),i1=1,im)
c790	format(1x,i3,10f8.4,:,/(4x,10f8.4))
 790	format(1x,i3,16f8.4,:,/(4x,16f8.4))
 	deallocate(wwl)
	return
	end
