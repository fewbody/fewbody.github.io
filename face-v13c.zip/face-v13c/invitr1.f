	subroutine invitrm(a,ia,ib,n,val,vec,neigs,e1,eps,mc)
	implicit real*8(a-h,o-z)
	dimension a(ia,n),vec(ib,neigs),rhs(n),val(neigs)
	integer p(n)

	parameter (zero=0d0, one=1d0)
c
c	find neigs eigensolutions nearest to e1 for ax=ex 
c	by inverse iteration:  [a-e1] x(n) = x(n-1)
c	
c	at end, val(kv)=e, vec(*,kv)=x for kv=1,neigs, 
c	a destroyed
c
!	write(6,*) 'Invitr: ia,ib,n,neigs,e1,eps,mc =',
!     x			ia,ib,n,neigs,e1,eps,mc
	do 10 i=1,n
	  a(i,i) = a(i,i) - e1
10	continue
	write(6,15) neigs,e1
15	format(/' Inverse iteration to find ',i3,' eigenstates nearest'
     x		,f10.5)

c			l.r decomposition 
	  call dgetrf(n,n,a,ia,p,ifail)
	if(ifail.ne.0) then
	     write(6,*)' singular matrix decomposition for this energy'
	      stop 'invitr'
	endif
	do 300 kv=1,min(neigs,n)
c			starting vector
	do 20 i=1,n
20	rhs(i)=one/sqrt(real(n))
c	rhs(1) = one
	e = zero
		
	do 100 ic=1,mc
	  elast = e
	   do 25 i=1,n
25	     vec(i,kv) = rhs(i)
        call dgetrs('n',n,1,a,ia,p,vec(1,kv),n,info)

	do 40 kvp=1,kv-1
	wn = zero
	do 30 i=1,n
30	wn = wn + vec(i,kv)*vec(i,kvp)
	do 35 i=1,n
35	vec(i,kv) = vec(i,kv) - wn*vec(i,kvp)
40	continue
	wn = zero
	do 45 i=1,n
45	wn = wn + vec(i,kv)*rhs(i)
	do 50 i=1,n
	   rhs(i) = vec(i,kv)
50	continue
	an=zero
	do 60 i=1,n
60	  an = an + vec(i,kv)*rhs(i)
	e = e1 + wn/an
	write(6,80) ic,e,e-elast
80	format(' iteration ',i4,' gives ',f10.5,', change =',1p,e10.2)
	call flush(6)
	an = one/sqrt(an)
	do 70 i=1,n
70	  rhs(i) = rhs(i) * an
	val(kv) = e
	if(ic.gt.3 .and. abs(e-elast).lt.eps) go to 200
100	continue
	write(6,*) ' inverse iteration failed after',mc,
     x             ' iterations for state ',kv,' near',real(e)
c	stop
200	do 210 i=1,n
210	vec(i,kv) = vec(i,kv) * an
	write(6,*) 
300	continue
	return
	end
