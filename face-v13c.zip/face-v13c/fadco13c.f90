	subroutine fadcoef
	use physics
	use methodspec
	use work
	use twobody_states
	implicit real*8(a-h,o-z)
!
! explicit dependence of the potentials before angular integration on lu 
	real*8 vnnc(0:mmultipole,njac,0:l1max),  &
	      vnnss(njac,0:l1max),vnnls(njac,0:l1max),vnnt(njac,0:l1max)
	real*8  a(499,29),sk(0:mmultipole,0:mmultipole/2,0:l1max,2)
	real*8  cc(imaxx,3,imaxx,3) 
!
! the angular integrated potentials depend explicitly on l1 (for jac poly) 
! and lu (for potential). no need for partition ib dependence since the
! initialisation of these will be within the ib loop
	real*8 uc(0:nmax,0:nmax,0:l1max,0:l2max,0:l1max,0:mmultipole,0:mmultipole/2)
	real*8 uls(0:nmax,0:nmax,0:l1max,0:l2max)
	real*8 uss(0:nmax,0:nmax,0:l1max,0:l2max)
	real*8 ut(0:nmax,0:nmax,0:l1max,0:l2max),  & 
	       ut1(0:nmax,0:nmax,0:l1max,0:l2max)
	real*8 wnc(imaxs,imaxs),wls(imaxs,imaxs),wss(imaxs,imaxs),  &
		wt(imaxs,imaxs),wt1(imaxs,imaxs), &
		wdef(2:mmultipole,imaxs,imaxs)
	real*8 jn,jn1,meso,mess,metensor,medef1,medef2
        real*8 jv,jx,jxmin,jxmax,jxmin1,jxmax1
	real*8 vvv(0:10),vvvls(0:10),vvvss(0:10),vvvt(0:10)
	integer q,same1(1:3,1:3),same2(1:3,1:3),same3(1:3,1:3)
	logical sameii,occup
	data same1(:,1)/1,3,2/, same1(:,2)/2,1,3/, same1(:,3)/3,2,1/
	data same2(:,1)/2,1,3/, same2(:,2)/3,2,1/, same2(:,3)/1,3,2/
	data same3(:,1)/3,2,1/, same3(:,2)/1,3,2/, same3(:,3)/2,1,3/
!
!	same1 holds the number os the nucleus in partition ia that is the	
!		spectator (1) in partition ib
!	same2 holds the number os the nucleus in partition ia that is the	
!		first interacting pair (2) in partition ib
!	same3 holds the number os the nucleus in partition ia that is the	
!		second interacting pair (3) in partition ib
!	so:
!
!	sameii(i,ia,i1,ib) = ii(i1,1,ib)==ii(i,same1(ia,ib),ia) .and.	&
!			     ii(i1,2,ib)==ii(i,same2(ia,ib),ia) .and.	&
!			     ii(i1,3,ib)==ii(i,same3(ia,ib),ia) 
!

	eps = 1d-12
	zero = 0d0
	itr=1
!
! initialising the potentials for print out only
 	if(itr>0) then
	  do ib=1,3
	   write(6,*) '   do potentials for partition ',ib
	   write(10,*) '  Potentials for partition ',ib
	  do ir=0,40
	    r = ir*0.2
		do l1=0,l1max
!		 vvv(l1) = vc(l1,r,ib)
                 vvv(l1) = vc(l1,r,ib) + vcoul(r,ib)
		 vvvls(l1) = vls(l1,r,ib)
		 vvvss(l1) = vss(l1,r,ib)
		 vvvt(l1) = vt(l1,r,ib)
		enddo
	    write(10,'(f6.2,12f8.3,:,/(6x,12f8.3))')  &
	      r,(vvv(l1),l1=0,min(4,l1max)), &
		(vvvss(l1),l1=0,min(4,l1max)),	&
		(vvvls(l1),l1=0,min(4,l1max)), &
		(vvvt(l1),l1=0,min(4,l1max)), v3b(1,1,r,ijt)
	  enddo
	  enddo
	    write(10,*) '&'
	    call flush(10)
!	    write(11,*) '&'
!	    call flush(11)
 	endif


	if(itr>3) write(10,*) 'Fadco: mass(:) =',mass,masstot
	cc(:,:,:,:) = zero
	do 21 ia=1,3
	do 20 ib=1,3
	 if(ia==ib) go to 20

! parameters for the kinematic rotation ia and ib = Faddeev components: 
! the spectator masses
      t=masstot*(masstot-mass(ia)-mass(ib))/(mass(ia)*mass(ib))
      tphi=sqrt(t)
      cphi=1.d0/(1.d0+t)
      sphi=1.d0/(1.d0+1.d0/t)
      cphi=-sqrt(cphi)
      sphi=sqrt(sphi)
	if(ib /= pairs(1,ia)) then
	  sphi = -sphi
	  endif
	tphi = sphi/cphi
	if(itr>3) write(10,*) ' For ',ia,'->',ib,', c,s,t =',cphi,sphi,tphi
!					From ia to ib
	do i=1,imax(ia)
	  k=kk(i,ia)
	  l1=ll1(i,ia)
	  l2=ll2(i,ia)
	  ltot=lltot(i,ia)
	  jj=k-ltot
	  nnn=jj-2*(jj/2)
	  j1=jj/2+1
	  j=ltot-nnn+1
	  kln=(k-ltot+nnn)/2
	  klz=(k+ltot)/2
	  call rrcoe(k,ltot,l1,l2,cphi,sphi,tphi,a,j,j1)
	    do j=1,imax(ib)
	    k1=kk(j,ib)
	    ltot1=lltot(j,ib)
	    if(k==k1 .and. ltot==ltot1) then
	    l1b=ll1(j,ib)
	    l2b=ll2(j,ib)
	    m=(klz+kln-l1b-l2b)/2+1
	    n=l1b-kln+m
!	    l1b=kln+n-m
!	    l2b=klz-n-m+2
 	    cc(j,ib,i,ia)=a(m,n) * (-1)**l2
		if(itr>3) write(10,*) 'cc(',j,ib,i,ia,') =',cc(j,ib,i,ia)
	    endif
	    enddo 
	enddo  
20	continue
21	continue


!
! ALGEBRA ------------------------------------  ALGEBRA
!
	allocate(wn1(imaxs,imaxs), mp12(imaxs),wfn(imaxs,imaxs))
	wn1(:,:) = 0d0
	wnc(:,:) = 0d0
	wls(:,:) = 0d0
	wss(:,:) = 0d0
	wt(:,:)  = 0d0
	wdef(:,:,:)  = 0d0

	do 700 ia=1,3
	kqmax=max(qmax(pairs(1,ia)),qmax(pairs(2,ia)))
	do 700 ib=1,3

!	write(99,*) 'kqmax, ia, ib: ', kqmax,ia,ib

!				If ia==ib, calculate potential matrix elements
!				For all,   calculate norm matrix wn1
!				Afterwards, fill in off-diagonal potl terms
	do 650 i=1,imax(ia)
	   l1=ll1(i,ia)
	   l2=ll2(i,ia)
	   k=kk(i,ia)
	   ltot=lltot(i,ia)
	   sxx=ssx(i,ia)
	   jn=jab(i,ia)
	   iy=i+imax0(ia)

	do 640 i1=1,imax(ib)

	   sameii = 	ii(i1,1,ib)==ii(i,same1(ia,ib),ia) .and.	&
			ii(i1,2,ib)==ii(i,same2(ia,ib),ia) .and.	&
			ii(i1,3,ib)==ii(i,same3(ia,ib),ia) 

	   k1=kk(i1,ib)
	   ltot1=lltot(i1,ib)
 	   l11=ll1(i1,ib)
 	   l21=ll2(i1,ib)
	   sxx1=ssx(i1,ib)
	   jn1=jab(i1,ib)
	   i1y=i1+imax0(ib)

!		 			Spin overlap matrix wfn
	   fn = fadnorm(i,ia,i1,ib)		
	   wfn(iy,i1y) = fn

!		 			Normalisation matrix wn1 
	   c=0d0
	   if(ia/=ib) c=cc(i,ia,i1,ib)
	   if(ia==ib.and.i==i1) c = 1d0
	   wn1(iy,i1y) = c * fn


	 if(ia==ib) then
!		 			Matrix wnc of central potentials
	   c=0d0
	   if(sameii.and.l1==l11.and.l2==l21.and.ltot==ltot1  &
		.and.abs(sxx-sxx1)<eps.and.abs(jn-jn1)<eps) c = 1d0
	     wnc(iy,i1y) = c * fn

!		 			Matrix wls of spin-orbit potentials
	   c=0d0
	   if(sameii.and.l1==l11.and.l2==l21.and.abs(jn-jn1)<eps) c = 1d0
	     wls(iy,i1y) = c * meso(i,i1,ia)

!		 			Matrix wss of spin-spin potentials
	   c=0d0
	   if(l1==l11.and.l2==l21.and.ltot==ltot1.and.sameii) c = 1d0
	     wss(iy,i1y) = c * mess(i,i1,ia)

!		 			Matrix wt of tensor potentials
	   c=0d0
	   if(l2==l21.and.sameii) c = 1d0
	     wt(iy,i1y) = c * metensor(i,i1,ia)

	   c=0d0
	   kq1=qmax(pairs(1,ia))
	   kq2=qmax(pairs(2,ia))
	   if(kq1.gt.eps.and.kq2.gt.eps) then 
	   write(6,*) '  TWO DEFORMED OBJECTS NOT ALLOWED YET!'
	   stop
	   endif
	   if(kq1.gt.eps) then
	     do kq=2,kq1
	       if (def(kq,pairs(1,ia)).gt.0.d0) c = 1.d0
	       wdef(kq,iy,i1y) = c * medef1(i,i1,ia,kq)
	     enddo
	   else
	     do kq=2,kq2
	       if (def(kq,pairs(2,ia)).gt.eps) c = 1.d0
	       wdef(kq,iy,i1y) = c * medef2(i,i1,ia,kq)
	     enddo 
	   endif
	 endif
640	continue
650	continue
700	continue
	  
	mp12(:) = 0d0
	if(itr>2.or.pripot) then
	write(10,*) '  Racah overlap matrix:'
  	do i=1,imaxs
     	write(10,790) i,(wfn(i,i1),i1=1,imaxs)
	enddo
	write(10,*) '  Norm overlap matrix:'
  	do i=1,imaxs
     	write(10,790) i,(wn1(i,i1),i1=1,imaxs)
	enddo
	write(10,'(/''  Central potential matrix:''/)')
  	do  i=1,imaxs
 	write(10,790) i,(wnc(i,i1),i1=1,imaxs)
 	enddo
	write(10,'(/''  Spin-orbit potential matrix:''/)')
  	do  i=1,imaxs
 	write(10,790) i,(wls(i,i1),i1=1,imaxs)
 	enddo
	write(10,'(/''  Spin-spin potential matrix:''/)')
  	do  i=1,imaxs
 	write(10,790) i,(wss(i,i1),i1=1,imaxs)
 	enddo
	write(10,'(/''  Tensor potential matrix:''/)')
  	do  i=1,imaxs
 	write(10,790) i,(wt(i,i1),i1=1,imaxs)
 	enddo
	qmaxall=max(qmaxb(1),qmaxb(2),qmaxb(3))
	do kq=2,qmaxall
	write(10,'(/''  Deformation potential matrix:''/)')
	write(10,*) 'MULTIPOLE: ',kq
  	do  i=1,imaxs
 	write(10,790) i,(wdef(kq,i,i1),i1=1,imaxs)
 	enddo
	enddo
 790	format(1x,i3,16f6.2,:,/(4x,16f6.2))
	endif

!
!	write(99,*)  ' w matrix elements done!'
!

! angular matrix elements of the potential energy
	write(6,*) '   allocate ww section of ',int(imaxs**2*8/1e6)+1,' Mb'
	write(6,*) '   allocate ww files of 2 *',int(nlag*imaxs**2*8/1e6)+1,' Mb'
	allocate( ww(imaxs,imaxs))
	iwf = 60
	open(iwf,access='sequential',status='scratch',form='unformatted')
!       open(iwf,access='sequential',form='unformatted', &
!    &           file=trim(tmpdir)//trim(nfile)//'.tmp.'//      &
!    &                char(ichar('0')+mod(iwf,2)))

	do 500 il=1,nlag     	! ----------------------------------- loop in radius
	  rho = rr*xl(il)
	  ww(:,:) = 0.
	if(itr>1) write(10,*) 'Fadco: rho =',rho

	do 301 ib=1,3     	! ------------------------------- loop in fadd partition

	  ip = mod(ib+1,3)+1
	  if (id(ip).and.init>10) then
	    if(il==1) write(6,*) ' Not calculating component rows ',ib,', as will use isospin symmetry'
	    go to 301
	    endif
!
! subsidiary angular matrix elements between Jacobi HH
	  kq1=qmax(pairs(1,ib))
	  kq2=qmax(pairs(2,ib))

	    dnn=sqrt((mass(pairs(1,ib))+mass(pairs(2,ib)))    &
                    /(mass(pairs(1,ib))*mass(pairs(2,ib)))) 
	     if(mass(pairs(1,ib)).gt.998.) dnn = sqrt(1d0/mass(pairs(2,ib))) 
	     if(mass(pairs(2,ib)).gt.998.) dnn = sqrt(1d0/mass(pairs(1,ib))) 

	if (.not.forb(ib)) then
!			------------- loop in fadd partition no forbidden states
!
	 if(il==1) write(6,*) ' For basis ',ib,', dnn =',real(dnn)
	lumxx = min(l1max,lxmax(ib))
	do lu=0,lumxx
	do j=1,njac
	  sy=sqrt(.5d0-0.5d0*xj(j))
	  x = rho*sy
	  rnn=x*dnn
	  vnnls(j,lu)=vls(lu,rnn,ib)
	  vnnss(j,lu)=vss(lu,rnn,ib)
	  vnnt(j,lu)=vt(lu,rnn,ib)
	  if (kq1.eq.0.and.kq2.eq.0) then
 	    vnnc(0,j,lu)=vc(lu,rnn,ib)
	  else
            if(kq1.gt.eps) then
	       call potdef(lu,kq1,rnn,vnnc(0,j,lu),def(2:kq1,pairs(1,ib)),ib)
	    else
	       call potdef(lu,kq2,rnn,vnnc(0,j,lu),def(2:kq2,pairs(2,ib)),ib)
	    endif
	  endif
          vnnc(0,j,lu)=vnnc(0,j,lu) + vcoul(rnn,ib)  ! add monopole Coulomb!
	 enddo
	if (kq1.gt.eps.or.kq2.gt.eps) then
	    write(10,'(a6,i3,f6.2,12f8.3)')  &
	      'vdef :',lu,rnn,(vnnc(i,1,lu),i=0,max(kq1,kq2))
	endif
	enddo

!
!	write(99,*) ' Vnn potentials done!'
!
! potential matrix elements: hyperangular integration
!
	do 43 l1=0,lumxx 		!------------------------------ loop in lx
	do 42 l2=0,l2max 		!------------------------------ loop in ly
!
! loops in jacobi basis
	do 40 n=0,nmax
	do 39 n1=0,n
!
! initialising auxiliary variables
	s=0.
	s1=0.
	s2=0.
	s4=0.
	s41=0.
	s42=0.
	  do 30 q=0,qmaxb(ib)
	   do 30 ldd=0,q/2
	   do 30 lu=0,lumxx
	  sk(q,ldd,lu,1)=0.0
	  sk(q,ldd,lu,2)=0.0
30	  continue

! central part - if no deformation
	do 35 jjj=1,njac
	if(qmaxb(ib).eq.0) then
	  s=s+wj(jjj)*pj(n,l1,l2,jjj)*pj(n1,l1,l2,jjj)*vnnc(0,jjj,l1)
	 else
!
! if the is deformation -
! the potential matrix elements defined in this way have the freedom of choice 
! of which l=lu to be used for the potential (up to the max l1 within the partition)
! all lu's are initialised - default lu=l1=min(l1,l11).
!
	  do 31 q=0,qmaxb(ib)
	  do 31 ldd=0,q/2
	  do 31 lu=0,lumxx
	   if(lpot(ib)<10.or.q>0) then  ! find new monopoles only if lpot < 10
	     l1d=mod(q,2)+ldd*2
	   if(l1+l1d.le.l1max) then
	     sk(q,ldd,lu,1)=sk(q,ldd,lu,1) + wj(jjj) *    &
     &                                     pj(n,l1,l2,jjj)*pj(n1,l1+l1d,l2,jjj)*vnnc(q,jjj,lu)
	     sk(q,ldd,lu,2)=sk(q,ldd,lu,2) + wj(jjj) *   &
     &                                     pj(n1,l1,l2,jjj)*pj(n,l1+l1d,l2,jjj)*vnnc(q,jjj,lu)
	   endif
	   endif
31	  continue
	 if(lpot(ib)>=10) then  ! keep original l1 monopole - put in all lu positions!
	   sk(0,0,0:lumxx,1)=sk(0,0,0:lumxx,1) + wj(jjj) *    &
     &                                     pj(n,l1,l2,jjj)*pj(n1,l1,l2,jjj)*vnnc(0,jjj,l1)
	   sk(0,0,0:lumxx,2)=sk(0,0,0:lumxx,2) + wj(jjj) *   &
     &                                     pj(n1,l1,l2,jjj)*pj(n,l1,l2,jjj)*vnnc(0,jjj,l1)
	  endif ! lpot
	 endif ! qmax
	s2=s2 + wj(jjj)*pj(n,l1,l2,jjj)*pj(n1,l1,l2,jjj)*vnnss(jjj,l1)
	if(l1.ne.0)then
	s1=s1+wj(jjj)*pj(n,l1,l2,jjj)*pj(n1,l1,l2,jjj)*vnnls(jjj,l1)
	s4=s4+wj(jjj)*pj(n,l1,l2,jjj)*pj(n1,l1,l2,jjj)*vnnt(jjj,l1)
	endif
	if(l1+2.le.l1max) then
		s41=s41+wj(jjj)*pj(n,l1,l2,jjj)*pj(n1,l1+2,l2,jjj)  &
     &			*vnnt(jjj,l1)
		s42=s42+wj(jjj)*pj(n1,l1,l2,jjj)*pj(n,l1+2,l2,jjj)  &
     &			*vnnt(jjj,l1)
	endif
35	continue
	if(qmaxb(ib).eq.0) then
	   uc(n,n1,l1,l2,l1,0,0)=s
	   uc(n1,n,l1,l2,l1,0,0)=s
	  else
	   do 36 q=0,qmaxb(ib)
	   do 37 ldd=0,q/2
	   do 37 lu=0,lumxx
	     uc(n,n1,l1,l2,lu,q,ldd)=sk(q,ldd,lu,1)
	     uc(n1,n,l1,l2,lu,q,ldd)=sk(q,ldd,lu,2)
37	   continue
		if(itr>6.and.qmaxb(ib).gt.0) then
		     write(10,*) 'ucdef(',n1,n,l1,l2,q,') = ', &
			(real(uc(n1,n,l1,l2,lu,q,ldd)),ldd=0,q/2)
		endif
36	   continue
	endif
	uls(n1,n,l1,l2)=s1
	uls(n,n1,l1,l2)=s1
	uss(n,n1,l1,l2)=s2
	uss(n1,n,l1,l2)=s2
	ut(n,n1,l1,l2)=s4 
	ut(n1,n,l1,l2)=s4
	ut1(n,n1,l1,l2)=s41
	ut1(n1,n,l1,l2)=s42
		if(itr>6) write(10,*) 'uc(',n,n1,l1,l2,') =',s
		if(itr>6) write(10,*) 'uls(',n,n1,l1,l2,') =',s1
		if(itr>6) write(10,*) 'ut(',n,n1,l1,l2,') =',s4
		if(itr>6) write(10,*) 'ut1(',n,n1,l1,l2,') =',s41
39	continue
40	continue
42	continue
43	continue
45	continue

!
!	write(99,*) ' u potentials (after angular integration) done!'
!
        ia = ib
	if(itr>1) write(10,*) 'Fadco: ia,ib =',ia,ib
!						<ia | V(ia) | ib=ia>
	do 90 i=1,imax(ia)  !-------------------------- channel in ia fad partition
	   l1=ll1(i,ia)
	   l2=ll2(i,ia)
	   k=kk(i,ia)
	   ltot=lltot(i,ia)
	   sxx=ssx(i,ia)
	   jn=jab(i,ia)
	   iy=i+imax0(ia)
!
	do 80 i1=1,imax(ib)  !-------------------------- channel' in ia fad partition
!
! make sure the spin of the spectator is the same
	   sameii = ii(i1,1,ib)==ii(i,1,ia) 
!
	   if(.not.sameii) go to 80
	   if(abs(jab(i1,ib)-jab(i,ia))>eps) go to 80
	   l11=ll1(i1,ib)
	   l21=ll2(i1,ib)
	   if(l2/=l21) go to 80
	   k1=kk(i1,ib)
	   ltot1=lltot(i1,ib)
	   sxx1=ssx(i1,ib)
	   i1y=i1+imax0(ib)
	   n=(k-l1-l2)/2	
	   n1=(k1-l11-l21)/2
	   if (l1==l11) then 
		ten=ut(n,n1,l1,l2) * wt(iy,i1y)
	   else
		ten=ut1(n,n1,l1,l2) * wt(iy,i1y)
	   endif
	   deform=0.d0
	     l1min=min(l1,l11)
	     lumin=l1min
	     lumax=max(l1,l11)
	     luav=(l1+l11)/2
	     if(lpot(ia).eq.0) lu=lumin
	     if(lpot(ia).eq.1) lu=luav
	     if(lpot(ia).eq.2) lu=lumax
	     if(lpot(ia).eq.3) lu=l1
	     if(lpot(ia).ge.10) lu=lpot(ia)-10 ! independent of l1 and l11
	   do kq=2,qmaxb(ib)
	   do ldd=0,kq/2
	     l1d=mod(kq,2)+ldd*2
	     if(l1.eq.l11+l1d  .or. l11.eq.l1+l1d) then
	     if(l1.eq.l1min)then
		na=n
		nb=n1
	     else
		na=n1
		nb=n
	     endif
	     deform = deform + uc(na,nb,l1min,l2,lu,kq,ldd) *  wdef(kq,iy,i1y)
	     endif
           enddo
           enddo
      	 	ww(iy,i1y)=uc(n,n1,l1,l2,l1,0,0) * wnc(iy,i1y)  &
      	 	             +uls(n,n1,l1,l2) * wls(iy,i1y)  &
		             +uss(n,n1,l1,l2) * wss(iy,i1y)  &
		             +ten 				&
	                               +deform
	if(itr>2) write(10,*) ' ww(',iy,i1y,') now 1 is ',ww(iy,i1y)
80	continue
90	continue
!
!	write(99,*) ' ww matrix elements ia=ib done! ib : ', ib
!

300	continue    	! ------------- loop in fadd partition with no forbidden states
	else
        ia = ib
	if(itr>1) write(10,*) 'Fadco: ia,ib =',ia,ib
!						<ia | V(ia) | ib=ia> from SUSY
        do 250 i2s=1,n2states
          if(ia/=twbod(i2s)%inf%pair) go to 250
	   occup = twbod(i2s)%inf%fermi>-800..or.twbod(i2s)%inf%s_kind<=0   ! must be same as occ
	  if(.not.occup.or.twbod(i2s)%inf%test) go to 250
          jv = twbod(i2s)%inf%jv
          nch= twbod(i2s)%nch
	   if(itr>0.and.il==5) write(10,*) ' Include ',ia,' SUSY potentials from state',i2s,real(jv),nch
        do 230 i2i=1,nch
          ic1i = twbod(i2s)%ic1v(i2i) 
          ic2i = twbod(i2s)%ic2v(i2i) 
          l2i  = twbod(i2s)%lv(i2i) 
          sv   = twbod(i2s)%sv(i2i) 
        do 230 i2i1=1,nch
          ic1i1= twbod(i2s)%ic1v(i2i1) 
          ic2i1= twbod(i2s)%ic2v(i2i1) 
          l2i1 = twbod(i2s)%lv(i2i1) 
          sv1  = twbod(i2s)%sv(i2i1) 
	   is=1.0/dx
!	   if(itr>2) write(10,162) (twbod(i2s)%vccx(ix+1,i2i,i2i1),ix=is,is*5,is)
	   if(itr>0.and.il==5) write(10,162) (twbod(i2s)%vccx(ix+1,i2i,i2i1),ix=is,is*5,is)
162        format(' V2(:) =',5f12.3)
          
	do 190 i=1,imax(ia)  !-------------------------- channel in ia fad partition
	   l1=ll1(i,ia)
	   l2=ll2(i,ia)
	   k=kk(i,ia)
	   n=(k-l1-l2)/2
	   ltot=lltot(i,ia)
	   sxx=ssx(i,ia)
	   jn=jab(i,ia)
	   iy=i+imax0(ia)
	   jxmin=abs(l1-sxx)
	   jxmax=l1+sxx
!	   if(itr>2.and.il==5) write(10,155) 'A',i2i,l2i,i,l1,jxmin,jxmax
155	   format(' ',a1,':Try 2body ',2i3,' with 3body ',2i3,2f5.1)
           if(abs(sxx-sv)>1e-5) go to 190
           if(jv<jxmin.or.jv>jxmax) go to 190
           if(l2i/=l1) go to 190
	   if(ii(i,2,ia)/=ic1i .or. ii(i,3,ia)/=ic2i) go to 190
	   if(itr>2.and.il==5) write(10,*) ' A:2body ',i2i,' matches 3body ',i
!
	do 180 i1=1,imax(ib)  !-------------------------- channel' in ia fad partition
!
!    make sure the spin of the spectator is the same
	   sameii = ii(i1,1,ib)==ii(i,1,ia) 
!
	   if(.not.sameii) go to 180
	   l11=ll1(i1,ib)
	   l21=ll2(i1,ib)
!	   if(itr>2.and.il==5) write(10,155) 'B',i2i1,l2i1,i1,l11
	   if(l2/=l21) go to 180
           if(l2i1/=l11) go to 180
	   if(ii(i1,2,ib)/=ic1i1 .or. ii(i1,3,ib)/=ic2i1) go to 180
!	   if(itr>2.and.il==5) write(10,155) 'B',i2i1,l2i1,i1,l11
	   k1=kk(i1,ib)
	   n1=(k1-l11-l21)/2
	   ltot1=lltot(i1,ib)
	   sxx1=ssx(i1,ib)
           if(abs(sxx1-sv1)>1e-5) go to 180
	   jn1=jab(i1,ib)
	   if(abs(jab(i1,ib)-jab(i,ia))>eps) go to 180  
	   i1y=i1+imax0(ib)
	   jxmin1=abs(l11-sxx1)
	   jxmax1=l11+sxx1
!	   if(itr>2.and.il==5) write(10,*) 'BB: need ',real(jxmin1),'<=',real(jv),'<=',real(jxmax1)
!	   if(itr>2.and.il==5) write(10,*) 'BB: from l11,sxx1 =',l11,real(sxx1)
           if(jv<jxmin1.or.jv>jxmax1) go to 180
	   if(itr>2.and.il==5) write(10,*) ' B:2body ',i2i1,' matches 3body ',i1

           s1 = racah(l2+zero,l1+zero,jn,sxx,ltot+zero,jv) * sqrt((2*ltot+1)*(2*jv+1))
           s2 = racah(l21+zero,l11+zero,jn1,sxx1,ltot1+zero,jv)* sqrt((2*ltot1+1)*(2*jv+1))
     	    coef = (-1)**nint(ltot+ltot1-l1-l11+jv+jv-jn-jn1) * s1 * s2
	   if(itr>2.and.il==5) write(10,160) i,i1,coef,(twbod(i2s)%vccx(ix+1,i2i,i2i1),ix=is,is*5,is)
160	   format(' This couples chs ',i3,' and ',i3,' with ',f10.5,', V2(:)=',5f9.3)
!	   if(itr>2) write(10,161) l2+zero,l1+zero,jn,sxx,ltot+zero,jv,s1
!	   if(itr>2) write(10,161) l21+zero,l11+zero,jn1,sxx1,ltot1+zero,jv,s2
!161        format(' hh*Racah(',6f5.1,') =',f10.5)
	   if(abs(coef)>1e-5) then
	    vrho=0.d0
	    do jjj=1,njac
	      sy=sqrt(.5d0-0.5d0*xj(jjj))
	      x = rho*sy
	      rnn=x*dnn
              ix = rnn/dx+1
              if(ix<nx) then
                px = (rnn-(ix-1)*dx)/dx
                qx = 1.-px
	        vcx=twbod(i2s)%vccx(ix,i2i,i2i1)*qx + twbod(i2s)%vccx(ix+1,i2i,i2i1)*px
	        vrho=vrho + vcx * pj(n,l1,l2,jjj)*pj(n1,l11,l21,jjj)*wj(jjj)
              endif
	    enddo
	    ww(iy,i1y)=ww(iy,i1y) + vrho * coef
	    if(itr>2.and.il==5) write(10,165) iy,i1y,il,ww(iy,i1y)
165	    format(' ww(',3i3,') now is ',1p,e12.4)
	    if(itr>2.and.il==5) write(10,*)
	   endif
170        continue
180	continue
190	continue
230     continue
250     continue
!
!	write(99,*) ' ww matrix elements ia=ib done! ib : ', ib
!
	endif		! ------------- if on whether fadd partition has forbidden states
301     continue
!---------------------------------------------------------------------------------------
!
!				Afterwards, fill in off-diagonal potl terms:
!						<ia | V(ia) | ib/=ia>
 	do ia=1,3
 	  ip = mod(ia+1,3)+1
	  if (id(ip).and.init>0) go to 400
 	do ib=1,3
	if(ia/=ib) then
	  do i=1,imax(ia)
	   iy=i+imax0(ia)
	  do j=1,imax(ib)
	   i1y=j+imax0(ib)
	  do k=1,imax(ia)
	   i2y=k+imax0(ia)
	     ww(iy,i1y) = ww(iy,i1y) + ww(iy,i2y)*wn1(i2y,i1y)
	  enddo
	  enddo
	  enddo
	 endif
	enddo
400	continue
	enddo
!		Add in 3-body potential
	do iy=1,imaxs
	do i1y=1,imaxs
	ww(iy,i1y) = ww(iy,i1y) + v3b(iy,i1y,rho,ijt)
	enddo
	enddo
	
!
!	write(99,*) ' ww matrix elements ia not eq ib done!  il = ', il
!
	write(iwf) ww
500	continue		! ----------------------------------- loop in radius
	end
